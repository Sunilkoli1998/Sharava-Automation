package com.Common;

import com.data.ImgDiffPercent;
import com.data.Shonit_data.*;


import org.apache.commons.io.FileUtils;
import org.apache.log4j.LogManager;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.apache.log4j.Logger;

import javax.swing.plaf.TableHeaderUI;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.ThreadLocalRandom;
import java.util.concurrent.TimeUnit;


public class ShonitRBCReport extends ReportPage {


    public Properties props;
    public WebDriver driver;
    public WebDriverWait wait;
    public ImgDiffPercent imagecomp;
    String curDir = System.getProperty("user.dir");
    private final Logger logger = LogManager.getLogger(ShonitRBCReport.class);
    String filename = "Shonit.csv";

    Map<String, Map<String, String>> RBCColordata = new HashMap<String, Map<String, String>>();
    Map<String, Map<String, String>> RBCPoikdata = new HashMap<String, Map<String, String>>();
    Map<String, Map<String, String>> RBCSizedata = new HashMap<String, Map<String, String>>();


    public ShonitRBCReport(WebDriver driver) throws Exception {
        super(driver);
        this.driver = driver;
        PropertiesFile.readRbcPropertiesFile();
        PropertiesFile.readShonitPropertiesFile();
        PropertiesFile.readShonitListReportFile();

        props = PropertiesFile.prop;
        int time = Integer.parseInt(props.getProperty("timeout"));
        wait = new WebDriverWait(driver, time);
        imagecomp = new ImgDiffPercent();


    }

//---------------------------------- RBC Tab --------------------------------------------

    //Click on RBC Tab
    public Boolean clickonRBCTab() throws InterruptedException {

        return super.clickonTab(props.getProperty("rbctab"));
    }

//---------------------------------- RBC Size --------------------------------

    //Get name of tables in RBC tab
    public String getRBCListofTabels() {
        props = PropertiesFile.prop;
        //String labels="";
        String tablelist = driver.findElement(By.xpath(props.getProperty("alltables"))).getText();
        System.out.println(tablelist);

        return tablelist;
    }

    public String updateThereport() throws InterruptedException {
        props = PropertiesFile.prop;
        driver.findElement(By.xpath(props.getProperty("updateButton"))).click();
        driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
        Thread.sleep(1000);
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(props.getProperty("tableContent")))).isDisplayed();
        driver.findElement(By.xpath(props.getProperty("clickOnUpdateButton"))).click();
        Thread.sleep(3000);
        String popupMessage = driver.findElement(By.xpath(props.getProperty("updationMessage"))).getText();
        driver.findElement(By.xpath(props.getProperty("clickOnClosePopup"))).click();
      //  Thread.sleep(3000);
        driver.manage().timeouts().pageLoadTimeout(25, TimeUnit.SECONDS);


        return popupMessage;


    }










    //Get header of RBC Size
    public String getRBCSizeColoumns() {
        props = PropertiesFile.prop;
        return wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.xpath(props.getProperty("rbcsizeheader")))).getText();
    }


    //Get list of rows in RBC Size
    public String getRBCSizerows() throws InterruptedException {
        List<WebElement> listofrows = driver.findElements(By.xpath(props.getProperty("rbcsizerow")));
        String header = "";
        for (WebElement listofrow : listofrows) {
            header = header + (listofrow.getText()) + ",";
            System.out.println(header);
        }

        return header;
    }

    //verify  the Grades with Colour codes with conditions for RBC cells except normocte and normal
    public Boolean verifytheGradeForMicrocyte(WebElement grade,WebElement gradecoulor) {
        props = PropertiesFile.prop;
        String num = grade.getText();
        boolean flage=false;
        String Gradecoulor="";
        int nums = Integer.parseInt(num);
        Gradecoulor=gradecoulor.getAttribute("class");
     System.out.println("The actual grade value is "+nums);
        if (nums < 2 && Gradecoulor.contains("non-significance") ) {
            System.out.println("the grade is not significant with grade number as "+nums);
            System.out.println(Gradecoulor);
            flage=true;
        }else {
            if(nums>=2 && Gradecoulor.contains("significance"))
            {
                System.out.println("the grade is  significant with grade number as "+nums);
                System.out.println(Gradecoulor);
                flage=true;
            }

        }
         return flage;
    }



    //verify  the Grades with Colour codes with conditions for normocte and normal
    public Boolean verifytheGradeForNormocyte(WebElement grade,WebElement gradecoulor) {
        props = PropertiesFile.prop;

        String num = grade.getText();
        boolean flage=false;
        String Gradecoulor="";
        int nums = Integer.parseInt(num);
        Gradecoulor=gradecoulor.getAttribute("class");
        System.out.println("The actual grade value is "+nums);
        if (nums < 2 && Gradecoulor.contains("significance") ) {
            System.out.println("the grade is significant with grade number as "+nums);
            System.out.println(Gradecoulor);
            flage=true;
        }else {
            if(nums>=2 && Gradecoulor.contains("non-significance"))
            {
                System.out.println("the grade is  non-significant with grade number as "+nums);
                System.out.println(Gradecoulor);
                flage=true;
            }

        }
        return flage;
    }



public boolean VerifyPercentageForRBCSize()
    {
        props = PropertiesFile.prop;
        float total = 0;
        boolean flage=false;
        List<WebElement> Percentage = driver.findElements(By.xpath(props.getProperty("Percentage")));

        for (WebElement Percentage1:Percentage) {
         String Value= Percentage1.getText().trim().split("%")[0];
            //float percentage = Float.parseFloat(rowdata.get(2).getText());
        float Percentage2 = Float.parseFloat(Value);
               // parseInt();
//           int Percentage3= Integer.
            total=total+Percentage2;

        }if (total==100.00)
    {
        flage=true;
    }
        System.out.println("the total percentage is "+total);
        return flage;
    }









    public String typeOfSignificant() {
        props = PropertiesFile.prop;
        String text = driver.findElement(By.xpath(props.getProperty("significantType"))).getText();
        System.out.println(text);
        return text;
    }

    public String noteMessage() {
        props = PropertiesFile.prop;
        String noteText = driver.findElement(By.xpath(props.getProperty("noteMessage"))).getText();
        System.out.println(noteText);
        return noteText;
    }

    public String metricsNameOnAovePatches() {
        String metricsName = driver.findElement(By.xpath(props.getProperty("metricsName"))).getText();
        System.out.println(metricsName);
        return metricsName;
    }

    public String viewSettingRBC() {
        driver.findElement(By.xpath(props.getProperty("ViewInputField"))).click();
        String options = driver.findElement(By.xpath(props.getProperty("RBCViewOptions"))).getText();
        driver.findElement(By.xpath(props.getProperty("clickOnAllText"))).click();
        System.out.println(options);
        return options;
    }

    public boolean diableViewbeforeSelection() {
        boolean condition = driver.findElement(By.xpath(props.getProperty("viewSettingBeforeSelection"))).isEnabled();
        if (condition) {
            System.out.println("setting is enabled");
        } else {
            System.out.println("setting is disabled");
        }
        return true;
    }

    public String clickOnExpandButtonOnRBC() throws InterruptedException {
        Actions act = new Actions(ShonitRBCReport.this.driver);
        WebElement element = driver.findElement(By.xpath(props.getProperty("firstPatchImage")));
        act.moveToElement(element).perform();
        driver.findElement(By.xpath(props.getProperty("clickOnViewFullImage"))).click();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        WebElement canvasVisibility = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(props.getProperty("ImageVisibility"))));
        canvasVisibility.isDisplayed();
        Thread.sleep(1000);
        //actions.moveToElement(canvasVisibility).build().perform();
        String text = driver.findElement(By.xpath(props.getProperty("extractedCellText"))).getText();
       // driver.findElement(By.xpath(props.getProperty("clickOnClose"))).click();
       // driver.manage().timeouts().pageLoadTimeout(10, TimeUnit.SECONDS);
        return text;
    }


    public String cellNameOnREferenceTab() {
        props = PropertiesFile.prop;
        String sameCellNameonReference = driver.findElement(By.xpath(props.getProperty("selectedCellOnReference"))).getText();
        //driver.manage().timeouts().implicitlyWait(20,TimeUnit.SECONDS);
        //  driver.findElement(By.xpath(props.getProperty("close"))).click();
        System.out.println(sameCellNameonReference);
        return sameCellNameonReference;
    }

    public String rbcSizeRegrading() throws InterruptedException {
        boolean flage=false;
        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
        WebElement grade = driver.findElement(By.xpath(props.getProperty("grade")));

        String num=grade.getText();
        int nums=Integer.parseInt(num);
        System.out.println(nums);
        grade.click();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        List<WebElement> gradingValues = driver.findElements(By.xpath(props.getProperty("gradingVlaue")));
        int s = ThreadLocalRandom.current().nextInt(0, gradingValues.size());

            if (nums!=s) {
                gradingValues.get(s).click();

            }else{
               if(nums==s && s!=3) {
                   s = s + 1;
                   gradingValues.get(s).click();
               }else{
                   s = s - 1;
                   gradingValues.get(s).click();
               }
            }

        Thread.sleep(2000);

// driver.findElement(By.xpath(props.getProperty("updateButton"))).click();
//        driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
//        Thread.sleep(1000);
//        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(props.getProperty("tableContent")))).isDisplayed();
//        driver.findElement(By.xpath(props.getProperty("clickOnUpdateButton"))).click();
//        String popupMessage = driver.findElement(By.xpath(props.getProperty("updationMessage"))).getText();
//        driver.findElement(By.xpath(props.getProperty("clickOnClosePopup"))).click();
//        driver.manage().timeouts().pageLoadTimeout(25, TimeUnit.SECONDS);
//        return popupMessage;

//        Thread.sleep(10000);
//        WebElement grade1 = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(props.getProperty("grade"))));
////        String actualgrade=grade.getText();
//        String actualgrade=grade.getAttribute("value");
//        int actualRegrade=Integer.parseInt(actualgrade);
//        if (actualRegrade==selectedValue)
//        {
//            flage=true;
//        }

return updateThereport();

    }

    public Boolean clickonRBCPoikilocytesTab() throws InterruptedException {
        Thread.sleep(1000);
        return super.clickonTab(props.getProperty("rbcpoikilocytesTab"));

    }


//verifying the updated grade
public String verifyUpdatedGrade()
{
    WebElement grade = driver.findElement(By.xpath(props.getProperty("gradeOnPoikilocytes")));

    String UpdatedGrade=grade.getText();
    return UpdatedGrade;

}
    //Get list of rows in get RBC Size rows
    public void getRBCSizerowsNew() throws InterruptedException {
        this.RBCSizedata = super.collectTableData(props.getProperty("rbcsizerow"), props.getProperty("rbcsizeheaders"));
    }

    //Get list of rows in External metrics
    public Map<String, Map<String, String>> sendRBCSizerows() throws InterruptedException {
        if (this.RBCSizedata.size() == 0)
            this.getRBCSizerowsNew();
        return this.RBCSizedata;
    }

    //verify RBC Size patches patches
    public boolean getRBCSizepatches() throws InterruptedException {
        return super.verifypatches(props.getProperty("rbcsizerow"));
    }

    //verify RBC size grading
    public boolean verifyRBCSizeGrading() throws Exception {
        return super.verifyGrading(RBCSizedata, filename);
    }

    //Validate date for RBC absolute table
    public boolean VerifyRbcSizeTableData(String product) throws Exception {
        props = PropertiesFile.prop;
        this.getRBCSizerowsNew();
        ArrayList<String> columns = new ArrayList<String>();
        columns.add("Count");
        columns.add("Percentage");
        return super.createCSVFortable(product, RBCSizedata, "RBCSize", columns);
    }

//---------------------------------- RBC Poikilocytes --------------------------------

    //Get header of RBC Poik*
    public String getRBCPoikColumns() {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.xpath(props.getProperty("rbcpoikheader")))).getText();
    }

    //Get list of rows in RBC Poik*
    public String getRBCPoikrows() throws InterruptedException {
        String listofrows = super.gettablerows(props.getProperty("rbcpoikrow"));
        return listofrows;
    }

    //Get list of rows in get RBC Size rows
    public void getRBCPoikrowsNew() throws InterruptedException {
        this.RBCPoikdata = super.collectTableData(props.getProperty("rbcpoikrow"), props.getProperty("rbcpoikheaders"));
    }
    public String rbcPoikilocytesRegrading() throws InterruptedException {
        Thread.sleep(2500);
        WebElement grade = driver.findElement(By.xpath(props.getProperty("gradeOnPoikilocytes")));

        String num=grade.getText();
        int nums=Integer.parseInt(num);
        System.out.println(nums);
        grade.click();
        driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
        List<WebElement> gradingValues = driver.findElements(By.xpath(props.getProperty("gradingVlaue")));

        int s = ThreadLocalRandom.current().nextInt(0, gradingValues.size());

        if (nums!=s) {
            Thread.sleep(1500);
            gradingValues.get(s).click();

        }else{
            if(nums==s && s!=3) {
                s = s + 1;
                Thread.sleep(1500);
                gradingValues.get(s).click();
            }else{
                s = s - 1;
                Thread.sleep(1500);
                gradingValues.get(s).click();
            }
        }
        Thread.sleep(1500);
        return updateThereport();

    }
    //Get list of rows in External metrics
    public Map<String, Map<String, String>> sendRBCPoikrowsrows() throws InterruptedException {
        if (this.RBCPoikdata.size() == 0)
            this.getRBCPoikrowsNew();
        return this.RBCPoikdata;
    }

    //verify RBC Poikrows patches
//    public boolean getRBCPoikrowspatches() throws InterruptedException {
//        Thread.sleep(3000);
//        return super.verifypatches(props.getProperty("rbcpoikrow"));
//    }



//verify the patches header for RBC paokilocyte
    public boolean verifypatcheHeader(String tablepath) throws InterruptedException {
        props = PropertiesFile.prop;
        boolean Cellname = false;
        String ActualCellname1="";
        List<WebElement> rowdata;
        WebElement firstpatch = null;

        List<WebElement> tablerows = wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(
                By.xpath(tablepath)));
        for (WebElement cellName:tablerows)

         // for (int i=0;i<tablerows.size()-2;i++)
//           for (WebElement cellName:tablerows)
     {

         cellName.click();
         Thread.sleep(3000);
           String ExpectedCellname=cellName.getText();
           WebElement Actualname=driver.findElement(By.xpath(props.getProperty("patchHeader")));
           String ActualCellname=Actualname.getText();

   char[] AA= ActualCellname.toCharArray();
    for(int j=0; j<AA.length-8;j++) {
        ActualCellname1 = ActualCellname1+AA[j];
    }
           logger.info(ActualCellname1);
    System.out.println("+"+ActualCellname1+"+");
           if(ExpectedCellname.equals(ActualCellname1))
           {
                  Cellname=true;
               System.out.println("ExpectedCellname "+ExpectedCellname+":"+ActualCellname1+" ActualCellname");

           }else {
              Cellname=false;
               System.out.println("ExpectedCellname "+ExpectedCellname+" not eqaul"+ActualCellname1+" ActualCellname");
               break;
           }
         ActualCellname1="";
        }
        return Cellname;
    }







    //Get total percentage of WBC absolute
    public boolean verifyRBCPoikilocytesPercentageTotal() throws InterruptedException {
        Thread.sleep(3000);
        return super.verifyTotalPercentageAndCount(props.getProperty("rbcpoikrow"));
    }

    //verify RBC Poik grading
    public boolean verifyRBCPoikGrading() throws Exception {
        return super.verifyGrading(RBCPoikdata, filename);

    }

    //Validate date for wbc absolute table
    public boolean VerifyRbcPoikTableData(String product) throws Exception {
        props = PropertiesFile.prop;
        this.getRBCPoikrowsNew();
        ArrayList<String> columns = new ArrayList<String>();
        columns.add("Count");
        columns.add("Percentage");
        return super.createCSVFortable(product, RBCPoikdata, "RBCPoikilocytes", columns);
    }

//---------------------------------- RBC Color --------------------------------

    //Get header of RBC Color
    public String getRBCColorColumns() {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.xpath(props.getProperty("rbccolorheader")))).getText();
    }

    //Get list of rows in RBC Color
    public String getRBCColorrows() throws InterruptedException {
        String listofrows = super.gettablerows(props.getProperty("rbccolorrow"));
        this.getRBCColorrowsNew();
        return listofrows;
    }

    //Get list of rows in get RBC Size rows
    public void getRBCColorrowsNew() throws InterruptedException {
        this.RBCColordata = super.collectTableData(props.getProperty("rbccolorrow"), props.getProperty("rbccolorheaders"));
    }

//---------------------------------- RBC Diameter --------------------------------

    //Get header of RBC Diameter
    public String getRBCDiameterColoumns() {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.xpath(props.getProperty("rbcdiameterheader")))).getText();
    }

//---------------------------------- RBC Pallor Ratio --------------------------------

    //Get header of RBC Pallor
    public String getRBCPallorColoumns() {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.xpath(props.getProperty("rbcpallorheader")))).getText();
    }

//---------------------------------- Histogram of RBC diameters --------------------------------

    //verify RBC Histogarm table
    public String getRBCHistogram() throws InterruptedException, IOException {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.xpath(props.getProperty("historbcheader")))).getText();
    }

    //verify RBC Histogarm  chart
    public boolean getRBCHistogramchart() {

        return wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.xpath(props.getProperty("histofullchart")))).isDisplayed();
    }

    //verify RBC Histogarm ratio table
    public boolean getRBCHistRefRadio() throws InterruptedException, IOException {
        props = PropertiesFile.prop;
        this.clickonRBCTab();
        File scrFile = ((TakesScreenshot) driver).
                getScreenshotAs(OutputType.FILE);

        String curr = curDir + "/src/test/java/com/rbc/histoRef-current.png";
        FileUtils.copyFile(scrFile, new File(curr));
        Thread.sleep(2000);

        boolean status = false;
        while (true) {
            try {
                driver.findElement(By.cssSelector(props.getProperty("historefradio"))).click();
                status = true;
            } catch (Exception e) {
                Thread.sleep(1000);
            }
            if (status == true) break;
        }

        File scrFile1 = ((TakesScreenshot) driver).
                getScreenshotAs(OutputType.FILE);
        driver.findElement(By.cssSelector(props.getProperty("historefradio"))).click();

        String difference = curDir + "/src/test/java/com/rbc/HistoRef-difference.png";
        FileUtils.copyFile(scrFile1, new File(difference));
        double differ = imagecomp.getDifferencePercent(curr, difference);
        return differ > 0.0;

    }

//---------------------------------- Histogram of ratio of RBC pallor to total area --------------------------------

    //verify RBC Poller Histogarm Radio button
    public boolean getRBCPollHistoPollRadio() throws InterruptedException, IOException {
        props = PropertiesFile.prop;
        File scrFile = ((TakesScreenshot) driver).
                getScreenshotAs(OutputType.FILE);

        String curr = curDir + "/src/test/java/com/rbc/histoRBCdia-current.png";
        FileUtils.copyFile(scrFile, new File(curr));
        Thread.sleep(2000);
        boolean status = false;
        while (true) {
            try {
                driver.findElement(By.cssSelector(props.getProperty("historatioradio"))).click();
                status = true;
            } catch (Exception e) {
                Thread.sleep(1000);
            }
            if (status == true) break;
        }
        File scrFile1 = ((TakesScreenshot) driver).
                getScreenshotAs(OutputType.FILE);
        driver.findElement(By.cssSelector(props.getProperty("historatioradio"))).click();

        String difference = curDir + "/src/test/java/com/rbc/HistoRBCdia-difference.png";
        FileUtils.copyFile(scrFile1, new File(difference));
        double differ = imagecomp.getDifferencePercent(curr, difference);
        return differ > 0.0;
    }

    //verify RBC Poller Histogram  table  
    public String getRBCPoller() throws InterruptedException, IOException {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.xpath(props.getProperty("pollrbcheader")))).getText();
    }

    //verify RBC Poller Histogram chart
    public boolean getRBCPollchart() throws InterruptedException, IOException {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.xpath(props.getProperty("pollfullchart")))).isDisplayed();
    }

    //verify RBC Poller Referance Radio button
    public boolean getRBCPollRefRadio() throws InterruptedException, IOException {
        props = PropertiesFile.prop;
        File scrFile = ((TakesScreenshot) driver).
                getScreenshotAs(OutputType.FILE);

        String curr = curDir + "/src/test/java/com/rbc/pollRef-current.png";
        FileUtils.copyFile(scrFile, new File(curr));
        Thread.sleep(2000);

        Actions action = new Actions(driver);
        //action.moveToElement(driver.findElement(By.cssSelector(props.getProperty("pollrefradio")))).click().build().perform();
        boolean status = false;
        while (true) {
            try {
                action.moveToElement(driver.findElement(By.cssSelector(props.getProperty("pollrefradio")))).click().build().perform();
                status = true;
            } catch (Exception e) {
                action.sendKeys(Keys.PAGE_DOWN).perform();
                Thread.sleep(1000);
            }
            if (status == true) break;
        }

        File scrFile1 = ((TakesScreenshot) driver).
                getScreenshotAs(OutputType.FILE);

        action.moveToElement(driver.findElement(By.cssSelector(props.getProperty("pollrefradio")))).click().build().perform();

        String difference = curDir + "/src/test/java/com/rbc/pollRef-difference.png";
        FileUtils.copyFile(scrFile1, new File(difference));
        double differ = imagecomp.getDifferencePercent(curr, difference);
        return differ > 0.0;


    }

    //verify RBC Poller Histogarm Radio button
    public boolean getRBCPollHistoRadio() throws InterruptedException, IOException {
        props = PropertiesFile.prop;
        File scrFile = ((TakesScreenshot) driver).
                getScreenshotAs(OutputType.FILE);

        String curr = curDir + "/src/test/java/com/rbc/pollRBCdia-current.png";
        FileUtils.copyFile(scrFile, new File(curr));
        Thread.sleep(2000);

        Actions action = new Actions(driver);
        boolean status = false;
        while (true) {
            try {
                action.moveToElement(driver.findElement(By.cssSelector(props.getProperty("pollratioradio")))).click().build().perform();

                status = true;
            } catch (Exception e) {
                action.sendKeys(Keys.PAGE_DOWN).perform();
                Thread.sleep(1000);
            }
            if (status == true) break;
        }

        File scrFile1 = ((TakesScreenshot) driver).
                getScreenshotAs(OutputType.FILE);

        action.moveToElement(driver.findElement(By.cssSelector(props.getProperty("pollratioradio")))).click().build().perform();

        String difference = curDir + "/src/test/java/com/rbc/pollRBCdia-difference.png";
        FileUtils.copyFile(scrFile1, new File(difference));
        double differ = imagecomp.getDifferencePercent(curr, difference);
        return differ > 0.0;

    }

    //--------------------------------------------------------------------------------------
    
    

    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
 /*   
    
    //Click on RBC tab
    public Boolean clickonRBC(){
        boolean flag = false;
       String rbc = wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.xpath(props.getProperty("rbcref")))).getText();
        if(rbc.matches("RBC")){
            wait.until(ExpectedConditions.visibilityOfElementLocated(
                    By.xpath(props.getProperty("rbcref")))).click();
            flag = true;
        }
        return flag;
    }


    //Verify that RBC tab is loaded successfully
    public String RBCTabpage()
    {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(props.getProperty("rbctab")))).getText();
    }

    //get the row size for RBC Size section
    public int getRBCSizecount(){
        List<WebElement> rbcsizerows = driver.findElements(By.xpath(props.getProperty("rbcsizesect")));
        int count = rbcsizerows.size();
        return count;
    }

    //get RBC size values
    public List<String> getRBCsizeValues() {

        int count = getRBCSizecount();
        List<String> rbcsizevalues=new ArrayList<String>();

        int i;
        for(i=0;i<=count;i++) {
            List<WebElement> rbcsizecount = driver.findElements(
                    By.xpath(props.getProperty("rbcsizeval")+"["+i+"]"));
            for(WebElement rbcsizearray : rbcsizecount) {
                String rbcsizetext = rbcsizearray.getText();
                rbcsizevalues.add(rbcsizetext);
            }
        }
        return rbcsizevalues;
    }


    //get the row size for RBC Poililocytes section
    public int getRBCPoikilocytescount()
    {
        List<WebElement> rbcpoikilocytesrows = driver.findElements(By.xpath(props.getProperty("rbcpoikilocyterow")));
        int count = rbcpoikilocytesrows.size();
        return count;
    }

    //get RBC Poikilocytes values
    public List<String> getRBCPoikilocytesValues() {

        int count = getRBCPoikilocytescount();
        List<String> rbcpoikilocytesvalues=new ArrayList<String>();

        int i;
        for(i=0;i<=count;i++) {
            List<WebElement> rbcpoikilocytes = driver.findElements(
                    By.xpath(props.getProperty("rbcpoikilocyte")+"["+i+"]"));
            for(WebElement poikilocytearray : rbcpoikilocytes) {
                String rbcpoikilocytestext = poikilocytearray.getText();
                rbcpoikilocytesvalues.add(rbcpoikilocytestext);
            }
        }
        return rbcpoikilocytesvalues;
    }



    //get the row size for RBC Diameter
    public int getRBCDiametercount(){
        List<WebElement> rbcdiameterrows = driver.findElements(By.xpath(props.getProperty("rbcdiameter")));
        int count = rbcdiameterrows.size();
        return count;
    }

    //get RBC Diameter values
    public List<String> getRBCDiameterValues() {

        int count = getRBCDiametercount();
        List<String> rbcdiametervalues=new ArrayList<String>();

        int i;
        for(i=0;i<=count;i++) {
            List<WebElement> rbcdiameter = driver.findElements(
                    By.xpath(props.getProperty("rbcdiameterval")+"["+i+"]"));
            for(WebElement rbcdiameterarray : rbcdiameter) {
                String rbcdiametertext = rbcdiameterarray.getText();
                rbcdiametervalues.add(rbcdiametertext);
            }
        }
        return rbcdiametervalues;
    }

    //get the row size for RBC Pallor Ratio
    public int getRBCPallorRatiocount(){
        List<WebElement> rbcpallarratiorows = driver.findElements(By.xpath(props.getProperty("rbcpallor")));
        int count = rbcpallarratiorows.size();
        return count;
    }

    //get RBC Pallor Ratio values
    public List<String> getRBCPallorRatioValues() {

        int count = getRBCPallorRatiocount();
        List<String> rbcpallarratiovalues=new ArrayList<String>();

        int i;
        for(i=0;i<=count;i++) {
            List<WebElement> rbcpallarratio = driver.findElements(
                    By.xpath(props.getProperty("rbcpallorval")+"["+i+"]"));
            for(WebElement rbcpallorarray : rbcpallarratio) {
                String rbcpallarratiotext = rbcpallorarray.getText();
                rbcpallarratiovalues.add(rbcpallarratiotext);
            }
        }
        return rbcpallarratiovalues;
    }

*/
}
