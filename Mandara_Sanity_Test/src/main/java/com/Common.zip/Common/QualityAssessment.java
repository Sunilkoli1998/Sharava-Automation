package com.Common;

import com.data.ImgDiffPercent;
import com.data.Shonit_data.PropertiesFile;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.util.List;
import java.util.Properties;

public class QualityAssessment extends ReportPage{
    private final WebDriverWait wait;
    public Properties props;
    public WebDriver driver;
    public Login login;

    String curDir = System.getProperty("user.dir");

    private final Logger logger = LogManager.getLogger(QualityAssessment.class);



    public QualityAssessment(WebDriver driver) throws Exception {
        super(driver);
        this.driver = driver;
        wait = new WebDriverWait(driver, 50);
        PropertiesFile.readMicroscopicViewFile();
        PropertiesFile.readCommentPropertiesFile();
        props = PropertiesFile.prop;
        //imagecomp = new ImgDiffPercent();


    }

    public boolean clickOnQualityAssessmentTab() throws InterruptedException {
        props = PropertiesFile.prop;
        return super.clickonTab(props.getProperty("QualityAssessmenttab"));
    }

    public String qualityAssessmentHeader() {

        String header = driver.findElement(By.xpath(props.getProperty("qualityAssessmentHeader"))).getText();
        System.out.println(header);
        return header;
    }

    public String suggestionOnQualityAssessmentTab() {
        List<WebElement> suggestion = driver.findElements(By.xpath(props.getProperty("suggestion")));
        String suggestionName = "";
        for (WebElement suggestions : suggestion) {
            suggestionName = suggestionName + (suggestions.getText()) + ",";
        }
        System.out.println(suggestionName);
        return suggestionName;
    }

    public String visibilityOfBacktolist() {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.xpath(props.getProperty("backtolist")))).getText();
    }

    // get backtolist button
    public boolean clickonbacktolist() {
        WebElement button = wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.xpath(props.getProperty("backtolist"))));
        if (button.isDisplayed()) {
            button.click();
            return true;
        }
        return false;
    }

    // get backtolist button
    public boolean verifyBacktolist() throws InterruptedException {
        WebElement button = wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.xpath(props.getProperty("clickOnBack"))));
        if (button.isDisplayed()) {
            button.click();
            Thread.sleep(2000);
            return super.verifyListReportPage().contains("Analysis Reports");
        }
        return false;
    }

    public void clickUserIcon() {
        WebElement usericon = wait.until(ExpectedConditions.elementToBeClickable(By.xpath(props.getProperty("usericon"))));
        usericon.click();
    }

    public boolean checkLogout() throws InterruptedException {
        clickUserIcon();
        Thread.sleep(2000);
        WebElement logout = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(props.getProperty("logoutOption"))));
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", logout);
        Thread.sleep(1000);
        logout.click();
        Thread.sleep(2000);
        try {
            boolean flag1 = login.visibilityOfLoginContainer();

            if (flag1) {
                return true;
            } else {
                return false;
            }
        } catch (NullPointerException e) {
        }


        return true;
    }

}
