package com.Common;

import com.data.Shonit_data.PropertiesFile;
import jdk.internal.instrumentation.Logger;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.io.File;
import java.io.IOException;
import java.util.*;
import java.util.concurrent.ThreadLocalRandom;
import java.util.concurrent.TimeUnit;

import static org.openqa.selenium.support.ui.ExpectedConditions.visibilityOfElementLocated;

public class ShonitPlateleteReport extends ReportPage {


    public Properties props;
    public WebDriver driver;
    public WebDriverWait wait;
    ShonitRBCReport shonitRBCReport;
    Actions actions;
    String filename = "Shonit.csv";

    Map<String, Map<String, String>> Pltdata = new HashMap<String, Map<String, String>>();

    public ShonitPlateleteReport(WebDriver driver) throws Exception {
        super(driver);
        this.driver = driver;
        PropertiesFile.readShonitPropertiesFile();
        PropertiesFile.readShonitListReportFile();

        props = PropertiesFile.prop;
        int time = Integer.parseInt(props.getProperty("timeout"));
        wait = new WebDriverWait(driver, time);
    }


//---------------------------------- Platelet Tab --------------------------------------------

    //Click on PLT Tab
    public Boolean clickonpltTab() throws InterruptedException {
        return super.clickonTab(props.getProperty("plttab"));
    }

    //Get name of tables in plt tab
    public String getpltListofTabels() throws InterruptedException {
        props = PropertiesFile.prop;
        String tabelnames = wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.xpath(props.getProperty("pltabsolute")))).getText();

        tabelnames = tabelnames + wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.xpath(props.getProperty("pltdiameter")))).getText();
        System.out.println(tabelnames);
        return tabelnames;
    }

    //Get header of plt Absolute
    public String getpltAbsoluteColoumns() {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.xpath(props.getProperty("pltheader")))).getText();
    }

    //Get list of rows in Plt cell names
    public String getpltAbsoluterows() throws InterruptedException {

        props = PropertiesFile.prop;
        String cellname = "";
        List<WebElement> platelleteName = wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(
                By.xpath(props.getProperty("pltrows"))));
        for (int i = 0; i < platelleteName.size() - 1; i++) {
            cellname = cellname + platelleteName.get(i).getText();
        }

        return cellname;
    }

    public String getPlateletModifiedNote() {
        props = PropertiesFile.prop;
        String PlateletMOdifiedNote = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(props.getProperty("PlateletModifiedNote_Xpath")))).getText();
        return PlateletMOdifiedNote;
    }

    public String ImpressionDetection() {
        String text = driver.findElement(By.xpath(props.getProperty("impressionDetection"))).getText();
        System.out.println(text);
        return text;
    }

    public float compareavarageCount() {
        props = PropertiesFile.prop;
        float avaragecount = 0;
        List<WebElement> PlateletCount = wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(
                By.xpath(props.getProperty("plateletCountXpath"))));
        for (int i = 0; i < PlateletCount.size() - 2; i++) {
            String count = PlateletCount.get(i).getText();
            avaragecount = avaragecount + Float.parseFloat(count);
//            avaragecount=avaragecount+Integer.parseInt(count);
        }
        System.out.println("the avarage cunt is " + avaragecount);
        return avaragecount;

    }

    public String verifytheNMGnoteWithColourcode() {
        props = PropertiesFile.prop;
        String TextColour = "";
        List<WebElement> NMGcolourCode = wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(
                By.xpath(props.getProperty("NMGXpath"))));
        for (WebElement NMG : NMGcolourCode) {
            TextColour = TextColour + NMG.getText();
        }
        return TextColour;
    }

    public String verifyFOVnumberwithtext() {
        props = PropertiesFile.prop;
        String FOV = "";
        List<WebElement> FOVNUmber = wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(
                By.xpath(props.getProperty("PlateletFOVXpath"))));
        for (WebElement FOV1 : FOVNUmber) {
            FOV = FOV + FOV1.getText();
        }
        return FOV;
    }

    public float VerifyTheaverageCountOfIndividualCells(String NormalPlateletFOVXpath1, String firstrowcell) throws InterruptedException {
        float total = 0;
        // List<WebElement> normalpatelates=driver.findElements(By.xpath("//*[@id='plateletCount']/div[2]/div[2]/div[1]/app-platelet-fov-level-count-table/div/div[2]/div/div[3]/div[1]/app-platelet-fov-cell-level-input/div/div"));
        List<WebElement> normalpatelates = driver.findElements(By.xpath(NormalPlateletFOVXpath1));

        for (int i = 1; i <= normalpatelates.size() - 1; i++) {
            //normalpatelates.get(i).click();
            //Thread.sleep(1000);
            //String count= driver.findElement(By.xpath("//*[@id='plateletCount']/div[2]/div[2]/div[1]/app-platelet-fov-level-count-table/div/div[2]/div/div[3]/div[1]/app-platelet-fov-cell-level-input/div/div/input")).getAttribute();
            String count = normalpatelates.get(i).getText();
            System.out.println(count);
            int count1 = Integer.parseInt(count);
            total = total + count1;
        }
        driver.findElement(By.xpath("//app-platelet-fov-level-count-table[1]/div[1]/div[2]/div[2]/div[2]")).click();
        Thread.sleep(2000);
//        String frstval= driver.findElement(By.xpath("//div[1]/div[2]/div[1]/div[3]/div[1]/app-platelet-fov-cell-level-input[1]/div[1]/div[1]")).getText();
        String frstval = driver.findElement(By.xpath(firstrowcell)).getText();

        int count3 = Integer.parseInt(frstval);
        total = total + count3;
        System.out.println(total);
        float totalcountofplateltes = total / 10;
        System.out.println(totalcountofplateltes);
//        WebElement avgcountval= driver.findElement(By.xpath("//app-platelet-count-table[1]/div[1]/app-table[1]/table[1]/tbody[1]/tr[1]/td[2]/div[1]/div[1]"));
//        String avgcount=avgcountval.getText();
//        float avgcount1=Float.parseFloat(avgcount);

//        if(avgcount1==totalcountofplateltes){
//            System.out.println( avgcount1+"="+totalcountofplateltes);
//        }
        Thread.sleep(2000);
        driver.findElement(By.xpath("//app-platelet-fov-level-count-table[1]/div[1]/div[2]/div[1]/div[2]")).click();
        return totalcountofplateltes;


    }


    public String verifythe100xFOVnote() {
        String noteText = driver.findElement(By.xpath(props.getProperty("100xfovnoteXpath"))).getText();
        System.out.println(noteText);
        return noteText;
    }


    public String noteMessageOnPlatelet() {
        String noteText = driver.findElement(By.xpath(props.getProperty("plateletnoteMessage"))).getText();
        System.out.println(noteText);
        return noteText;
    }


    public String cellNameOnREferenceTab() throws InterruptedException {
        props = PropertiesFile.prop;
        Thread.sleep(1000);
        String sameCellNameonReference = driver.findElement(By.xpath(props.getProperty("selectedCellOnReferenceTab"))).getText();
        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
        driver.findElement(By.xpath(props.getProperty("close"))).click();
        System.out.println(sameCellNameonReference);
        return sameCellNameonReference;
    }


    //Get list of rows in Plt absolute data
    public void getpltAbsoluterowsNew() throws InterruptedException {
        this.Pltdata = super.collectTableData(props.getProperty("pltrows"), props.getProperty("pltheaders"));
    }

    //Get list of rows in External metrics
    public Map<String, Map<String, String>> sendpltAbsoluterows() throws InterruptedException {
        if (this.Pltdata.size() == 0)
            this.getpltAbsoluterowsNew();
        return this.Pltdata;
    }

    //verify PLT absolute patches
    public boolean getpltAbsolutepatches() throws InterruptedException {
        return super.verifypatches(props.getProperty("pltrows"));
    }

    //verify Platelet Absolute grading
    public boolean verifyPlateletAbsoluteGrading() throws Exception {
        return super.verifyGrading(Pltdata, filename);
    }

    public String plateletRevampingfornormal() throws InterruptedException {

        Thread.sleep(3000);
        driver.findElement(By.xpath(props.getProperty("clickOnAnyFovAtPlatelet"))).click();
        WebElement updationOfFov = driver.findElement(By.xpath(props.getProperty("fovInputAreaAtPlatelet")));
        updationOfFov.click();
        updationOfFov.clear();
        updationOfFov.sendKeys(props.getProperty("randomFovNumber"));
        driver.findElement(By.xpath(props.getProperty("updateButton"))).click();
        Thread.sleep(1500);
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(props.getProperty("tableContent")))).isDisplayed();
        driver.findElement(By.xpath(props.getProperty("clickOnUpdateButton"))).click();
        Thread.sleep(1000);
        String updatemessage = driver.findElement(By.xpath(props.getProperty("updationMessage"))).getText();
        Thread.sleep(1000);
        driver.findElement(By.xpath(props.getProperty("clickOnClosePopup"))).click();
        Thread.sleep(1000);
        return updatemessage;


    }

    public String plateletRevampingforGaint() throws InterruptedException {
        Thread.sleep(3000);
        driver.findElement(By.xpath(props.getProperty("clickOnAnyFovAtPlatelet"))).click();
        WebElement updationOfFov = driver.findElement(By.xpath(props.getProperty("fovInputAreaAtPlatelet2")));
        updationOfFov.click();
        updationOfFov.clear();
        updationOfFov.sendKeys(props.getProperty("randomFovNumber"));
        driver.findElement(By.xpath(props.getProperty("updateButton"))).click();
        Thread.sleep(1500);
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(props.getProperty("tableContent")))).isDisplayed();
        driver.findElement(By.xpath(props.getProperty("clickOnUpdateButton"))).click();
        Thread.sleep(1000);
        String updatemessage = driver.findElement(By.xpath(props.getProperty("updationMessage"))).getText();
        Thread.sleep(1000);
        driver.findElement(By.xpath(props.getProperty("clickOnClosePopup"))).click();
        Thread.sleep(1000);
        return updatemessage;
    }

    public String plateletRevampingforMacro() throws InterruptedException {
        Thread.sleep(3000);
        driver.findElement(By.xpath(props.getProperty("clickOnAnyFovAtPlatelet"))).click();
        WebElement updationOfFov = driver.findElement(By.xpath(props.getProperty("fovInputAreaAtPlatelet1")));
        updationOfFov.click();
        updationOfFov.clear();
        updationOfFov.sendKeys(props.getProperty("randomFovNumber"));
        driver.findElement(By.xpath(props.getProperty("updateButton"))).click();
        Thread.sleep(1500);
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(props.getProperty("tableContent")))).isDisplayed();
        driver.findElement(By.xpath(props.getProperty("clickOnUpdateButton"))).click();
        Thread.sleep(2000);
        String updatemessage = driver.findElement(By.xpath(props.getProperty("updationMessage"))).getText();
        Thread.sleep(1000);
        driver.findElement(By.xpath(props.getProperty("clickOnClosePopup"))).click();
        Thread.sleep(2000);
        return updatemessage;


    }

    public void plateletRevampingWithZero() throws Exception {
        Thread.sleep(2000);
        props = PropertiesFile.prop;
//        List<WebElement> FovXpath=wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(
//                By.xpath(props.getProperty("PlateletFOVXpath"))));
//        for (WebElement FOVXpath10:FovXpath) {
//            FOVXpath10.click();
        for (int i = 1; i <= 10; i++) {
            List<WebElement> FOVCOunt = driver.findElements(By.xpath(props.getProperty("NMGcount1") + i + (props.getProperty("NMGcount2"))));
            for (WebElement FOVCOunt1 : FOVCOunt) {
                FOVCOunt1.click();
//                    Thread.sleep(2000);
//                    FOVCOunt1.click();
                Thread.sleep(2000);
                FOVCOunt1.clear();
                Thread.sleep(2000);
                FOVCOunt1.clear();
                FOVCOunt1.sendKeys("0");
                Thread.sleep(2000);
                System.out.println(i);
            }
        }

        ShonitRBCReport shonitRBCReport = new ShonitRBCReport(driver);
        shonitRBCReport.updateThereport();

    }


    public String maximumZoomIn() throws InterruptedException {
        props = PropertiesFile.prop;
        Thread.sleep(3000);
        for (int i = 0; i < 32; i++) {
            driver.findElement(By.xpath(props.getProperty("MaximumZoomInXpath"))).click();
            Thread.sleep(1000);
        }
        String popupMessage = driver.findElement(By.xpath(props.getProperty("MaximumZoomInPop"))).getText();

        return popupMessage;
    }

    public String maximumZoomOut() throws InterruptedException {
        props = PropertiesFile.prop;
        Thread.sleep(3000);
        driver.findElement(By.xpath(props.getProperty("MaximumZoomOutXpath"))).click();
        String popupMessage = driver.findElement(By.xpath(props.getProperty("MaximumZoomInPop"))).getText();

        return popupMessage;
    }

    public Boolean clickonpltMorphologyTab() throws InterruptedException {
        return super.clickonTab(props.getProperty("morphology"));
    }

    public String verifyTableHearderOfMorphology() throws InterruptedException {
        Thread.sleep(2000);
        props = PropertiesFile.prop;
        String Header = "";
        List<WebElement> HeaderNames = driver.findElements(By.xpath(props.getProperty("headerXpathMorphology")));
        for (WebElement HeaderName : HeaderNames) {
            Header = Header + HeaderName.getText();
        }
        return Header;
    }


    public Boolean verifyPlateletClumpsDetectedNote() throws InterruptedException {
        props = PropertiesFile.prop;
        boolean flag = false;
        String count = driver.findElement(By.xpath(props.getProperty("CountOFPlateletClump"))).getText();
        if (count != "0")
        {
            driver.navigate().refresh();
            Thread.sleep(2000);
            String Note = driver.findElement(By.xpath(props.getProperty("PlateletclumpDetectedNote"))).getText();
            System.out.println(Note);
//            if (Note.contains("Platelet clumps are detected. Platelet count might be underestimated")) ;
//            {
//                flag = true;
//                clickonpltMorphologyTab();
//            }
            if(Note.contains("Platelet clumps are detected. Platelet count might be underestimated"))
            {
                flag=true;
            }else{
                flag=false;

            }
        } else
        {
            flag = true;
        }
       clickonpltMorphologyTab();
        return flag;
    }





    public String verifyCellsNameOfMorphology() throws InterruptedException
    {
        Thread.sleep(2000);
        props=PropertiesFile.prop;
        String Name="";
        List<WebElement> CellNames = driver.findElements(By.xpath(props.getProperty("MorphologycellName")));
        for (WebElement cellName:CellNames) {
            Name=Name+cellName.getText();
        }
        return Name;
    }
   public boolean verifyGiantPlateltDetectedORnotDedected()
   {
props=PropertiesFile.prop;
       boolean flag=false;
         String count=driver.findElement(By.xpath(props.getProperty("CountOFGiantPlatelet"))).getText();
       String result=driver.findElement(By.xpath(props.getProperty("ResultOfGiantPlatelet"))).getText();

         if (count!="0" && result.equals("Detected") )
         {
             flag=true;
             System.out.println("Giant platelet count and results are verified and count is"+count+" and result is"+result);

         }else if (count.equals("0") && result.equals("Not Detected"))
         {
             flag=true;
             System.out.println("Giant platelet count and results are verified and count is"+count+" and result is"+result);
         }

         return flag;
   }
    public boolean verifyPlateletClumpDetectedORnotDedected()
    {
        props=PropertiesFile.prop;
        boolean flag=false;
        String count=driver.findElement(By.xpath(props.getProperty("CountOFPlateletClump"))).getText();
        String result=driver.findElement(By.xpath(props.getProperty("ResultOfPlateletClump"))).getText();

        if (count!="0" && result.equals("Detected") )
        {
            flag=true;
            System.out.println("platelet clump count and results are verified and count is"+count+" and result is"+result);

        }else if (count.equals("0") && result.equals("Not Detected"))
        {
            flag=true;
            System.out.println("platelet clump count and results are verified and count is"+count+" and result is"+result);
        }

        return flag;
    }

   public String GiantandClumpPlateetNot()
   {
       props=PropertiesFile.prop;
       String Note=driver.findElement(By.xpath(props.getProperty("GiantandClumpPlateletNote"))).getText();
       return Note;

   }

   public boolean verifyTheReferenceImage() throws InterruptedException
   {
       props=PropertiesFile.prop;
       boolean flag=false;

       List<WebElement> CellNames = driver.findElements(By.xpath(props.getProperty("MorphologycellName")));
       for (WebElement cellName:CellNames) {
           int count=0;
           cellName.click();
           Thread.sleep(2000);
       driver.findElement(By.xpath(props.getProperty("RefenceIcon"))).click();
       List<WebElement> referenceImages = driver.findElements(By.xpath(props.getProperty("ReferenceImagesCount")));
      // for (WebElement referenceImage :referenceImages) {
         for (int i=0;i<referenceImages.size();i++)
         {
           count++;
           Thread.sleep(2000);
       }
         System.out.println("count is"+count);
       if(count==4)
           {
               flag=true;
           }else{
           flag=false;
           break;
           }

       }
       return flag;
   }






    public String clickOnRightArrow() throws InterruptedException{
        props = PropertiesFile.prop;
        boolean flag=false;
        String FOVnumbers="";
        for(int i=1;i<10;i++) {
            Thread.sleep(1000);
            String fov=driver.findElement(By.xpath(props.getProperty("platletFOVNumberText"))).getText();
            Thread.sleep(1000);
            String Expected="FOV "+i;
            FOVnumbers=FOVnumbers+fov;
         System.out.println("Expected is"+Expected+"Actual is"+fov);
         driver.findElement(By.xpath(props.getProperty("rightArrow"))).click();
            Thread.sleep(1000);
        }

        return FOVnumbers;
    }





    public boolean verifyGoToNextImage() throws InterruptedException, IOException {

        props = PropertiesFile.prop;
        File scrFile = ((TakesScreenshot) driver).
                getScreenshotAs(OutputType.FILE);

        String current = curDir + "/src/test/java/com/temp/nextimg-current.png";
        FileUtils.copyFile(scrFile, new File(current));
        driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);

        Actions action = new Actions(driver);
        action.moveToElement(driver.findElement(By.xpath(props.getProperty("RightArrow")))).click().build().perform();
        Thread.sleep(3000);

        File scrFile1 = ((TakesScreenshot) driver).
                getScreenshotAs(OutputType.FILE);

        String difference = curDir + "/src/test/java/com/temp/nextimg-difference.png";
        FileUtils.copyFile(scrFile1, new File(difference));

        double differ = imagecomp.getDifferencePercent(current, difference);
        Thread.sleep(3000);
        return differ > 0.0;

    }

    public boolean verifyGoToPrevImage() throws InterruptedException, IOException {

        props = PropertiesFile.prop;
        File scrFile = ((TakesScreenshot) driver).
                getScreenshotAs(OutputType.FILE);

        String current = curDir + "/src/test/java/com/temp/previmg-current.png";
        FileUtils.copyFile(scrFile, new File(current));

        Actions action = new Actions(driver);
        action.moveToElement(driver.findElement(By.xpath(props.getProperty("LeftArrow")))).click().build().perform();
        Thread.sleep(3000);

        File scrFile1 = ((TakesScreenshot) driver).
                getScreenshotAs(OutputType.FILE);

        String difference = curDir + "/src/test/java/com/temp/previmg-difference.png";
        FileUtils.copyFile(scrFile1, new File(difference));

        double differ = imagecomp.getDifferencePercent(current, difference);
        Thread.sleep(3000);
        return differ > 0.0;

    }

    public boolean reclassification(String cell11) throws InterruptedException{
 actions=new Actions(driver);
        props = PropertiesFile.prop;
        driver.findElement(By.xpath(cell11)).click();
        driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
        WebElement element = driver.findElement(By.xpath(props.getProperty("firstPatchImage1")));
        Thread.sleep(3000);
        actions.moveToElement(element).perform();
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath(props.getProperty("clickOnReclassification")))).click();
        driver.manage().timeouts().pageLoadTimeout(10, TimeUnit.SECONDS);
        String textOnEdittab = driver.findElement(By.xpath(props.getProperty("allCellType"))).getText() + ",";
        System.out.println(textOnEdittab);
        return true;
    }
    public Boolean reclassificationOfGaintTOClump(String cell11) throws InterruptedException
    {
        props=PropertiesFile.prop;
        Boolean flag = false;
        String CountOFGiantPlatelet=driver.findElement(By.xpath(props.getProperty("CountOFGiantPlatelet"))).getText();
        int Count=Integer.parseInt(CountOFGiantPlatelet);
        if(Count!=0) {

            String CountOFPlateletClump = driver.findElement(By.xpath(props.getProperty("CountOFPlateletClump"))).getText();
            int Beforecount = Integer.parseInt(CountOFPlateletClump);
            Thread.sleep(2500);
            reclassification(cell11);
            Thread.sleep(2000);
            actions.moveToElement(driver.findElement(By.xpath(props.getProperty("PlateletClumps")))).click().build().perform();

            Thread.sleep(1500);
            wait.until(ExpectedConditions.elementToBeClickable(By.xpath(props.getProperty("updateButton")))).click();
            wait.until(visibilityOfElementLocated(By.xpath(props.getProperty("tableContent")))).isDisplayed();
            int initialValue = Integer.parseInt(driver.findElement(By.xpath(props.getProperty("initialcount"))).getText());
            driver.findElement(By.xpath(props.getProperty("clickOnUpdateButton"))).click();
            wait.until(visibilityOfElementLocated(By.xpath(props.getProperty("updationMessage")))).getText();
            driver.findElement(By.xpath(props.getProperty("clickOnClosePopup"))).click();
            //shonitRBCReport.updateThereport();
            driver.manage().timeouts().pageLoadTimeout(50, TimeUnit.SECONDS);
            // int updatedValue = Integer.parseInt(driver.findElement(By.xpath(props.getProperty("updatedbasophilcount"))).getText());
            Thread.sleep(3000);
            clickonpltMorphologyTab();
            Thread.sleep(3000);
            String CountOFPlateletClump1 = driver.findElement(By.xpath(props.getProperty("CountOFPlateletClump"))).getText();
            int Aftercount = Integer.parseInt(CountOFPlateletClump1);
            System.out.println("Before reclassification count is"+Beforecount);
            System.out.println("After reclassification count is"+Aftercount);
            if (Aftercount == Beforecount + 1) {
                flag = true;
            } else {
                flag = false;
            }
        }else {
            flag=true;
            System.out.println("Count is zero so reclassification was not handled");
        }

           System.out.println("reclassified  happened successfully from Giant Platelet  to Platelet clump  is verified ");

        return flag;
    }

    public Boolean reclassificationOfClumpTOGiant(String cell11) throws InterruptedException
    {
        props=PropertiesFile.prop;

        Boolean flag=false;


        String CountOFGiantPlatelet=driver.findElement(By.xpath(props.getProperty("CountOFPlateletClump"))).getText();
        int Count=Integer.parseInt(CountOFGiantPlatelet);
        if(Count!=0) {

            String CountOFPlateletClump = driver.findElement(By.xpath(props.getProperty("CountOFGiantPlatelet"))).getText();
            int Beforecount = Integer.parseInt(CountOFPlateletClump);
            Thread.sleep(2500);
            reclassification(cell11);
            Thread.sleep(2000);
            actions.moveToElement(driver.findElement(By.xpath(props.getProperty("GiantPlateletNote")))).click().build().perform();

            Thread.sleep(1500);
            wait.until(ExpectedConditions.elementToBeClickable(By.xpath(props.getProperty("updateButton")))).click();
            wait.until(visibilityOfElementLocated(By.xpath(props.getProperty("tableContent")))).isDisplayed();
            int initialValue = Integer.parseInt(driver.findElement(By.xpath(props.getProperty("initialcount"))).getText());
            driver.findElement(By.xpath(props.getProperty("clickOnUpdateButton"))).click();
            wait.until(visibilityOfElementLocated(By.xpath(props.getProperty("updationMessage")))).getText();
            driver.findElement(By.xpath(props.getProperty("clickOnClosePopup"))).click();
            //shonitRBCReport.updateThereport();
            driver.manage().timeouts().pageLoadTimeout(50, TimeUnit.SECONDS);
            // int updatedValue = Integer.parseInt(driver.findElement(By.xpath(props.getProperty("updatedbasophilcount"))).getText());
            Thread.sleep(3000);
            clickonpltMorphologyTab();
            Thread.sleep(3000);
            String CountOFPlateletClump1 = driver.findElement(By.xpath(props.getProperty("CountOFGiantPlatelet"))).getText();
            int Aftercount = Integer.parseInt(CountOFPlateletClump1);
            System.out.println("Before reclassification count is"+Beforecount);
            System.out.println("After reclassification count is"+Aftercount);
            if (Aftercount == Beforecount + 1) {
                flag = true;
            } else {
                flag = false;
            }
        }else {
            flag=true;
            System.out.println("Count is zero so reclassification was not handled");
        }

        System.out.println("reclassified  happened successfully from Giant Platelet  to Platelet clump  is verified ");

        return flag;
    }
    public boolean verifypatcheHeader(String tablepath) throws InterruptedException {
        props = PropertiesFile.prop;
        boolean Cellname = false;
        String ActualCellname1="";
        List<WebElement> rowdata;
        WebElement firstpatch = null;

        List<WebElement> tablerows = wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(
                By.xpath(tablepath)));
        System.out.println(tablepath);
        //for (WebElement cellName:tablerows)
        for(int i=1;i<=tablerows.size()-1;i++)
        // for (int i=0;i<tablerows.size()-2;i++)
//           for (WebElement cellName:tablerows)
        {
            // cellName.click();
            tablerows.get(i).click();
            Thread.sleep(3000);
            String ExpectedCellname=tablerows.get(i).getText();
            WebElement Actualname=driver.findElement(By.xpath(props.getProperty("patchHeader")));
            String ActualCellname=Actualname.getText();

            char[] AA= ActualCellname.toCharArray();
            for(int j=0; j<AA.length-8;j++) {
                ActualCellname1 = ActualCellname1+AA[j];
            }
           // logger.info(ActualCellname1);
            System.out.println("+"+ActualCellname1+"+");
            if(ExpectedCellname.equals(ActualCellname1))
            {
                Cellname=true;
                System.out.println("ExpectedCellname "+ExpectedCellname+":"+ActualCellname1+" ActualCellname");

            }else {
                Cellname=false;
                System.out.println("ExpectedCellname "+ExpectedCellname+" not eqaul"+ActualCellname1+" ActualCellname");
                break;
            }
            ActualCellname1="";
        }
        return Cellname;
    }
    public String clickOnExpandButton() throws InterruptedException {
        props = PropertiesFile.prop;
        WebElement element = driver.findElement(By.xpath(props.getProperty("firstPatchImage1")));
        actions=new Actions(driver);
        actions.moveToElement(element).perform();
        driver.findElement(By.xpath(props.getProperty("clickOnViewFullImage1"))).click();
        WebElement canvasVisibility = wait.until(visibilityOfElementLocated(By.xpath(props.getProperty("ImageVisibility1"))));
        canvasVisibility.isDisplayed();
        Thread.sleep(2000);
        actions.moveToElement(canvasVisibility).build().perform();
        String text = getTextFromElement(By.xpath(props.getProperty("extractedCellText")));
        Thread.sleep(3000);
      String  PlateletCellNameInfullpatch=driver.findElement(By.xpath("//*[@id='label-container']")).getText();
      System.out.println(PlateletCellNameInfullpatch);
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath(props.getProperty("clickOnClose")))).click();
        driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
        return text;
    }

}












