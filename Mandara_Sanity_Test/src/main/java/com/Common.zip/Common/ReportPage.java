package com.Common;

import com.data.Shonit_data.PropertiesFile;
import com.data.MandaraData.ReadMandaraData;

import com.data.ImgDiffPercent;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.*;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.io.*;
import java.util.*;

import java.text.DecimalFormat;
import java.util.concurrent.TimeUnit;

public class ReportPage extends ListReport {

    public Actions actions;
    public Properties props;
    public WebDriver driver;
    public WebDriverWait wait;
    static String reviewerValue;
    public Login login;

    public ReadMandaraData readmandaradata;
    public ImgDiffPercent imagecomp;
    private final Logger logger = LogManager.getLogger(ReportPage.class);
    private static DecimalFormat df = new DecimalFormat("0.00");
    public String selectedrowdetails = "abc";
    String curDir = System.getProperty("user.dir");

    public ReportPage(WebDriver driver) throws Exception {
        super(driver);
        this.driver = driver;
        Actions actions = new Actions(driver);

        props = PropertiesFile.prop;
        PropertiesFile.readMandaraHomePropertiesFile();
        PropertiesFile.readShonitPropertiesFile();
        PropertiesFile.readShonitListReportFile();
        PropertiesFile.readSearchFilterFile();

        int time = Integer.parseInt(props.getProperty("timeout"));
        wait = new WebDriverWait(driver, time);
        readmandaradata = new ReadMandaraData();
        imagecomp = new ImgDiffPercent();
    }

//---------------------------  Verify Shonit Report Page -------------------------------------

    //
    public String openedsampledetails() {
        return this.selectedrowdetails;
    }

    public boolean clickOnSigupleIcon() throws InterruptedException {
        WebElement icon = wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.xpath(props.getProperty("sigtupleicon"))));
        if (icon.isDisplayed()) {
            icon.click();
            WebElement homepage = wait.until(ExpectedConditions.visibilityOfElementLocated(
                    By.xpath(props.getProperty("apptoolbar"))));
            if (homepage.isDisplayed()) {
                Thread.sleep(2000);
                logger.info("Clicked on sigtuple icon and home page loaded ");
                return true;
            }
        }
        return false;
    }


    public boolean searchSampelID(String product) throws InterruptedException {
        props = PropertiesFile.prop;
        Thread.sleep(1000);
        driver.findElement(By.xpath(props.getProperty("menuCard"))).click();
        Thread.sleep(1000);
        driver.findElement(By.xpath(props.getProperty("shonitCard"))).click();
        Thread.sleep(1000);
        WebElement searchicon1 = driver.findElement(By.xpath("//i[@class='material-icons hide-search-icon ng-star-inserted']"));
        // WebElement searchicon1 = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(props.getProperty("searchicon"))));
        boolean status = false;
        if (searchicon1.isDisplayed()) {
            searchicon1.click();
            WebElement searchicon = driver.findElement(By.xpath("//div//input[contains(@class,'search-input')]"));
            searchicon.click();
            searchicon.clear();
            driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
            searchicon.sendKeys(props.getProperty("searchSampleID"));
            Thread.sleep(1000);
            searchicon.sendKeys(Keys.ENTER);
            Thread.sleep(2500);
            String statusText = "//table[@role='grid']//tbody//tr[1]//td[4]";
            driver.findElement(By.xpath(statusText)).click();
            Thread.sleep(2000);
        }

        return true;
    }

    public String reportPageHeader() {
        props = PropertiesFile.prop;
        String headerText = driver.findElement(By.xpath(props.getProperty("reportHeader"))).getText();
        System.out.println(headerText);
        return headerText;
    }


    public String pbsReportHeader() {
        props = PropertiesFile.prop;
        List<WebElement> pbsReportHeadings = driver.findElements(By.xpath("//section[@id='otherMetrics']//table//thead//tr//th"));
        String header = "";
        for (WebElement pbsReportHeading : pbsReportHeadings) {
            header = header + (pbsReportHeading.getText()) + ",";
        }
        System.out.println(header);
        return header;
    }

    public String getListOfReportName() {
        props = PropertiesFile.prop;
        List<WebElement> allReportName = driver.findElements(By.xpath(props.getProperty("allreportname")));
        String reportsName = "";
        for (WebElement allReportNames : allReportName) {
            reportsName = reportsName + (allReportNames.getText()) + ",";
        }
        System.out.println(reportsName);
        return reportsName;
    }

    //Verify the presence of Update approve reject button
    public String reportAccessibilityButton() throws InterruptedException {
        props = PropertiesFile.prop;
        Thread.sleep(3000);
        //driver.manage().timeouts().implicitlyWait(50,TimeUnit.SECONDS);
        List<WebElement> allButtons = driver.findElements(By.xpath(props.getProperty("accessibilityButton")));
        String allConatiners = "";
        for (WebElement allButton : allButtons) {
            allConatiners = allConatiners + (allButton.getText()) + ",";
        }
        System.out.println(allConatiners);
        return allConatiners;
    }


    public int additionOfAllValue() {
        props = PropertiesFile.prop;
        // List<WebElement> elements=driver.findElements(By.tagName("tr"));
        int sum = 0;
        double DoubleValue;
        List<WebElement> elements = driver.findElements(By.tagName("tr"));
        for (int i = 1; i <= elements.size() - 1; i++) {
            WebElement allValue = (WebElement) driver.findElements(By.xpath("//section[@id='otherMetrics']//table//tbody//tr[" + i + "]//td[2]"));
            String valueCount = allValue.getText();
            DoubleValue = Double.parseDouble(valueCount);
            sum = (int) (sum + DoubleValue);

        }
        System.out.println("Total Sum : " + sum);

        return sum;
    }


    public String psImpressiontHeader() {
        props = PropertiesFile.prop;
        List<WebElement> psImpressionHeadings = driver.findElements(By.xpath(props.getProperty("psImpressionHeader")));
        String header = "";
        for (WebElement psimpressionHeading : psImpressionHeadings) {
            header = header + (psimpressionHeading.getText()) + ",";
        }
        System.out.println(header);
        return header;
    }

    public String ListOfPSImpressiontName() {
        props = PropertiesFile.prop;
        List<WebElement> psImpressionName = driver.findElements(By.xpath(props.getProperty("psImpressionName")));
        String name = "";
        for (WebElement allPsImpressionName : psImpressionName) {
            name = name + (allPsImpressionName.getText()) + ",";
        }
        System.out.println(name);
        return name;
    }


    public String getFirstImpressionComment() throws InterruptedException {
        props = PropertiesFile.prop;
        Thread.sleep(2000);
        WebElement firstFiled = driver.findElement(By.xpath(props.getProperty("FirstImpressionField")));
        firstFiled.click();
        firstFiled.clear();
        firstFiled.sendKeys("TESTING");
        firstFiled.sendKeys(Keys.ENTER);
        // firstFiled.clear();
        driver.findElement(By.xpath(props.getProperty("updateButton"))).click();
        String message = driver.findElement(By.xpath(props.getProperty("message"))).getText();
        driver.findElement(By.xpath(props.getProperty("ClosePopUp"))).click();
        driver.manage().timeouts().implicitlyWait(25, TimeUnit.SECONDS);
        return message;
    }

    public String getCorrectValue() throws InterruptedException {
        props = PropertiesFile.prop;
        WebElement correctField = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(props.getProperty("correctionField"))));
        correctField.click();
        correctField.clear();
        correctField.sendKeys("100");
        correctField.sendKeys(Keys.ENTER);
        // correctField.clear();
        driver.findElement(By.xpath(props.getProperty("updateButton"))).click();
        String message = driver.findElement(By.xpath(props.getProperty("message"))).getText();
        driver.findElement(By.xpath(props.getProperty("ClosePopUp"))).click();

        Thread.sleep(4000);
        String value = correctField.getAttribute("class");
        System.out.println(value);

        // driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
        return message;
    }

    public String reassignmentdetails() {
        props = PropertiesFile.prop;
        String reassignment = driver.findElement(By.xpath(props.getProperty("reassignment"))).getText() + "";
        System.out.println(reassignment);
        return reassignment;
    }

    public boolean reassingedWithDifferentUsers() throws InterruptedException {
        props = PropertiesFile.prop;
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath(props.getProperty("addAssignee")))).click();
        Thread.sleep(1000);
        List<WebElement> reviewerNames = driver.findElements(By.cssSelector(props.getProperty("dropdownvalues")));
        for (WebElement reviewerName : reviewerNames) {
            reviewerValue = reviewerName.getText().trim();
            if (reviewerValue.startsWith(props.getProperty("username3"))) {
                reviewerName.click();
                break;
            }
        }
        WebElement comment = driver.findElement(By.xpath(props.getProperty("comment")));
        comment.click();
        comment.clear();
        comment.sendKeys(props.getProperty("comments"));
        comment.sendKeys(Keys.ENTER);
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath(props.getProperty("reassign")))).click();
        Thread.sleep(3000);
        // driver.findElement(By.xpath(props.getProperty("saveChangeButton"))).click();

        return true;
    }


    public boolean downloadsCSVReport() {
        props = PropertiesFile.prop;
        driver.findElement(By.xpath(props.getProperty("download"))).click();
        Actions actions1 = new Actions(ReportPage.this.driver);
        actions1.moveToElement(driver.findElement(By.xpath(props.getProperty("CSVReport")))).click().build().perform();
        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
        return true;
    }

    public String downloadReport() throws InterruptedException {
        props = PropertiesFile.prop;
        Thread.sleep(2000);
        WebElement download = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(props.getProperty("download"))));
        download.click();
        String reportFormat = driver.findElement(By.xpath(props.getProperty("downloadContent"))).getText();
        Actions actions1 = new Actions(ReportPage.this.driver);
        actions1.moveToElement(download).click().build().perform();
        return reportFormat;
    }


    public String originalReport() {
        props = PropertiesFile.prop;
        String original = driver.findElement(By.xpath(props.getProperty("originalReport"))).getText();
        System.out.println(original);
        // driver.findElement(By.xpath("//span[@class='mat-option-text'][normalize-space()='Modified']")).click();
        return original;
    }


    public String auditLog() throws InterruptedException {
        props = PropertiesFile.prop;
        Thread.sleep(1000);
        String auditLog = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(props.getProperty("auditLog")))).getText();
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath(props.getProperty("auditLog")))).click();
        Thread.sleep(3800);
        String productVersion = driver.findElement(By.xpath(props.getProperty("auditLogsHeader"))).getText();
        System.out.println(productVersion);
        Thread.sleep(1000);
        driver.findElement(By.xpath(props.getProperty("backToReport"))).click();
        //Thread.sleep(1000);
        ////i[normalize-space()='keyboard_backspace']
        return auditLog;
    }

    public String verifySlideID() {
        props = PropertiesFile.prop;
        String SlideID = wait.until(
                ExpectedConditions.visibilityOfElementLocated(
                        By.xpath(props.getProperty("sample_id")))).getText();
        return SlideID;
    }

    public String verifyslidedetails() throws InterruptedException {
        Thread.sleep(1000);
        String slidedetails = "";
        WebElement slidedropdown = wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.xpath(props.getProperty("slideDetails"))));
        slidedropdown.click();
        Thread.sleep(3000);
        String Description = wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.xpath(props.getProperty("Description")))).getText();
        String SubmitedBy = wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.xpath(props.getProperty("SubmitedBy")))).getText();
        String ScanMode = wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.xpath(props.getProperty("ScanMode")))).getText();
        String productversion = wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.xpath(props.getProperty("productversion")))).getText();
        String SubmittedAt = wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.xpath(props.getProperty("SubmittedAt")))).getText();
        slidedetails = Description + SubmitedBy + ScanMode + productversion + SubmittedAt;
        return slidedetails;

    }


    //change version from modified to original
    public Boolean changeVersion() throws Exception {
        props = PropertiesFile.prop;
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(props.getProperty("version")))).click();
        Thread.sleep(1000);
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(props.getProperty("versionoriginal")))).click();
        Thread.sleep(1000);
        String version = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(props.getProperty("version")))).getText();
        return version.contains("Original");
    }


    public boolean verifyReportPage() throws InterruptedException {
        props = PropertiesFile.prop;
        return wait.until(
                ExpectedConditions.visibilityOfElementLocated(
                        By.cssSelector(props.getProperty("cardonReportpage")))).isDisplayed();
    }

    //fetches sample details header value
    public String getSampleDetailsHeader() {
        props = PropertiesFile.prop;
        String headers = "";
        List<WebElement> sampledetailsheader = driver.findElements(
                By.xpath(props.getProperty("sampledetailheader")));
        for (int i = 0; i < sampledetailsheader.size(); i++) {
            String text = sampledetailsheader.get(i).getText().trim();

        }
        return headers;
    }

    //
    public boolean verifysampleDetailAtReportPage() throws InterruptedException {
        props = PropertiesFile.prop;
        System.out.println(selectedrowdetails);
        Thread.sleep(1000);
        List<WebElement> sampledetails = driver.findElements(
                By.xpath(props.getProperty("selectedsampledetail")));
        for (int i = 0; i < sampledetails.size(); i++) {
            String text = sampledetails.get(i).getText().trim();
            System.out.println(text);
            if (selectedrowdetails.contains(text)) ;
            else
                return false;
        }
        return true;
    }


    // get Desclaimer
    public String getDesclaimer() {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.xpath(props.getProperty("desclaimer")))).getText();
    }

    //fetch status container labels
    public String getStatusContainers() {
        props = PropertiesFile.prop;
        String labels = "";
        List<WebElement> sampledetailsheader = wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(
                By.cssSelector(props.getProperty("statuscontainer"))));

        for (WebElement sampledetailarray : sampledetailsheader)
            labels = labels + sampledetailarray.getText();
        System.out.println(labels);
        return labels;
    }

    //fetch status container labels
    public String getStatusContainersColors() {
        props = PropertiesFile.prop;
        String colors = "";
        List<WebElement> sampledetailsheader = wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(
                By.cssSelector(props.getProperty("statuscontainer") + " i")));

        for (WebElement sampledetailarray : sampledetailsheader)
            colors = colors + sampledetailarray.getAttribute("class").trim() + " ";
        System.out.println(colors);
        return colors;
    }

    //visibility of export button
    public boolean visibilityOfExportButton() throws InterruptedException {
        props = PropertiesFile.prop;
        WebElement export = wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath(props.getProperty("export"))));
        if (export.isEnabled()) {
            logger.info("export button is visible at top of the report page");
            return true;
        }
        logger.info("export button is not visible or not clickable at top of the page");
        return false;
    }

    //visibility of export button
    public String verifyOptionsInExportButton() throws InterruptedException {
        props = PropertiesFile.prop;
        String options = "";
        WebElement export = wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath(props.getProperty("export"))));
        if (export.isEnabled()) {
            export.click();
            Thread.sleep(2000);
            options = wait.until(ExpectedConditions.visibilityOfElementLocated(
                    By.xpath(props.getProperty("listofexportoptions")))).getText();
            Actions action = new Actions(driver);
            action.moveToElement(export).click().build().perform();
        }
        //logger.info("list of options : "+options);
        return options;
    }

    //fetch all tabs on Report page
    public String getAllTabs() {
        props = PropertiesFile.prop;
        String labels = "";
        List<WebElement> sampledetailsheader = wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(
                By.cssSelector(props.getProperty("alltabs"))));

        for (WebElement sampledetailarray : sampledetailsheader)
            labels = labels + sampledetailarray.getText();
        return labels;
    }

    //fetch selected tabs on Report page
    public String getSelectedTab() {
        props = PropertiesFile.prop;
        String labels = "";
        List<WebElement> sampledetailsheader = wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(
                By.xpath(props.getProperty("currentselectedtab"))));

        for (WebElement sampledetailarray : sampledetailsheader)
            labels = labels + sampledetailarray.getText();
        return labels;
    }

// ----------------------------------- Globle Methods ------------------------

    //Verify sample assignee to the Reviewer
    public Boolean assigneAndOpenReport() throws Exception {
        props = PropertiesFile.prop;
        boolean status = false;
        int i = 1;
        String reportstatus = "Assigned, Report Updated, Report Generated, Rejected";
        String table = props.getProperty("tablelocation");
        String status_text = props.getProperty("status_text");
        String status_path = "";
        Thread.sleep(2000);
        selectedrowdetails = "";
        List<WebElement> tableheaders = wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.cssSelector(props.getProperty("tableheader"))));
        int k = tableheaders.size() - 1;

        WebElement button = wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(props.getProperty("assign"))));
        int assignindex = super.findcolumnNumber(button);

        while (true) {
            status_path = table + String.valueOf(i) + "]/td[" + String.valueOf(k) + status_text;
            String statustext = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(status_path))).getText();
            if (reportstatus.contains(statustext)) {
                Thread.sleep(1000);
                selectedrowdetails = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(status_path + props.getProperty("rowalldata")))).getText();
                String temp_path = table + String.valueOf(i) + "]/td[" + String.valueOf(assignindex) + props.getProperty("selectassignee");
                wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(temp_path))).click();
                List<WebElement> reviewerlist = wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.cssSelector(props.getProperty("reviewers"))));
                for (int j = 0; j < reviewerlist.size(); j++) {
                    if (reviewerlist.get(j).getText().toLowerCase().contains(props.getProperty("reviewer1").toLowerCase()) ||
                            reviewerlist.get(j).getText().toLowerCase().contains(props.getProperty("reviewer2").toLowerCase())) {
                        reviewerlist.get(j).click();
                        status = true;
                        break;
                    }
                }
            }
            if (status) break;
            i++;
            if (i > 10) {
                i = 1;
                String expected_path = props.getProperty("chevronicon") + "[2]";
                wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(expected_path))).click();
                Thread.sleep(5000);
            }
        }
        // open sample report page for assigend sample to the reviewer
        if (status) {
            Thread.sleep(1000);
            Actions action = new Actions(driver);

            WebElement sample = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(status_path)));
            sample.click();
            Thread.sleep(2000);
        }
        status = wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(props.getProperty("cardonReportpage")))).isDisplayed();
        Thread.sleep(5000);
        System.out.println(this.selectedrowdetails);
        return status;
    }


    public boolean clickOnFirstSample() throws InterruptedException {
        props = PropertiesFile.prop;
        Thread.sleep(2000);
        driver.findElement(By.xpath("//table[@role='grid']//tbody//tr[1]//td[4]")).click();
        Thread.sleep(3000);
        driver.findElement(By.xpath(props.getProperty("addAssignee"))).click();
        Thread.sleep(1000);
        List<WebElement> reviewerNames = driver.findElements(By.cssSelector(props.getProperty("dropdownvalues")));
        for (WebElement reviewerName : reviewerNames) {
            reviewerValue = reviewerName.getText().trim();
            if (reviewerValue.startsWith(props.getProperty("username3"))) {
                reviewerName.click();
                break;
            }
        }
        return true;
    }






    /* String text = "Add Assignee";
            List<WebElement> assignee = driver.findElements(By.xpath("//tbody//tr//span[text()='Report Generated']"));
            // /preceding::td[1]//following-sibling::div//div//mat-select//span
            for (int i = 1; i<assignee.size(); i = i + 2) {
                if (assignee.get(i).getText().equals(text)) {
                    String firstRowOfAddAssignee = "//tbody//tr['" + i + "']//span[text()='Report Generated']";
                    // /preceding::td[1]//following-sibling::div//div//mat-select//span
                    driver.findElement(By.xpath(firstRowOfAddAssignee)).click();
                    break;
                }
            }
            List<WebElement> reviewerNames = driver.findElements(By.cssSelector(props.getProperty("dropdownvalues")));
            Thread.sleep(2000);
            for (WebElement reviewerName : reviewerNames) {
                reviewerValue = reviewerName.getText().trim();
                if (reviewerValue.startsWith(props.getProperty("reviewrName"))) {
                    reviewerName.click();
                    Thread.sleep(2000);
                   // String statusText = "//table[@role='grid']//tbody//tr[1]//td[4]";
                    // String statusText= "//tbody//tr//span[text()='Assigned']/preceding::td[3]";
                    driver.findElement(By.xpath(statusText)).click();
                    break;
                }
            }
            return true;
        }*/


    //Click on PLT Tab
    public Boolean clickonTab(String tabname) throws InterruptedException {
        props = PropertiesFile.prop;
        Thread.sleep(2000);
        try {
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(tabname))).click();
            logger.info("clicked on tab");

            return true;
        } catch (Exception e) {
            return false;
        }
    }


    public String clickOnExpandButton() throws InterruptedException {
        props = PropertiesFile.prop;
        WebElement element = driver.findElement(By.xpath(props.getProperty("firstPatchImage")));
        actions.moveToElement(element).perform();
        driver.findElement(By.xpath(props.getProperty("clickOnViewFullImage"))).click();
        driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
        WebElement canvasVisibility = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(props.getProperty("ImageVisibility"))));
        canvasVisibility.isDisplayed();
        Thread.sleep(2000);
        actions.moveToElement(canvasVisibility).build().perform();
        String text = driver.findElement(By.xpath(props.getProperty("extractedCellText"))).getText();
        driver.findElement(By.xpath(props.getProperty("clickOnClose"))).click();
        driver.manage().timeouts().pageLoadTimeout(10, TimeUnit.SECONDS);
        return text;
    }

    //Get list of rows in RBC Color
    public String gettablerows(String tablepath) throws InterruptedException {
        props = PropertiesFile.prop;
        String labels = "";
        List<WebElement> tablerows = wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(
                By.xpath(tablepath)));
        for (int i = 1; i <= tablerows.size(); i++) {
            List<WebElement> rowdata = wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(
                    By.xpath(tablepath + "[" + String.valueOf(i) + "]/td")));
            labels = labels + rowdata.get(0).getText().trim() + ";";
        }
        return labels;
    }


    //Get total percentage and Total Counts
    public boolean verifyTotalPercentageAndCount(String tabletype) throws InterruptedException {
        props = PropertiesFile.prop;
        List<WebElement> tablerows = wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(
                By.xpath(tabletype)));
        float total_per = 0, expected_total = 0;
        int total_count = 0, expected_count = 0;
        for (int i = 1; i <= tablerows.size(); i++) {
            try {
                List<WebElement> rowdata = wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(
                        By.xpath(tabletype + "[" + String.valueOf(i) + "]/td")));
                String key = rowdata.get(0).getText().trim();
                int count = Integer.valueOf(rowdata.get(1).getText().trim());
                float percentage = Float.valueOf(rowdata.get(2).getText().trim().split("%")[0]);
                if (key.contains("TOTAL")) {
                    expected_total = percentage;
                    expected_count = count;
                    break;
                }
                total_per = total_per + percentage;
                total_count = total_count + count;
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        total_per = Float.valueOf(df.format(total_per));
        logger.info("Total Percentage : " + String.valueOf(total_per) + " : " + String.valueOf(expected_total));
        logger.info("Total Counts : " + String.valueOf(total_count) + " : " + String.valueOf(expected_count));
        if (total_per == expected_total && total_count == expected_count)
            return true;
        return false;
    }


    public boolean verifyDefauldLandingPage() throws InterruptedException {
        WebElement tabs = wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.xpath(props.getProperty("currentselectedtab"))));
        if (tabs.isDisplayed() && tabs.getText().contains("Summary"))
            return true;
        return false;
    }


    //verify list of patches and it size
    public boolean findpatchrelatedresult(int count) throws InterruptedException {
        props = PropertiesFile.prop;
        int patchsize = 0;
        int refsize = 0;
        int totalpatches = 0;
        int patchinfirst = 0;
        Thread.sleep(2000);
        //String patchheader = wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(props.getProperty("patchheader")))).getText();
        try {
            for (int i = 0; i <= 5; i++) {
                patchsize = driver.findElements(By.cssSelector(props.getProperty("listofpatches"))).size();
                if (patchsize == 12)
                    break;
                Thread.sleep(1000);
            }
        } catch (Exception e) {
        }
        try {
            for (int i = 0; i < 5; i++) {
                refsize = driver.findElements(By.cssSelector(props.getProperty("refimages"))).size();
                if (refsize == 4)
                    break;
                Thread.sleep(1000);
            }
        } catch (Exception e) {
        }
        try {
            String temp_data = wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(props.getProperty("totalpatch")))).getText();
            String[] arrOfStr = temp_data.split("of", 2);
            totalpatches = Integer.valueOf(arrOfStr[1].trim());
            patchinfirst = Integer.valueOf(arrOfStr[0].split("-", 2)[1].trim());
        } catch (Exception e) {
        }
        System.out.println(totalpatches + " : " + String.valueOf(patchsize) + " : " + String.valueOf(refsize));
        if (patchinfirst == patchsize && (totalpatches == count || totalpatches == 100) && refsize == 4)
            return true;
        return false;
    }


    public boolean verifypatches(String tablepath) throws InterruptedException {
        props = PropertiesFile.prop;
        Thread.sleep(3000);
        boolean status = false;
        List<WebElement> tablerows = wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(
                By.xpath(tablepath)));
        List<WebElement> rowdata;
        WebElement firstpatch = null;
        boolean fullfov = true;
        for (int i = 1; i <= tablerows.size(); i++) {
            try {
                rowdata = wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(
                        By.xpath(tablepath + "[" + String.valueOf(i) + "]/td")));
                System.out.println(rowdata);
                String key = rowdata.get(0).getText().trim();
                System.out.println("key value is " + key);
                String image = rowdata.get(rowdata.size() - 1).getText().trim();
                System.out.println("The image string contains " + image);
                if (image.contains("collections")) {
                    firstpatch = rowdata.get(rowdata.size() - 1);
                    System.out.println("1st patch x path " + firstpatch);
                    firstpatch.click();
                    String patchheader = wait.until(ExpectedConditions.visibilityOfElementLocated(
                            By.cssSelector(props.getProperty("patchheader")))).getText();
                    if (patchheader.equalsIgnoreCase(key) || patchheader.toLowerCase().contains(key.substring(0, 2).toLowerCase())) {
                        if (patchheader.contains("collection"))
                            System.out.println(key + " : " + patchheader.split(" ")[1]);
                        else
                            System.out.println(key + " : " + patchheader);
                    } else {
                        logger.info(key + " : for this row table name and patch header is not matching");
                        status = status && false;
                    }
                    Thread.sleep(2000);
                    status = this.findpatchrelatedresult(Integer.valueOf(rowdata.get(1).getText().trim()));
                    if (fullfov) {
                        if (this.checkfullfov()) {
                            logger.info(key + " : show image in full FOV is verified");
                            fullfov = false;
                        } else
                            logger.info(key + " : failed to show image in full FOV");
                    }
                    if (!status && !key.contains("Unclassified"))
                        break;
                }
            } catch (Exception e) {
            }
        }
        firstpatch.click();
        return status && !fullfov;
    }

    public boolean checkfullfov() throws InterruptedException {
        List<WebElement> listofpatches = wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.cssSelector(props.getProperty("listofpatches"))));
        if (listofpatches.size() == 0)
            return false;
        boolean status = false;
        Actions action = new Actions(driver);
        action.moveToElement(listofpatches.get(0)).build().perform();
        Thread.sleep(2000);
        WebElement imgloc = driver.findElement(By.cssSelector(props.getProperty("getfirstpatch")));
        action.moveToElement(imgloc).build().perform();
        WebElement patchDispSrcOpen = wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(props.getProperty("Displaypatch"))));
        action.moveToElement(patchDispSrcOpen).click().build().perform();
        //System.out.println("clicked on first patch");
        try {
            WebElement displycanvas = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(props.getProperty("displycanvas"))));
            if (displycanvas.isDisplayed()) {
                Thread.sleep(2000);
                wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(props.getProperty("dispsrcclose")))).click();
                status = true;
            }
        } catch (Exception e) {
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(props.getProperty("dispsrcclose")))).click();
            status = false;
        }
        return status;
    }

    //verify grading in diff tables
    public boolean verifyGrading(Map<String, Map<String, String>> tabledata, String filename) throws Exception {
        props = PropertiesFile.prop;
        Map<String, String> ShonitRefData = readmandaradata.ReadCSVFile(filename);
        System.out.println(ShonitRefData);

        boolean status = true;
        Set setofKeys = tabledata.keySet();
        Iterator itr = setofKeys.iterator();
        while (itr.hasNext()) {
            String key = (String) itr.next();
            if (key.equalsIgnoreCase("TOTAL"))
                continue;
            Map<String, String> value = tabledata.get(key);
            if (!value.keySet().contains("Grading")) {
                logger.info("Grading colums is not availabe for this table ");
                return false;
            }
            if (value.get("Percentage").length() == 0) {
                logger.info(key + " : this row is not having any percentage value");
                continue;
            }
            float percentage = Float.valueOf(value.get("Percentage").split("%")[0].trim());
            String grading = value.get("Grading").trim();
            if (grading.length() == 0) {
                logger.info(key + " : this row is not having grading ");
                status = status && false;
                continue;
            }
            String ref = ShonitRefData.get(key);
            float startvalue = Float.valueOf(ref.split("-")[0].trim());
            float endvalue = Float.valueOf(ref.split("-")[1].trim());
            System.out.println(String.valueOf(startvalue) + " : " + String.valueOf(endvalue) + " : " + String.valueOf(percentage) + " : " + grading);
            if ((percentage < startvalue && grading.equalsIgnoreCase("+")) ||
                    (percentage > endvalue && grading.equalsIgnoreCase("+++")) ||
                    (percentage >= startvalue && percentage <= endvalue && grading.equalsIgnoreCase("++"))) {
                logger.info(key + " : is passed in grading validation");
            } else {
                status = status && false;
                logger.info(key + " : is failed in grading validation");
            }

        }
        return status;
    }


    //Get list of rows in External metrics
    public Map<String, Map<String, String>> collectTableData(String rowpath, String headerpath) throws InterruptedException {
        props = PropertiesFile.prop;
        Map<String, Map<String, String>> tabledata = new HashMap<String, Map<String, String>>();
        List<WebElement> tablerows = wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(
                By.xpath(rowpath)));
        List<WebElement> tablecol = wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(
                By.xpath(headerpath)));

        Map<Integer, String> head_map = new HashMap<Integer, String>();
        for (int i = 0; i < tablecol.size(); i++) {
            System.out.println(tablecol.get(i).getText().trim());
            head_map.put(i, tablecol.get(i).getText().trim());
        }

        for (int i = 1; i <= tablerows.size(); i++) {
            try {
                List<WebElement> rowdata = wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(
                        By.xpath(rowpath + "[" + String.valueOf(i) + "]/td")));
                String key = rowdata.get(0).getText().trim();
//        		if(key.toLowerCase().contains("total")) {
//        			status=true;
//        			break;
//        		}
                Map<String, String> temprowmap = new HashMap<String, String>();
                for (int j = 1; j < rowdata.size(); j++)
                    temprowmap.put(head_map.get(j), rowdata.get(j).getText().trim());
                tabledata.put(key, temprowmap);

            } catch (Exception e) {
            }
        }

        //---printing map data
        Set setofKeys = tabledata.keySet();
        Iterator itr = setofKeys.iterator();
        while (itr.hasNext()) {
            String key = (String) itr.next();
            Map<String, String> value = tabledata.get(key);
            Set setofKeys1 = value.keySet();
            Iterator itr1 = setofKeys1.iterator();
            System.out.println("key : " + key);
            while (itr1.hasNext()) {
                String key1 = (String) itr1.next();
                System.out.println("\t" + key1 + " : " + value.get(key1));
            }
            System.out.println();
        }

        return tabledata;
    }

    //verify left/right icon to change the images
    public boolean verifychangeinaction(String source, String nextpoint) throws Exception {
        props = PropertiesFile.prop;
        WebElement preview = wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.cssSelector(source)));
        File scrFile = ((TakesScreenshot) preview).getScreenshotAs(OutputType.FILE);

        String curr = curDir + "/src/test/java/com/Screenshot/before.png";
        FileUtils.copyFile(scrFile, new File(curr));
        Thread.sleep(2000);
        wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.cssSelector(nextpoint))).click();

        Thread.sleep(5000);

        File scrFile1 = ((TakesScreenshot) preview).
                getScreenshotAs(OutputType.FILE);

        String difference = curDir + "/src/test/java/com/Screenshot/after.png";
        FileUtils.copyFile(scrFile1, new File(difference));
        double differ = imagecomp.getDifferencePercent(curr, difference);
        return differ > 0.0;
    }


    public void getLoadedSampleData(String product) throws Exception {
        props = PropertiesFile.prop;
        String sample_id = wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.xpath(props.getProperty("sample_id")))).getText().trim();
        String sample_des = wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.xpath(props.getProperty("sample_des")))).getText().trim();
        String date = wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.xpath(props.getProperty("sample_date")))).getText().trim();
        date = date.replace(" ", "#");
        String workingdir = System.getProperty("user.dir");
        String dataoutput = workingdir + "/PythonFiles/" + product;

        String env = props.getProperty("Environment");
        String command = "python3 " + workingdir + "/PythonFiles/" + product + "/get_sample_data.py --Sample \'" + sample_id + "\' --Des \'" + sample_des + "\' --Date " + date + " --Output " + dataoutput + " --Env " + env;

        try {
            FileWriter f = new FileWriter(workingdir + "/PythonFiles/" + product + "/sample_details.txt");
            BufferedWriter b = new BufferedWriter(f);
            PrintWriter p = new PrintWriter(b);
            p.print(command);
            p.flush();
            p.close();
        } catch (IOException i) {
            i.printStackTrace();
        }

        try {
            FileWriter f = new FileWriter(workingdir + "/PythonFiles/" + product + "/capturedFOV.txt");
            BufferedWriter b = new BufferedWriter(f);
            PrintWriter p = new PrintWriter(b);
            String capturedimages = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(props.getProperty("capturedimages")))).getText().trim();
            p.print(capturedimages);
            p.flush();
            p.close();
        } catch (IOException i) {
            i.printStackTrace();
        }
    }

    public String clickOnMainCell(String cellname) {
        props = PropertiesFile.prop;

        try {
                   /* List<WebElement> counts=driver.findElements(By.xpath("//button[normalize-space()='Myelocytes']"));
                    for(WebElement count:counts){
                        int i = 0;
                       // if(counts.get(i).getText().contains("0")){*/
            driver.findElement(By.xpath(cellname)).click();
            logger.info("clicked on main cell on wbc tab");
        } catch (Exception e) {
        }
        return driver.findElement(By.xpath(props.getProperty("cellnameonpatch"))).getText();
    }

    public boolean createCSVFortable(String product, Map<String, Map<String, String>> tabledata, String tablename, ArrayList<String> columns) throws Exception {
        /*
         * if you are going to start with new product , please create folder structure as follows :
         * PythonFiles/"+product+"/MandaraFile
         * PythonFiles/"+product+"/DBFile
         * PythonFiles/"+product+"/dataTemplet
         */
        Map<String, String> csvdata = new HashMap<String, String>();
        try {
            Set setofKeys = tabledata.keySet();
            Iterator itr = setofKeys.iterator();

            String workingdir = System.getProperty("user.dir");
            String dataoutput = workingdir + "/PythonFiles/" + product + "/MandaraFile";
            FileWriter csvWriter = new FileWriter(dataoutput + "/" + tablename + ".csv");
            csvWriter.append("Mandara");
            csvWriter.append(",");
            csvWriter.append("Mandara-Value");
            csvWriter.append("\n");

            while (itr.hasNext()) {
                String key = (String) itr.next();
                Map<String, String> value = tabledata.get(key);
                for (String col : columns) {

                    String inputkey = key + "-" + col;
                    String inputvalue = "";
                    if (col.contentEquals("Percentage"))
                        inputvalue = value.get(col).split("%")[0].trim();
                    else
                        inputvalue = value.get(col);
                    System.out.println(inputkey + " : " + inputvalue);
                    csvdata.put(inputkey, inputvalue);
                    csvWriter.append(inputkey + "," + inputvalue);
                    csvWriter.append("\n");
                }
            }
            csvWriter.flush();
            csvWriter.close();
            try {
                this.getLoadedSampleData(product);
            } catch (Exception e) {
            }
            return true;
        } catch (Exception e) {
            return false;
        }
    }
//    public WebElement webAction(final By locator) {     //this is fluent wait
//        Wait<WebDriver> wait = new FluentWait<WebDriver>(driver)
//                .withTimeout(Duration.ofSeconds(100)) // max time
//                .pollingEvery(Duration.ofSeconds(5)) // every 5 seconds
//                .ignoring(NoSuchElementException.class)
//                .ignoring(StaleElementReferenceException.class)
//                .ignoring(ElementClickInterceptedException.class)
//                .ignoring(ElementNotInteractableException.class)
//                .ignoring(Throwable.class)
//                .withMessage(
//                        "Webdriver waited for 50 seconds but still could not find the element therefore Timeout Exception has been thrown");
//
//        return wait.until(new Function<WebDriver, WebElement>() {
//            public WebElement apply(WebDriver driver1) {
//                return driver1.findElement(locator);
//            }
//        });
//    }


    // this method is use for display the title
    public String waitForTitleDisplay(String title) {
        new WebDriverWait(driver, 20).until(ExpectedConditions.titleIs(title));
        return title;
    }
   /*
    public boolean elementToBeClick(WebDriver driver, WebElement elementToBeClicked)
    {

        try{

            elementToBeClicked.click();

            return true;
        }
        catch(Exception e){

            return false;
        }

    }*/

    public WebElement waitForElementToDisplay(By locator) {
        try {

            return new WebDriverWait(driver, 80).until(ExpectedConditions.presenceOfElementLocated(locator));
        } catch (Exception e) {
            e.printStackTrace();
        }

        return null;
    }


    public Boolean waitForElementNotDisplay(By locator) {
        try {
            return new WebDriverWait(driver, 20).until(ExpectedConditions.not(ExpectedConditions.visibilityOfAllElementsLocatedBy(locator)));
        } catch (Exception e) {
            e.printStackTrace();
        }

        return null;
    }

    public void doClick(By locator) {
        waitForElementToDisplay(locator).click();
    }

    public void doClick(WebElement element) {
        element.click();
    }

    public void enterText(WebElement element, String text) {
        element.sendKeys(text);
    }

    public void clickOnLink(String text) {

        driver.findElement(By.linkText(text)).click();

    }

    public void sendKeysOnWebElement(WebElement element, String text) {
        element.click();
        element.clear();
        element.sendKeys(text);
    }

    // to get single text
    public String getTextFromElement(By locator) {
        return waitForElementToDisplay(locator).getText();
    }

// to Get Element from list

    public List<String> getElementFromList(By locator) {

        List<String> list = new ArrayList<String>();
        try {
            List<WebElement> elements = waitForElementToDisplay(locator).findElements(locator);
            for (WebElement name : elements) {
                list.add(name.getText());
            }
            return list;
        } catch (Exception e) {
            e.printStackTrace();
        }


        return null;
    }

    public String getTextFromMultipleElements(By locator) {
        String text = null;
        try {

            List<WebElement> elements = waitForElementToDisplay(locator).findElements(locator);
            for (WebElement name : elements) {
                text = name.getText();
            }
            return text;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;


    }

    public void javaScriptScroll(By locator, WebElement element) {
        try {
            waitForElementToDisplay(locator);
            JavascriptExecutor js = (JavascriptExecutor) driver;
            js.executeScript("arguments[0].scrollIntoView(true);", element);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void moveToElement(WebElement element) {
        try {
            new Actions(driver).moveToElement(element).perform();
        } catch (Exception e) {
            e.printStackTrace();
        }


    }

    public List<Integer> getTextFromNumber(By locator) {
        try {
            List<Integer> list = new ArrayList<>();
            List<String> value = getElementFromList(locator);
            for (String name : value) {
                list.add(Integer.parseInt(name.replaceAll("[^0-9]", "")));

            }
            return list;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }


    public boolean verifyDisplay(WebElement element) {
        return element.isDisplayed();

    }

    public boolean verifyEnableButton(WebElement element) {
        return element.isEnabled();
    }

    public boolean verifyDisableButton(WebElement element) {
        return element.isSelected();
    }

    public void enterValues(By locator, String value) {
        try {
            waitForElementToDisplay(locator).sendKeys(value);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    public String getTextFromAttribute(By locator, String value) {
        return waitForElementToDisplay(locator).getAttribute(value);
    }


    private List<WebElement> getAllRows(WebElement table) {
        return table.findElements(By.cssSelector("table tr"));
    }

    public String verifyRowItems(WebElement table, List<String> actualValue) {
        List<WebElement> allRows = getAllRows(table);
        for (WebElement allRow : allRows) {
            for (String eachValue : actualValue) {
                if (allRow.getText().equalsIgnoreCase(eachValue)) {
                    return eachValue;
                }
            }
        }
        return null;
    }


    public String getRowsFromTable(WebElement table, String columnHeader, int index) {
        try {
            List<WebElement> header = table.findElements(By.cssSelector(" thead tr th"));
            List<WebElement> rowElemnts = table.findElements(By.cssSelector("tbody tr"));
            int columnIndex = -1;
            for (int i = 0; i < header.size(); i++) {
                if (header.get(i).getText().equalsIgnoreCase(columnHeader)) {
                    columnIndex = i;
                    break;
                }
            }
            List<WebElement> cellElements = rowElemnts.get(index).findElements(By.cssSelector("td"));
            return cellElements.get(columnIndex).getText();
        } catch (Exception e) {
            logger.info("Row with index:" + index + " and column:" + columnHeader + "is not found:");
        }

        return null;
    }


    public Boolean expandIcon(WebElement element, String cellName) {

        List<WebElement> allExpandIcons = driver.findElements(By.xpath(props.getProperty("expandIcons")));
        for (WebElement allExpandIcon : allExpandIcons) {
            if (allExpandIcon.getText().equalsIgnoreCase(cellName)) {
                allExpandIcon.click();
            }
        }

        return element.isDisplayed();
    }

}




