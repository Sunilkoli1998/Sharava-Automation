package com.Common;

import com.data.Shonit_data.PropertiesFile;
import com.Common.ReportPage;
import com.Common.SearchFilter;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

public class SampleRejectApprove extends ReportPage {


    public Properties props;
    public WebDriver driver;
    public WebDriverWait wait;
    public int ApproveCount, RejectCount;
    private final Logger logger = LogManager.getLogger(SampleRejectApprove.class);


    public SampleRejectApprove(WebDriver driver) throws Exception {
        super(driver);
        this.driver = driver;
        PropertiesFile.readApproveRejectFile();
        PropertiesFile.readApproveRejectFile();
        PropertiesFile.readMandaraHomePropertiesFile();
        PropertiesFile.readShonitListReportFile();

        ApproveCount = RejectCount = -1;
        props = PropertiesFile.prop;
        wait = new WebDriverWait(driver, 35);
    }

    //------------------------------------ Sample Reject ----------------------------------------------------    
    //
    public boolean gotohomeviesigtupleicon() throws InterruptedException {
        WebElement icon = wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.xpath(props.getProperty("sigtupleicon"))));
        if (icon.isDisplayed()) {
            icon.click();
            Thread.sleep(5000);
            try {
                WebElement alertpopup = driver.findElement(
                        By.xpath(props.getProperty("alerttorejectupdate")));
                if (alertpopup != null && alertpopup.isDisplayed()) {
                    WebElement accept = driver.findElement(
                            By.xpath(props.getProperty("alerttorejectupdate_accept")));
                    if (accept.isEnabled())
                        accept.click();
                }
            } catch (Exception e) {
            }
            WebElement homepage = wait.until(ExpectedConditions.visibilityOfElementLocated(
                    By.xpath(props.getProperty("apptoolbar"))));
            if (homepage.isDisplayed()) {
                Thread.sleep(2000);
                logger.info("Clicked on sigtuple icon and home page loaded ");
                return true;
            }
        }
        return false;
    }

    //find reject button
    public Boolean verifyrejectbtn() throws InterruptedException {
        props = PropertiesFile.prop;
        WebElement button = wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath(props.getProperty("Reject"))));
        return (button.isDisplayed() && button.isEnabled());
    }

    //click on Reject button
    public Boolean clickonRejectbutton() throws InterruptedException {
        props = PropertiesFile.prop;
        Thread.sleep(2000);
        WebElement button = wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath(props.getProperty("Reject"))));
        if (button.isDisplayed()) {
            button.click();
            Thread.sleep(3000);
            return true;
        }
        return false;
    }

    //Verify reject confirm popup
    public Boolean verifyRejectpop() throws InterruptedException {
        props = PropertiesFile.prop;
        wait.until(ExpectedConditions.alertIsPresent());
        Alert alert = driver.switchTo().alert();
        String text = alert.getText();
        System.out.println(text);
        return (text.contains(props.getProperty("Rejectpopupmsg")) || text.contains(props.getProperty("ApproveAlert")));

    }

    public void enterComment() throws InterruptedException {
        props = PropertiesFile.prop;
        WebElement commentfiled = wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.xpath(props.getProperty("commentFiled"))));
        commentfiled.sendKeys(props.getProperty("rejectionComment"));
        Thread.sleep(1000);
    }

    //verify the reject button in the cancel popup
    public String verifythecancellbutton() {
        props = PropertiesFile.prop;
        WebElement popupcancelbtn = wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.xpath(props.getProperty("popupcancelbtn"))));
        String placeHolderName = popupcancelbtn.getText();
        return placeHolderName;
    }


    //verify the reject button in the reject popup
    public String verifytheRejectbutton() {
        props = PropertiesFile.prop;
        WebElement popuprejectbtn = wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.xpath(props.getProperty("popuprejectbtn"))));
        String rejectbutton = popuprejectbtn.getText();
        return rejectbutton;
    }


    //verify the rejecting the sample
    public void verifytheRejectingthesample() throws InterruptedException {
        props = PropertiesFile.prop;
        Thread.sleep(3000);
        WebElement popuprejectbtn = wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.xpath(props.getProperty("popuprejectbtn"))));
        popuprejectbtn.click();
        driver.navigate().refresh();

    }

    //verify the status of the rejected  sample
    public String verifytheStatusofTherejectedSample() throws InterruptedException {
        props = PropertiesFile.prop;
        Thread.sleep(3000);
        WebElement rejectStatus = wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.xpath(props.getProperty("rejectedStatus"))));
        String Status = rejectStatus.getText();
        return Status;

    }

    //verify the rejected comment in the summary tab
    public String verifyTheRejectedComment() throws InterruptedException {
        props = PropertiesFile.prop;

        WebElement summaryTab = wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.xpath(props.getProperty("metricstab"))));
        summaryTab.click();
        Thread.sleep(3000);
        String rejectedComment = wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.xpath(props.getProperty("rejectedComment")))).getText();
        return rejectedComment;

    }


    //Verify Accept the sample rejection
    public Boolean AcceptsampleRejection() throws InterruptedException {
        props = PropertiesFile.prop;

        if (!this.clickonRejectbutton())
            return false;
        if (!this.verifyRejectpop())
            return false;
        Thread.sleep(3000);
        Alert alert = driver.switchTo().alert();
        alert.accept();
        Thread.sleep(3000);
        return this.verifysuccesspopup();

    }

    //Verify success sample rejection popup
    public Boolean verifysuccesspopup() throws InterruptedException {
        props = PropertiesFile.prop;
        Thread.sleep(3000);
        Alert alert = driver.switchTo().alert();
        String text = alert.getText();
        System.out.println(text);
        alert.accept();
        Thread.sleep(2000);
        System.out.println("confirmation popup closed");
        return this.verifyReportRejectOrApproveDone();
    }

    //Verify Reported Metrics headers


    //Verify reject confirm popup
    public Boolean visibilityOfRejectpop() throws InterruptedException {
        props = PropertiesFile.prop;
        Thread.sleep(2000);
        try {
            WebElement button = driver.findElement(By.xpath(props.getProperty("rejectpopup")));
            if (button == null)
                return false;
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    //Verify reject confirm popup
    public Boolean verifyOfRejectpopAlertsymbol() throws InterruptedException {
        props = PropertiesFile.prop;
        WebElement symbol = wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.xpath(props.getProperty("rejectpopup_alertsymb"))));
        if (symbol.isDisplayed())
            return true;
        return false;
    }

    //Verify reject confirm popup
    public Boolean verifyOfRejectpopAlertmessage() throws InterruptedException {
        props = PropertiesFile.prop;
        WebElement msg = wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.xpath(props.getProperty("rejectpopup_que"))));
        if (msg.isDisplayed()) {
            logger.info("alert msg : " + msg.getText());
            if (msg.getText().trim().equalsIgnoreCase(props.getProperty("rejectpopup_que_text")))
                return true;
        }
        return false;
    }

    //Verify reject confirm popup
    public Boolean verifyOfRejectpopInputField() throws InterruptedException {
        props = PropertiesFile.prop;
        WebElement input = wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.xpath(props.getProperty("rejectpopup_commentfield"))));
        if (input.isDisplayed()) {
            String placeholder = input.getAttribute("placeholder");
            logger.info("input field placholder  : " + placeholder);
            if (placeholder.trim().equalsIgnoreCase(props.getProperty("rejectpopup_placehoder")))
                return true;
        }
        return false;
    }

    //Verify reject confirm popup
    public Boolean inputcomment() throws InterruptedException {
        props = PropertiesFile.prop;
        WebElement input = wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.xpath(props.getProperty("rejectpopup_commentfield"))));
        if (input.isDisplayed()) {
            input.click();
            input.clear();
            input.sendKeys(props.getProperty("rejectpopup_inputcomment"));
            if (input.getAttribute("value").trim().equalsIgnoreCase(props.getProperty("rejectpopup_inputcomment")))
                return true;

        }
        return false;
    }

    //Verify reject confirm popup
    public String getalertmsg() throws InterruptedException {
        props = PropertiesFile.prop;
        String alertmsg = "";
        WebElement alert = wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.cssSelector(props.getProperty("alertpopup"))));
        if (alert.isDisplayed()) {
            alertmsg = alert.getText().trim();
            logger.info("Alert : " + alertmsg);
        }
        return alertmsg;

    }

    //Verify reject confirm popup
    public String verifyRejectpopInputAlert() throws InterruptedException {
        props = PropertiesFile.prop;
        WebElement button = wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.xpath(props.getProperty("rejectpopup_okbutton"))));
        if (button.isDisplayed()) {
            button.click();
            Thread.sleep(1000);
        }
        return this.getalertmsg();

    }

    //Verify reject confirm popup
    public Boolean verifyRejectpopclosebutton() throws InterruptedException {
        props = PropertiesFile.prop;
        WebElement button = wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.xpath(props.getProperty("rejectpopup_closebutton"))));
        if (button.isDisplayed()) {
            Thread.sleep(1000);
            button.click();
        }
        return !this.visibilityOfRejectpop();
    }

    //Verify reject confirm popup
    public Boolean verifyRejectpopCancelButton() throws InterruptedException {
        props = PropertiesFile.prop;
        WebElement button = wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.xpath(props.getProperty("rejectpopup_cancelbutton"))));
        if (button.isDisplayed()) {
            Thread.sleep(1000);
            button.click();
        }
        return !this.visibilityOfRejectpop();
    }

    //Verify reject confirm popup
    public Boolean verifyRejectpopOKButton() throws InterruptedException {
        props = PropertiesFile.prop;
        WebElement button = wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.xpath(props.getProperty("rejectpopup_okbutton"))));
        if (button.isDisplayed()) {
            Thread.sleep(1000);
            button.click();
        }
        return !this.visibilityOfRejectpop();
    }

    //Verify Reported Metrics headers
    public Boolean verifyReportRejectOrApproveDone() throws InterruptedException {
        props = PropertiesFile.prop;
        Thread.sleep(2000);
        WebElement reject = wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.xpath(props.getProperty("Status"))));
        WebElement approve = wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.xpath(props.getProperty("Status"))));
        //return (reject.isDisplayed() && !approve.isEnabled() && approve.isDisplayed() && !reject.isEnabled());
        if(reject.isDisplayed()){
            return true;
        } else if (approve.isDisplayed()){
            return true;

        }
        else return false;
    }


    //Verify reject confirm popup
    public Boolean visibilityOfRejectionUpdateInSummary() throws InterruptedException {
        props = PropertiesFile.prop;
        return wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.xpath(props.getProperty("Rejectiosectioninsummary")))).isDisplayed();
    }

    //Verify reject confirm popup
    private String findUserName() throws InterruptedException {
        props = PropertiesFile.prop;
        String details = "";
        WebElement usericon = wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.xpath(props.getProperty("usericon"))));
        if (usericon.isDisplayed()) {
            usericon.click();
            Thread.sleep(1000);
            details = wait.until(ExpectedConditions.visibilityOfElementLocated(
                    By.xpath(props.getProperty("usericonoptions")))).getText();
        }
        Actions action = new Actions(driver);
        action.moveToElement(usericon).click().build().perform();
        return details;
    }

    //Verify reject confirm popup
    public Boolean verifyRejectedByName() throws InterruptedException {
        props = PropertiesFile.prop;
        String username = wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.xpath(props.getProperty("Rejectedbyinsummary") + "//following-sibling::div"))).getText().trim();
        System.out.println(username.trim().split(" ")[0].trim());
        if (this.findUserName().contains(username.trim().split(" ")[0].trim()))
            return true;
        return false;
    }

    //Verify reject confirm popup
    public Boolean verifyRejectionComment() throws InterruptedException {
        props = PropertiesFile.prop;
        String comment = wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.xpath(props.getProperty("Rejectioncommentinsummary") + "//following-sibling::div"))).getText().trim();
        if (comment.contains(props.getProperty("rejectpopup_inputcomment")))
            return true;
        return false;
    }

//------------------------------------ Sample Approve ----------------------------------------------------    

    //find  Approve button
    public Boolean verifyApprovebtn() throws InterruptedException {
        props = PropertiesFile.prop;
        WebElement button = wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath(props.getProperty("Approve"))));
        return (button.isDisplayed() && button.isEnabled());
    }


    public void enterCommentOnApprovedReport() throws InterruptedException {
        props = PropertiesFile.prop;

        WebElement commentfiled = wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.xpath(props.getProperty("commentFiled"))));
        commentfiled.sendKeys("report approved ");
        Thread.sleep(1000);
    }


    //click on Approve button
    public Boolean clickonApprovebutton() throws InterruptedException {
        props = PropertiesFile.prop;
        WebElement button = wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath(props.getProperty("Approve"))));
        if (button.isDisplayed()) {
            button.click();
            return true;
        }
        return false;
    }


    public void verifytheApprovedsample() throws InterruptedException {
        props = PropertiesFile.prop;
        Thread.sleep(3000);
        WebElement popuprejectbtn = wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.xpath(props.getProperty("popupapprovebtn"))));
        popuprejectbtn.click();

    }
    public boolean clickOnCheckedBoxesForAllTheReport(){
        List<WebElement> checkbox=driver.findElements(By.xpath(props.getProperty("checkbox")));
           for(WebElement checkBoxes:checkbox){
               if(checkBoxes.isSelected())
                   checkBoxes.click();
           }
        return true;
    }




    public String clickOnYesButtonOnApprovePopUp() {
        props = PropertiesFile.prop;
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(props.getProperty("clickOnYesButton")))).isDisplayed();
        driver.findElement(By.xpath(props.getProperty("clickOnYesButton"))).click();
        driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
        return driver.findElement(By.xpath(props.getProperty("previewAndApproveReport"))).getText();
    }



    //reportValue

    public boolean ReportWithPsImpression() {
        props = PropertiesFile.prop;
        WebElement psImpression = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(props.getProperty("psImpressionCheckbox"))));
        if (psImpression.isSelected()) {
            //if (!psImpression.isSelected()) {
            // psImpression.click();
        }
        return wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(props.getProperty("psImpressionTable")))).isEnabled();

    }
    public boolean clickOnApproveButton(){
        props = PropertiesFile.prop;
       wait.until(ExpectedConditions.elementToBeClickable(By.xpath(props.getProperty("clickOnApproveButton")))).click();
        return true;
    }



    public boolean ReportWithoutPsImpression() {
        props = PropertiesFile.prop;
        driver.manage().timeouts().pageLoadTimeout(20,TimeUnit.SECONDS);
        WebElement psImpression = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(props.getProperty("psImpressionCheckbox"))));
        if (psImpression.isDisplayed()) {
            psImpression.click();
        }
        Boolean psImpressionTableStatus= wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath(props.getProperty("psImpressionTable"))));

           return psImpressionTableStatus ;
    }



















//   //Verify Approve confirm popup
//    public Boolean verifyApprovepop() throws InterruptedException
//    {
//        props = PropertiesFile.prop;
//        WebElement dialog= wait.until(ExpectedConditions.visibilityOfElementLocated(
//    			By.cssSelector(props.getProperty("approvedialog"))));
//        if(dialog.isDisplayed()) {
//            WebElement header= wait.until(ExpectedConditions.visibilityOfElementLocated(
//        			By.cssSelector(props.getProperty("diloagheader"))));
//            if(header.getText().contains("Analysis Report"))
//            	return true;
//        }
//        return false;
//    }
//    
//    //Verify Approve and cancel button in approve popup
//    public Boolean verifydialogbuttons() throws InterruptedException
//    {
//        props = PropertiesFile.prop;
//        WebElement dialog= wait.until(ExpectedConditions.visibilityOfElementLocated(
//    			By.cssSelector(props.getProperty("approvedialog"))));
//        if(dialog.isDisplayed()) {
//            WebElement approve= wait.until(ExpectedConditions.elementToBeClickable(
//        			By.cssSelector(props.getProperty("dialogapprovebtn"))));
//            WebElement cancel= wait.until(ExpectedConditions.elementToBeClickable(
//        			By.cssSelector(props.getProperty("dialogcancelbtn"))));
//            return (approve.isDisplayed() && cancel.isDisplayed());
//        }
//        return false;
//    }
//    
//    //Verify content table and email IDs with note
//    public Boolean verifytableAndemailsection() throws InterruptedException
//    {
//        props = PropertiesFile.prop;
//        WebElement dialog= wait.until(ExpectedConditions.visibilityOfElementLocated(
//    			By.cssSelector(props.getProperty("approvedialog"))));
//        if(dialog.isDisplayed()) {
//            WebElement table= wait.until(ExpectedConditions.visibilityOfElementLocated(
//        			By.cssSelector(props.getProperty("dialogtable"))));
//            WebElement emailcontent= wait.until(ExpectedConditions.visibilityOfElementLocated(
//        			By.cssSelector(props.getProperty("dialoganalysisemail"))));
//            return (table.isDisplayed() && emailcontent.isDisplayed());
//        }
//        return false;
//    }
//    
//    //click cancel button from approve dialog box
//    public Boolean clickoncancelbuttonofdialog() throws InterruptedException
//    {
//        props = PropertiesFile.prop;
//        WebElement button= wait.until(ExpectedConditions.elementToBeClickable(
//    			By.cssSelector(props.getProperty("dialogcancelbtn"))));
//        if(button.isDisplayed()) {
//        	Thread.sleep(2000);
//        	button.click();
//        	Thread.sleep(3000);
//            WebElement button1= wait.until(ExpectedConditions.visibilityOfElementLocated(
//        			By.xpath(props.getProperty("Approve"))));
//            return (button1.isDisplayed() && button1.isEnabled());
//        }
//        return false;
//    }
//    
    //  //click Approve button from approve dialog box
    //   public Boolean clickonApprovebuttonofdialog() throws Exception
    //   {
    //       props = PropertiesFile.prop;
    //       this.clickonApprovebutton();
    //       if(!this.verifyApprovepop())
//       	return false;
//        WebElement button= wait.until(ExpectedConditions.elementToBeClickable(
//    			By.cssSelector(props.getProperty("dialogapprovebtn"))));
//        if(button.isDisplayed()) {
//        	Thread.sleep(2000);
//        	button.click();
//        }
//        System.out.println("Approve done");
//        return true;
//    }

    //Verify downlaod report button
    public Boolean visibilityOfDownlaodButton() throws InterruptedException {
        props = PropertiesFile.prop;
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(props.getProperty("DrishtisummaryTab")))).click();
        WebElement button = wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath(props.getProperty("downloadbutton"))));
        driver.findElement(By.xpath(props.getProperty("downloadbutton"))).click();
        return button.isDisplayed();
    }

    //Verify downlaod report button
    public Boolean visibilityOfPrintReportButton() throws InterruptedException {
        props = PropertiesFile.prop;
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(props.getProperty("DrishtisummaryTab")))).click();
        WebElement button = wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath(props.getProperty("printreportbutton"))));
       // driver.findElement(By.xpath(props.getProperty("printreportbutton"))).click();
        return button.isDisplayed();
    }

    //--------------------------------------------------------------------------------

    public boolean getReportCountFromHome(String productpath) throws InterruptedException {
        Thread.sleep(5000);
        WebElement Reject = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(productpath + props.getProperty("RejectCount"))));
        this.RejectCount = Integer.valueOf(Reject.getText().trim());

        WebElement Approve = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(productpath + props.getProperty("ApproveCount"))));
        this.ApproveCount = Integer.valueOf(Approve.getText().trim());

        return ApproveCount >= 0 && RejectCount >= 0;
    }

    public boolean verifyRejectCountFromHome(String productpath) throws InterruptedException {
        Thread.sleep(5000);
        WebElement Reject = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(productpath + props.getProperty("RejectCount"))));
        int newRejectCount = Integer.valueOf(Reject.getText().trim());
        if (RejectCount == newRejectCount - 1) {
            System.out.println(String.valueOf(RejectCount) + " : " + String.valueOf(newRejectCount));
            logger.info("Updated Reject count is verified from home page");
            return true;
        }
        logger.info("updated Reject count is not same as expected ");
        return false;
    }

    public boolean verifyApproveCountFromHome(String productpath) throws InterruptedException {
        Thread.sleep(5000);
        WebElement Approve = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(productpath + props.getProperty("ApproveCount"))));
        int newApproveCount = Integer.valueOf(Approve.getText().trim());

        if (ApproveCount == newApproveCount - 1) {
            System.out.println(String.valueOf(ApproveCount) + " : " + String.valueOf(newApproveCount));
            logger.info("Updated Approve count is verified from home page");
            return true;
        }
        logger.info("updated Approve count is not same as expected ");
        return false;

    }


}

