package com.Common;

import com.data.Shonit_data.PropertiesFile;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.util.List;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

public class AdminPortal {
    public Properties props;
    public WebDriver driver;
    WebDriverWait wait;
    private static final Logger logger = LogManager.getLogger(AdminPortal.class);

    public AdminPortal(WebDriver driver) throws Exception {
        this.driver = driver;
        props = PropertiesFile.prop;
        int time = 30;
        wait = new WebDriverWait(driver, time);
        PropertiesFile.readPropertiesFIle();
        PropertiesFile.readSearchFilterFile();
        PropertiesFile.readPageLoadFile();
        PropertiesFile.readMandaraHomePropertiesFile();
    }

    //fetches title of the Login Page
    public String verifySigTupleTittle() {
        return driver.getTitle();
    }


    public boolean vailidlogin(String uname, String pwd) throws InterruptedException {
        Thread.sleep(1000);
        props = PropertiesFile.prop;
        WebElement userName = driver.findElement(By.xpath("//input[@id='login-username']"));
        Thread.sleep(1000);
        userName.clear();
        userName.sendKeys(uname);
        WebElement password = driver.findElement(By.xpath("//input[@id='login-password']"));
        password.click();
        password.clear();
        password.sendKeys(pwd);
        // ExpectedConditions.presenceOfElementLocated(By.xpath(props.getProperty("limssigninbutton"))));
        WebElement button = driver.findElement(By.xpath("//button[@class='btn form-control login-btn']"));

        if (button.isDisplayed() && !button.getAttribute("class").contains("disable")) {
            button.click();
            logger.info("clicked on login button");
            return true;
        }
        return false;

    }


    public boolean checkSideMenuOnLims() throws InterruptedException {
        return wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[@class='navbar-brand sidemenu-btn']"))).isDisplayed();

    }


    private boolean clickonsidemenuOnLims() throws InterruptedException {
        WebElement sidemenu = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[@class='navbar-brand sidemenu-btn']")));
        if (sidemenu.isDisplayed()) {

            // sidemenu.click();
            driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
            return true;
        }
        return false;
    }


    public boolean selectShonitCard() throws InterruptedException {
        if (this.clickonsidemenuOnLims()) {
            WebElement selectoption = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@id='side-menu-wrapper']//*[contains(text(),'Shonit')]")));
            // WebElement selectoption = driver.findElement(By.xpath("//div[@id='side-menu-wrapper']//*[contains(text(),'Shonit')]"));
            if (selectoption.isDisplayed()) {
                selectoption.click();
                return true;
            }
        }
        return false;
    }

    public boolean selectDataViewOptiopn() throws InterruptedException {

        WebElement dataViewOption = driver.findElement(By.xpath("//div[@class='sidemenu-children collapse in']//a[@class='list-group-item ng-binding ng-scope'][normalize-space()='Data View']"));

        if (dataViewOption.isDisplayed()) {
            dataViewOption.click();
            //Thread.sleep(2000);
            driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);

            return true;
        }
        return false;
    }


    public boolean selectSampleId() {


       int paginationSize=driver.findElements(By.xpath("//ul[@class='pagination ng-scope']//li")).size();
       System.out.println(paginationSize);

            String slideIdValue1 = "AUTOMATION-SAMPLE";

            for(int j=1;j<=paginationSize;j++) {


            String slidEID = "//table[@class='table mandara-table table-responsive table-hover']//td[text()='"+slideIdValue1+"']";

            try {
                if (driver.findElement(By.xpath(slidEID)).isDisplayed()) {
                   // String expandButton = slidEID+"/preceding-sibling::td[1]/i[1]";
                    String expandButton="//table[@class='table mandara-table table-responsive table-hover']//td[text()='"+slideIdValue1+"']//preceding-sibling::td/i";
                    driver.findElement(By.xpath(expandButton)).click();
                    break;
                }
            } catch (Throwable t) {}

            driver.findElement(By.xpath("//ul[@class='pagination ng-scope']/li[@class='ng-scope active']/following::a[1]")).click();

            return true;
        }
        return false;
    }


     /*  //  List<WebElement> slideId = driver.findElements(By.xpath("//table[@class='table mandara-table table-responsive table-hover']//tbody//tr//td[2]"));

        String slideIdValue = "AUTOMATION-SAMPLE";

        // we can pass  dynamically any type of slide id value either it can be text or number
       // String slideID = "//table[@class='table mandara-table table-responsive table-hover']//td[text()='"+slideIdValue+"']/preceding-sibling::td[1]/i[1]";
       // driver.findElement(By.xpath(slideID)).click();

        return true;
    }*/

   /* for(int i=0;i<slideId.size();i++) {
           if (slideId.get(i).getText().equals(slideIdValue)) {
               String statusText = "//table[@class='table mandara-table table-responsive table-hover']//tbody//tr[" + (i + 1) + "]//td[1]";
               driver.findElement(By.xpath(statusText)).click();
               break;
           }
        return true;
    }
       return false;

}*/

   public boolean clickOnStartAnalysis() {

       List <WebElement> startAnalysis =  driver.findElements(By.xpath("//table[@class='table table-hover table-responsive mandara-table table-outer-border']//tbody//td[5]/following::div/button[1]"));
        String StartAnalysis="Start Analysis";
       for(int i=0;i<startAnalysis.size();i++) {
           if (startAnalysis.get(i).getText().equals(StartAnalysis)) {
               String statusText = "//table[@class='table mandara-table table-responsive table-hover']//tbody//td[" + (i+1) + "]";
               driver.findElement(By.xpath(statusText)).click();
               break;
           }}
       return true;


   }

       /* WebElement initiateAnalysisModalTitle = driver.findElement(By.xpath("//h5[contains(text(),'Do you want to initiate Analysis for ')]"));
        String initiateAnalysisText = driver.findElement(By.xpath("//h3[@id='modal-title']")).getText();
        System.out.println(initiateAnalysisText);
        if (initiateAnalysisModalTitle.isDisplayed() && (initiateAnalysisText.contains("Initiate Analysis"))) {

            return true;
        }

    }
       return false;
   }*/

    public WebElement selectInstallationName() {

        WebElement nameOption = driver.findElement(By.xpath("//select[@id='installation']"));
        Select sl = new Select(nameOption);
        nameOption.click();
      List<WebElement> nameOptions = nameOption.findElements(By.tagName("option"));
        for (WebElement optionText : nameOptions) {
            String allText = optionText.getText();
            if (allText.contains("SIG-Sig-223-1")) {
                optionText.click();
                break;
            }
        }
        return nameOption;
    }

    public boolean cickOnConfirmButton() {
        driver.findElement(By.xpath("//button[normalize-space()='Confirm']")).click();
        driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
        WebElement clickOnUserIcon = driver.findElement(By.xpath("//i[@class='fa fa-2x fa-user-circle']"));

        clickOnUserIcon.click();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        WebElement logOuButtont = driver.findElement(By.xpath("//a[normalize-space()='Logout']"));
        logOuButtont.click();
        return true;
    }


}