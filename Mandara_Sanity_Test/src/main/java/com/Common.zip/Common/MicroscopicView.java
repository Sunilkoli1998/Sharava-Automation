package com.Common;

import com.data.ImgDiffPercent;
import com.data.Shonit_data.*;
import org.apache.commons.io.FileUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.Properties;
import java.util.concurrent.ThreadLocalRandom;
import java.util.concurrent.TimeUnit;

public class MicroscopicView extends ReportPage {

    private final WebDriverWait wait;
    public Properties props;
    public WebDriver driver;
    public Login login;
    public ImgDiffPercent imagecomp;
    String curDir = System.getProperty("user.dir");
    private final Logger logger = LogManager.getLogger(MicroscopicView.class);


    public MicroscopicView(WebDriver driver) throws Exception {
        super(driver);
        this.driver = driver;
        wait = new WebDriverWait(driver, 50);
        PropertiesFile.readMicroscopicViewFile();
        props = PropertiesFile.prop;
        imagecomp = new ImgDiffPercent();

    }

    //Open Microscopic tab and verify the page load
    public boolean clickOnMicroscopicViewTab() throws InterruptedException {
        props = PropertiesFile.prop;
        Thread.sleep(1000);
        return super.clickonTab(props.getProperty("microscopictab"));
    }

    //verify microscopy page is loaded
    public boolean verifyMicroscopicPageLoad() {
        props = PropertiesFile.prop;
        return wait.until(ExpectedConditions.visibilityOfElementLocated(By.id(props.getProperty("fovpanel")))).isDisplayed();
    }

    //find the name of sample id which is opened
    public boolean verifyFovSampleID() {
        props = PropertiesFile.prop;
        String openedSampleID = wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(props.getProperty("microscopicsampledesc")))).getText();
        String fovslideID = wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(props.getProperty("Fovslideid")))).getText();
        logger.info("FOV slide id : sampleID => " + fovslideID + " : " + openedSampleID);
        if (fovslideID.contains("Slide #") && fovslideID.contains(openedSampleID))
            return true;
        return false;

    }

//    //Match the Fov dots and numbers coresponding to the header
//    public boolean verifyNumberOfFovDots(String product) {
//        props = PropertiesFile.prop;
//        String capturedimages = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(props.getProperty("capturedimages")))).getText().trim();
//        int  fovdots= wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.cssSelector(props.getProperty("allfovdotclass")))).size();
//        logger.info("captured images : FOV Dots => "+capturedimages+" : "+String.valueOf(fovdots));
//        if(product.equalsIgnoreCase("Shrava"))
//        	return (Integer.valueOf(capturedimages)>=fovdots);
//        else
//        	return (Integer.valueOf(capturedimages)==fovdots);
//    }

    //Open a random FOV on the basis of random number generated between 1 to n where n is the max FoV present for any sample
    public boolean SelectAnyRandomDot() throws InterruptedException {
        props = PropertiesFile.prop;
        Thread.sleep(1500);
        List<WebElement> listofdots = wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.cssSelector(props.getProperty("allfovdotclass"))));
        int i = ThreadLocalRandom.current().nextInt(0, listofdots.size() - 1);
        //driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
        listofdots.get(i).click();
        Thread.sleep(2000);
        //return wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(props.getProperty("sampleattributes")))).isDisplayed();
        return true;
    }

    //
    public boolean verifyListOfAttributs() throws InterruptedException {
        return true;
    }

    //open first FOV for identify its visibilty
    public boolean SelectAnyRandomAttribute() throws InterruptedException {
        props = PropertiesFile.prop;
        List<WebElement> listofattributs = wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath(props.getProperty("sampleattributes") + "/tr/td[1]")));
        if (listofattributs.size() > 0) {
            int i = ThreadLocalRandom.current().nextInt(0, listofattributs.size() - 1);
            listofattributs.get(0).click();
            return true;
        }
        return false;
    }

    //Determine the canvas element to verify the full FoV has opened successfully
    public boolean verifyCanvasImageLoaded() {
        props = PropertiesFile.prop;
        return wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(props.getProperty("fovcanvas")))).isEnabled();
    }

    //Determine the canvas element to verify the full FoV has opened successfully
    public boolean verifyCanvasSize() {
        props = PropertiesFile.prop;
        return wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(props.getProperty("canvassize")))).isDisplayed();
    }

    // Verify the  FoV clicked is same as the opened one
    public boolean verifyImageCountSection() {
        props = PropertiesFile.prop;
        WebElement imagecount = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(props.getProperty("imagecount"))));
        if (imagecount.isDisplayed()) {
            logger.info("image count section is loaded ");
            boolean editbox = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(props.getProperty("imagecount") + "//input"))).isDisplayed();
            if (imagecount.getText().contains("of") && editbox)
                return true;
        }
        return false;
    }

    //To verify the FoV footer images are displayed.
    public boolean verifyFovButtons() {
        List<WebElement> fovbuttons = wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath(props.getProperty("fovbtn"))));
        if (fovbuttons.size() > 0)
            return true;
        return false;
    }

    //To verify the FoV footer images are displayed.
    public boolean verifyListOfAttributes() {
        return true;
    }


    //verify the functionality of zoomin button 
    public boolean verifyImageZoomIn() throws InterruptedException, IOException {
        props = PropertiesFile.prop;
        File scrFile = ((TakesScreenshot) driver).
                getScreenshotAs(OutputType.FILE);

        String curr = curDir + "/src/test/java/com/temp/zoomin-current.png";
        FileUtils.copyFile(scrFile, new File(curr));
        Thread.sleep(2000);

        Actions action = new Actions(driver);
        for (int i = 0; i < 4; i++)
            action.moveToElement(driver.findElement(By.cssSelector(props.getProperty("zoomin")))).click().build().perform();
        Thread.sleep(2000);

        File scrFile1 = ((TakesScreenshot) driver).
                getScreenshotAs(OutputType.FILE);

        String difference = curDir + "/src/test/java/com/temp/zoomin-difference.png";
        FileUtils.copyFile(scrFile1, new File(difference));
        double differ = imagecomp.getDifferencePercent(curr, difference);
        return differ > 0.0;

    }

    //verify the functionality of reset button 
    public boolean verifyImageSizeReset() throws InterruptedException, IOException {
        props = PropertiesFile.prop;
        File scrFile = ((TakesScreenshot) driver).
                getScreenshotAs(OutputType.FILE);

        String current = curDir + "/src/test/java/com/temp/reset-current.png";
        FileUtils.copyFile(scrFile, new File(current));
        Thread.sleep(2000);

        Actions action = new Actions(driver);
        action.moveToElement(driver.findElement(By.cssSelector(props.getProperty("resize")))).click().build().perform();
        Thread.sleep(2000);

        File scrFile1 = ((TakesScreenshot) driver).
                getScreenshotAs(OutputType.FILE);
        String difference = curDir + "/src/test/java/com/temp/reset-difference.png";
        FileUtils.copyFile(scrFile1, new File(difference));
        double differ = imagecomp.getDifferencePercent(current, difference);
        return differ > 0.0;
    }

    //verify the functionality of zoomout button 
    public boolean verifyImageZoomOut() throws InterruptedException, IOException {
        props = PropertiesFile.prop;
        File scrFile = ((TakesScreenshot) driver).
                getScreenshotAs(OutputType.FILE);

        String current = curDir + "/src/test/java/com/temp/zoomout-current.png";
        FileUtils.copyFile(scrFile, new File(current));
        Thread.sleep(2000);

        Actions action = new Actions(driver);
        for (int i = 0; i < 4; i++)
            action.moveToElement(driver.findElement(By.cssSelector(props.getProperty("zoomout")))).click().build().perform();
        Thread.sleep(2000);

        File scrFile1 = ((TakesScreenshot) driver).
                getScreenshotAs(OutputType.FILE);

        String difference = curDir + "/src/test/java/com/temp/zoomout-difference.png";
        FileUtils.copyFile(scrFile1, new File(difference));

        double differ = imagecomp.getDifferencePercent(current, difference);
        return differ > 0.0;

    }

    //find the next image after click on next button for the opened preview window
    public boolean verifyGoToNextImage() throws InterruptedException, IOException {

        props = PropertiesFile.prop;
        File scrFile = ((TakesScreenshot) driver).
                getScreenshotAs(OutputType.FILE);

        String current = curDir + "/src/test/java/com/temp/nextimg-current.png";
        FileUtils.copyFile(scrFile, new File(current));
        driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);

        Actions action = new Actions(driver);
        action.moveToElement(driver.findElement(By.xpath(props.getProperty("nextimage")))).click().build().perform();
        Thread.sleep(3000);

        File scrFile1 = ((TakesScreenshot) driver).
                getScreenshotAs(OutputType.FILE);

        String difference = curDir + "/src/test/java/com/temp/nextimg-difference.png";
        FileUtils.copyFile(scrFile1, new File(difference));

        double differ = imagecomp.getDifferencePercent(current, difference);
        return differ > 0.0;

    }

    //find the prev image after click on prev button for the opened preview window
    public boolean verifyGoToPrevImage() throws InterruptedException, IOException {

        props = PropertiesFile.prop;
        File scrFile = ((TakesScreenshot) driver).
                getScreenshotAs(OutputType.FILE);

        String current = curDir + "/src/test/java/com/temp/previmg-current.png";
        FileUtils.copyFile(scrFile, new File(current));

        Actions action = new Actions(driver);
        action.moveToElement(driver.findElement(By.xpath(props.getProperty("previmage")))).click().build().perform();
        Thread.sleep(3000);

        File scrFile1 = ((TakesScreenshot) driver).
                getScreenshotAs(OutputType.FILE);

        String difference = curDir + "/src/test/java/com/temp/previmg-difference.png";
        FileUtils.copyFile(scrFile1, new File(difference));

        double differ = imagecomp.getDifferencePercent(current, difference);
        return differ > 0.0;

    }

    public boolean verifyGoToTopImage() throws InterruptedException, IOException {

        props = PropertiesFile.prop;
        File scrFile = ((TakesScreenshot) driver).
                getScreenshotAs(OutputType.FILE);

        String current = curDir + "/src/test/java/com/temp/previmg-current.png";
        FileUtils.copyFile(scrFile, new File(current));

        Actions action = new Actions(driver);
        action.moveToElement(driver.findElement(By.xpath(props.getProperty("topimage")))).click().build().perform();
        Thread.sleep(3000);

        File scrFile1 = ((TakesScreenshot) driver).
                getScreenshotAs(OutputType.FILE);

        String difference = curDir + "/src/test/java/com/temp/previmg-difference.png";
        FileUtils.copyFile(scrFile1, new File(difference));

        double differ = imagecomp.getDifferencePercent(current, difference);
        return differ > 0.0;

    }


    public boolean verifyGoToBottomImage() throws InterruptedException, IOException {

        props = PropertiesFile.prop;
        File scrFile = ((TakesScreenshot) driver).
                getScreenshotAs(OutputType.FILE);

        String current = curDir + "/src/test/java/com/temp/previmg-current.png";
        FileUtils.copyFile(scrFile, new File(current));

        Actions action = new Actions(driver);
        action.moveToElement(driver.findElement(By.xpath(props.getProperty("bottomimage")))).click().build().perform();
        Thread.sleep(3000);

        File scrFile1 = ((TakesScreenshot) driver).
                getScreenshotAs(OutputType.FILE);

        String difference = curDir + "/src/test/java/com/temp/previmg-difference.png";
        FileUtils.copyFile(scrFile1, new File(difference));

        double differ = imagecomp.getDifferencePercent(current, difference);
        return differ > 0.0;

    }


    public String enterNumberInTextbox() {
        props = PropertiesFile.prop;
        WebElement inputField = driver.findElement(By.xpath(props.getProperty("inputBox")));
        inputField.clear();
        inputField.sendKeys(props.getProperty("FOVNumber"));
        inputField.sendKeys(Keys.ENTER);
        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
        String text = driver.findElement(By.xpath(props.getProperty("selectedNumber"))).getText();
        System.out.println(text);
        return text;
    }


    public String verifyMArkAll() {
        props = PropertiesFile.prop;
        String text = driver.findElement(By.xpath(props.getProperty("markAll"))).getText();
        System.out.println(text);
        driver.findElement(By.xpath(props.getProperty("checkkbox"))).click();

        return text;
    }

    public boolean minimisingOfFullFov() {
        props = PropertiesFile.prop;
        WebElement zoomIn = driver.findElement(By.tagName("html"));
        // zoomIn.sendKeys(Keys.chord(Keys.COMMAND,Keys.ADD));
        JavascriptExecutor executor = (JavascriptExecutor) driver;
        executor.executeScript("document.body.style.zoom='100%'");
        return true;
    }

    public boolean maximisingOfFullFov() {
        props = PropertiesFile.prop;
        WebElement zoomOut = driver.findElement(By.tagName("html"));
        zoomOut.sendKeys(Keys.chord(Keys.COMMAND, Keys.SUBTRACT));
        //JavascriptExecutor executor=(JavascriptExecutor)driver;
        // executor.executeScript("document.body.style.zoom='100%'");
        return true;
    }

    public boolean viewFullImage(){
        props = PropertiesFile.prop;
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(props.getProperty("expandImage")))).click();
        driver.manage().timeouts().pageLoadTimeout(10,TimeUnit.SECONDS);
        return true;
    }





    //find the any patch on the list of patches
    public boolean visibilityOfPatchesOnFov() throws InterruptedException, IOException {

        props = PropertiesFile.prop;
        File scrFile = ((TakesScreenshot) driver).
                getScreenshotAs(OutputType.FILE);

        String current = curDir + "/src/test/java/com/temp/patchFOV-current.png";
        FileUtils.copyFile(scrFile, new File(current));

        Actions action = new Actions(driver);
        List<WebElement> patches = driver.findElements(By.xpath(props.getProperty("availablepatches")));
        int i = 20;
        while (i > 0) {
            if (patches.size() == 0) {
                action.moveToElement(driver.findElement(By.xpath(props.getProperty("nextimage")))).click().build().perform();
                Thread.sleep(1000);
                patches = driver.findElements(By.xpath(props.getProperty("availablepatches")));
                i = i - 1;
            } else break;
        }
        action.moveToElement(patches.get(0)).click().build().perform();
        Thread.sleep(1000);

        File scrFile1 = ((TakesScreenshot) driver).
                getScreenshotAs(OutputType.FILE);

        String difference = curDir + "/src/test/java/com/temp/patchFOV-difference.png";
        FileUtils.copyFile(scrFile1, new File(difference));

        double differ = imagecomp.getDifferencePercent(current, difference);
        return differ > 0.0;

    }

    //verify the functionality of clearAll button
    public boolean verifyClearAllButton() throws InterruptedException, IOException {
        props = PropertiesFile.prop;
        File scrFile = ((TakesScreenshot) driver).
                getScreenshotAs(OutputType.FILE);

        String current = curDir + "/src/test/java/com/temp/clearall-current.png";
        FileUtils.copyFile(scrFile, new File(current));

        Actions action = new Actions(driver);
        action.moveToElement(driver.findElement(By.xpath(props.getProperty("clearall")))).click().build().perform();
        Thread.sleep(2000);

        File scrFile1 = ((TakesScreenshot) driver).
                getScreenshotAs(OutputType.FILE);

        String difference = curDir + "/src/test/java/com/temp/clearall-difference.png";
        FileUtils.copyFile(scrFile1, new File(difference));

        double differ = imagecomp.getDifferencePercent(current, difference);
        return differ > 0.0;
    }

    //click on close button of the preview window
    public boolean closeCanvas() throws InterruptedException {
        boolean flag = false;
        WebElement closecanvas = wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(props.getProperty("closecanvas"))));
        if (closecanvas.isDisplayed()) {
            flag = true;
            closecanvas.click();
        }
        Thread.sleep(1000);
        return flag;
    }


}
