package com.Common;

import com.data.Shonit_data.PropertiesFile;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import java.util.List;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

public class SystemRelease extends MandaraHome {
    private final WebDriverWait wait;
    static String optionValue;
    public Properties props;
    public WebDriver driver;
    public Login login;


    private final Logger logger = LogManager.getLogger(SystemRelease.class);

    public SystemRelease(WebDriver driver) throws Exception {
        super(driver);
        this.driver = driver;
        wait = new WebDriverWait(driver, 50);
        PropertiesFile.readSystemReleaseFile();
        props = PropertiesFile.prop;
    }


    public String clickonsidemenu() throws InterruptedException {
        props = PropertiesFile.prop;
        driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
        driver.findElement(By.xpath(props.getProperty("menuCard"))).click();
        Thread.sleep(1000);
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        driver.findElement(By.xpath(props.getProperty("commonSetting"))).click();
        Thread.sleep(1000);
        driver.findElement(By.xpath(props.getProperty("systemRelease"))).click();
        driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
        return wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(props.getProperty("systemReleaseConfiguration")))).getText();
    }


    public String SelectTheProduct() throws InterruptedException {
        props = PropertiesFile.prop;
        Thread.sleep(2000);
        driver.findElement(By.xpath(props.getProperty("selectTheProduct"))).click();
        Thread.sleep(1000);
        List<WebElement> options = driver.findElements(By.cssSelector(props.getProperty("dropdownvalues")));
        Thread.sleep(1000);
        for (WebElement option : options) {
            optionValue = option.getText().trim();
            if (optionValue.startsWith(props.getProperty("productName"))) {
                option.click();
                break;
            }
        }

        String qaSystemRelease = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(props.getProperty("qaSystemRelease")))).getText();
        String versionNumber = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(props.getProperty("versionNumber")))).getText();
        String releaseDate = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(props.getProperty("releaseDate")))).getText();
        String description = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(props.getProperty("descriptionDetail")))).getText();
        return (qaSystemRelease + versionNumber + releaseDate + description);
    }


    public String clickOnNewRelease() throws InterruptedException {
        props = PropertiesFile.prop;
        WebElement release=driver.findElement(By.xpath(props.getProperty("newRelease")));
        release.click();
       // Thread.sleep(1000);
       // release.sendKeys("Automation_test-123");
       // release.sendKeys(Keys.ENTER);
        return wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(props.getProperty("SystemNewRelease")))).getText();
    }

    public String ShonitAtNewSystemReleasePage() {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(props.getProperty("ShonitOnNewSystemRelease")))).getText();

    }

    public WebElement ReleaseVersionNumber() {
        WebElement releaseVersionNumber = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(props.getProperty("releaseVersionNumber"))));
        if (releaseVersionNumber.isDisplayed())
            releaseVersionNumber.click();
        releaseVersionNumber.sendKeys(props.getProperty("releaseVersionText"));
        releaseVersionNumber.sendKeys(Keys.ENTER);
       // releaseVersionNumber.clear();
        return releaseVersionNumber;
    }



    public String ReleaseType() throws InterruptedException {
        WebElement releasetype = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(props.getProperty("releaseType"))));
        releasetype.click();
        Thread.sleep(1000);
        List<WebElement> releaseTypes = driver.findElements(By.cssSelector(props.getProperty("dropdownvalues")));
        for (WebElement releaseType : releaseTypes) {
            String releasetypeOption = releaseType.getText().trim();
            if (releasetypeOption.startsWith(props.getProperty("TypeOfrelease"))) {
                releaseType.click();
                break;
            }
        }

        return wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(props.getProperty("selectedReleaseType")))).getText();
    }

    public String descriptionOptional(){
      return   wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(props.getProperty("descriptionOptional")))).getText();

    }

    public String instructionOfDeployment(){
        return wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(props.getProperty("instructionsOfDeployment")))).getText();
    }

    public String vasuki(){
        return  wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(props.getProperty("vasuki")))).getText();
    }


    public  String uploadPdfReleaseNote()  {
        WebElement uploadFile= driver.findElement(By.xpath(props.getProperty("uploadfile")));
        uploadFile.sendKeys("/Users/santoshchandrakantbudni/Downloads/SANT.pdf");
        return wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(props.getProperty("selectedFile")))).getText();
    }


    public String visibilityOfReportTemplate(){
        return wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(props.getProperty("reportTemplate")))).getText();
    }

    public String visibilityOfUserManual(){
        return  wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(props.getProperty("usermanualpdf")))).getText();
    }
    public String UserMAnulaPdfFile() throws InterruptedException {
        WebElement userManualPdf=driver.findElement(By.xpath(props.getProperty("uploadUserManualfile")));
        userManualPdf.sendKeys("/Users/santoshchandrakantbudni/Downloads/SANT.pdf");
        Thread.sleep(1000);
        return wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(props.getProperty("selectedManualPdfFile")))).getText();
    }

    public String uploadingReportTemplateJsonFile() throws InterruptedException {
        WebElement userManualPdf=driver.findElement(By.xpath(props.getProperty("ReportTemplate")));
        userManualPdf.sendKeys("/Users/santoshchandrakantbudni/Downloads/report_template_Shonit-0.3.3.json");
        Thread.sleep(1000);
        return wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(props.getProperty("uploadedReportTemplate")))).getText();
    }


    public String uploadingEmailtTemplateJsonFile() throws InterruptedException {
        WebElement userManualPdf=driver.findElement(By.xpath(props.getProperty("EmailTemplate")));
        userManualPdf.sendKeys("/Users/santoshchandrakantbudni/Downloads/report_template_Shonit-0.3.3.json");
        Thread.sleep(1000);
        return wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(props.getProperty("uploadedEmailTemplate")))).getText();
    }



    public String clickOnPackageVersion() throws InterruptedException {
        driver.findElement(By.xpath(props.getProperty("packageVersion"))).click();
        Thread.sleep(2000);
        List<WebElement> versionTypes = driver.findElements(By.cssSelector(props.getProperty("dropdownvalues")));
        for (WebElement versionType : versionTypes) {
            String packageVersionOption = versionType.getText().trim();
            if (packageVersionOption.startsWith(props.getProperty("TypeOfPackageVersion"))) {
                versionType.click();
                break;
            }
        }

        return wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(props.getProperty("selectedPackageVersion")))).getText();

    }



    public String visibilityOfAnalyserIcon(){
        return wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(props.getProperty("Analyser")))).getText();
    }

    public String uloadAnalyserJsonFile() throws InterruptedException {
        WebElement analyserJsonFile=driver.findElement(By.xpath(props.getProperty("uploadAnalyserfile")));
        analyserJsonFile.sendKeys("/Users/santoshchandrakantbudni/Downloads/report_template_Shonit-0.3.3.json");
        Thread.sleep(1000);
        return wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(props.getProperty("SelectedAnalyserJsonFile")))).getText();
    }


    public String ClickOnProductVersion() throws InterruptedException {
        driver.findElement(By.xpath(props.getProperty("productVersion"))).click();
        Thread.sleep(1000);
        List<WebElement> productVersionTypes = driver.findElements(By.cssSelector(props.getProperty("dropdownvalues")));
        for (WebElement productVersionType : productVersionTypes) {
            String productVersionOption = productVersionType.getText().trim();
            if (productVersionOption.startsWith(props.getProperty("TypeOfProductVersion"))) {
                productVersionType.click();
                break;
            }
        }

        return wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(props.getProperty("selectedProductVersion")))).getText();
    }



    public String clickOnAnalyserVersion() throws InterruptedException {
        driver.findElement(By.xpath(props.getProperty("AnalyserVersion"))).click();
        Thread.sleep(1000);
        List<WebElement> analyserVersionTypes = driver.findElements(By.cssSelector(props.getProperty("dropdownvalues")));
        for (WebElement analyserVersionType : analyserVersionTypes) {
            String analyserVersionOption = analyserVersionType.getText().trim();
            if (analyserVersionOption.startsWith(props.getProperty("TypeOfAnalyserVersion"))) {
                analyserVersionType.click();
                break;
            }
        }

        return wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(props.getProperty("selectedAnalyserVersion")))).getText();
    }


    public String visibilityOfCancelButton(){
        return  wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(props.getProperty("cancel")))).getText();
    }
    public String clickOnUpdate() throws InterruptedException {
        Thread.sleep(2000);
        Actions actions=new Actions(SystemRelease.this.driver);
       actions.moveToElement(wait.until(ExpectedConditions.elementToBeClickable(By.xpath(props.getProperty("updateNewRelease"))))).click().build().perform();
        Thread.sleep(4000);
        return wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(props.getProperty("ReleaseVersionAtQASystemRelease")))).getText();
    }


}