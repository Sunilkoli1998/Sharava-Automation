package com.Common;

import com.data.Shonit_data.PropertiesFile;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.util.*;


import java.util.concurrent.ThreadLocalRandom;
import java.util.concurrent.TimeUnit;

import static org.openqa.selenium.support.ui.ExpectedConditions.elementToBeClickable;
import static org.openqa.selenium.support.ui.ExpectedConditions.visibilityOfElementLocated;

public class ShonitWBCReport extends ReportPage {

    public Actions actions;
    public Properties props;
    public WebDriver driver;
    public WebDriverWait wait;
    static String reviewerValue;
    ShonitRBCReport shonitRBCReport;
    private MicroscopicView microscopicview;
    private final Logger logger = LogManager.getLogger(ShonitWBCReport.class);
    String filename = "Shonit.csv";

    Map<String, Map<String, String>> WBCdata = new HashMap<String, Map<String, String>>();
    Map<String, Map<String, String>> Reportdata = new HashMap<String, Map<String, String>>();

    public ShonitWBCReport(WebDriver driver) throws Exception {
        super(driver);
        this.driver = driver;
        PropertiesFile.readShonitPropertiesFile();
        PropertiesFile.readShonitListReportFile();

        props = PropertiesFile.prop;
        int time = Integer.parseInt(props.getProperty("timeout"));
        wait = new WebDriverWait(driver, time);
        actions = new Actions(driver);
        MicroscopicView microscopicView = new MicroscopicView(driver);
    }

//---------------------------------- WBC Tab --------------------------------------------


    //verify WBC absolute patches
    public boolean getWBCAbsolutepatches() throws InterruptedException {
        return super.verifypatches(props.getProperty("wbcrows"));
    }

    //Click on WBC Tab
    public Boolean clickonWBCTab() throws InterruptedException {
        props = PropertiesFile.prop;
        return super.clickonTab(props.getProperty("wbctab"));
    }

    //Get name of tables in WBC tab
    public String getWBCListofTabels() throws InterruptedException {
        props = PropertiesFile.prop;

        String tabelnames = wait.until(visibilityOfElementLocated(
                By.xpath(props.getProperty("wbcabsolute")))).getText();
        System.out.println(tabelnames);

        tabelnames = tabelnames + wait.until(visibilityOfElementLocated(
                By.xpath(props.getProperty("reportedmetrics")))).getText();
        return tabelnames;
    }

    //Get header of External Metrics
    public String getWBCAbsoluteColoumns() {
        props = PropertiesFile.prop;

        String text = driver.findElement(By.xpath(props.getProperty("wbcheader"))).getText();
        System.out.println(text);
        return text;
    }

    //Get list of rows in External metrics
    public String getWBCAbsoluterows() throws InterruptedException {
        props = PropertiesFile.prop;
        String listofrows = super.gettablerows(props.getProperty("wbcrows"));
        return listofrows;
    }

    public String ClickOnRefImag() throws InterruptedException {
        props = PropertiesFile.prop;
        Thread.sleep(3000);
        //String cellName = driver.findElement(By.xpath(props.getProperty("cellSelecttion"))).getText();
        // System.out.println(cellName);
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath(props.getProperty("clickonreferences")))).click();
        String sameCellNameonReference = driver.findElement(By.xpath(props.getProperty("selectedCellOnReferences"))).getText();
        driver.findElement(By.xpath(props.getProperty("defaultRefImg"))).isDisplayed();
        driver.findElement(By.xpath(props.getProperty("mylibrary"))).isDisplayed();
        Thread.sleep(1300);
        driver.findElement(By.xpath(props.getProperty("mylibrarycheckbox"))).click();
        String emptymsg =driver.findElement(By.xpath(props.getProperty("emptylibrary"))).getText();
        if (emptymsg.contains("Your library is empty!")) {
            logger.info("your library is empty message is verified");
        } else if (driver.findElement(By.xpath(props.getProperty("listOfAddedImg"))).isDisplayed()) ;

        {
            System.out.println(driver.findElement(By.xpath(props.getProperty("listOfAddedImg"))).getSize());
        }
        driver.findElement(By.xpath(props.getProperty("defaultCheckbox"))).click();
        System.out.println(sameCellNameonReference);
        // driver.findElement(By.xpath(props.getProperty("close"))).click();
        Thread.sleep(2500);
        return sameCellNameonReference;
    }


    public String dropDownAtRefImg() throws InterruptedException {
        driver.findElement(By.xpath(props.getProperty("refImgDropDown"))).click();
        Thread.sleep(1500);
        String selectedcellname = driver.findElement(By.xpath(props.getProperty("selectedcellname"))).getText();
        List<WebElement> allrefdropdown = driver.findElements(By.xpath(props.getProperty("listofdropdownonrefimg")));
        int i = ThreadLocalRandom.current().nextInt(0, allrefdropdown.size());
        allrefdropdown.get(i).click();
        Thread.sleep(3000);
       // String imagecount= driver.findElement(By.xpath(props.getProperty("listOfAddedImg"))).getText();
        driver.findElement(By.xpath(props.getProperty("close"))).click();
        Thread.sleep(3000);
        return selectedcellname;
    }


    public String cellNameOnREferenceTab() {
        props = PropertiesFile.prop;
        String sameCellNameonReference = driver.findElement(By.xpath(props.getProperty("selectedCellOnReferences"))).getText();
        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
        System.out.println(sameCellNameonReference);
        driver.findElement(By.xpath(props.getProperty("close"))).click();
        return sameCellNameonReference;
    }


    public String viewTabSetting() throws InterruptedException {
        props = PropertiesFile.prop;
        String allOptions = driver.findElement(By.xpath(props.getProperty("ViewSetting"))).getText();
        Thread.sleep(1000);
        //List <WebElement> listofpatches=driver.findElements(By.xpath(props.getProperty("listofpatches")));
       // for(int i=0; i<=listofpatches.size()-1;i++){
         //   actions.contextClick((listofpatches.get(6))).perform();
          //  actions.moveToElement(driver.findElement(By.xpath("//div[@class='mat-menu-content']//button[1]"))).click().build().perform();
       // }
        driver.findElement(By.xpath(props.getProperty("allSetting"))).click();
        driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);
        actions.moveToElement(driver.findElement(By.xpath(props.getProperty("modifiedReports")))).click().build().perform();
        Thread.sleep(2000);
        driver.findElement(By.xpath(props.getProperty("allSetting"))).click();
        driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);
        actions.moveToElement(driver.findElement(By.xpath(props.getProperty("markedForReview")))).click().build().perform();
        driver.manage().timeouts().implicitlyWait(20,TimeUnit.SECONDS);
        driver.findElement(By.xpath(props.getProperty("allSetting"))).click();
        actions.moveToElement(driver.findElement(By.xpath(props.getProperty("allReports")))).click().build().perform();
        driver.manage().timeouts().implicitlyWait(20,TimeUnit.SECONDS);
        System.out.println(allOptions);
        return allOptions;
    }

    public boolean diableViewbeforeSelection() {
        boolean condition = driver.findElement(By.xpath(props.getProperty("viewSettingBeforeSelection"))).isEnabled();
        if (condition) {
            System.out.println("setting is enabled");
        } else {
            System.out.println("setting is disabled");
        }
        return true;
    }


    public Boolean Subclassification() throws InterruptedException {
        props = PropertiesFile.prop;
        Thread.sleep(1000);
        WebElement element = driver.findElement(By.xpath(props.getProperty("firstPatchImage")));
        actions.moveToElement(element).perform();
        driver.findElement(By.xpath(props.getProperty("subClassificationIcon"))).click();
        driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
        return true;
    }


    public String clickOnSubclassification() throws InterruptedException {
        Subclassification();
        String allsubClassificationOptions =  driver.findElement(By.xpath(props.getProperty("subClassificationContent"))).getText();
        //System.out.println(allsubClassificationOptions);
        driver.switchTo().activeElement().click();
        return allsubClassificationOptions;
    }


    public String subclassifiedToBandNuet() throws InterruptedException {
        Subclassification();
        Thread.sleep(2000);
        actions.moveToElement(driver.findElement(By.xpath(props.getProperty("subCellSelection")))).click().build().perform();
        Thread.sleep(1500);
        String subclassifiedCell = wait.until(visibilityOfElementLocated(By.xpath(props.getProperty("selectedreclassifiedcell")))).getText();
        Thread.sleep(1000);
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath(props.getProperty("updateButton")))).click();
        wait.until(visibilityOfElementLocated(By.xpath(props.getProperty("tableContent")))).isDisplayed();
        int initialValue = Integer.parseInt(driver.findElement(By.xpath(props.getProperty("initialcount"))).getText());
        driver.findElement(By.xpath(props.getProperty("clickOnUpdateButton"))).click();
        wait.until(visibilityOfElementLocated(By.xpath(props.getProperty("updationMessage")))).getText();
        driver.findElement(By.xpath(props.getProperty("clickOnClosePopup"))).click();
        Thread.sleep(1800);
        int updatedValue = Integer.parseInt(driver.findElement(By.xpath(props.getProperty("updatedbandnuetcount"))).getText());
        if (initialValue < updatedValue) {
            logger.info("cell value is incremented by one number");
        }
        return String.valueOf(updatedValue);
    }


    public String SubclassifiedToHypersegmented() throws InterruptedException {
        super.clickonTab(props.getProperty("wbctab"));
        Subclassification();
        Thread.sleep(1800);
        actions.moveToElement(driver.findElement(By.xpath(props.getProperty("hypersegmented")))).click().build().perform();
        Thread.sleep(1500);
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath(props.getProperty("updateButton")))).click();
        wait.until(visibilityOfElementLocated(By.xpath(props.getProperty("tableContent")))).isDisplayed();
        int initialValue = Integer.parseInt(driver.findElement(By.xpath(props.getProperty("initialcount"))).getText());
        driver.findElement(By.xpath(props.getProperty("clickOnUpdateButton"))).click();
        wait.until(visibilityOfElementLocated(By.xpath(props.getProperty("updationMessage")))).getText();
        driver.findElement(By.xpath(props.getProperty("clickOnClosePopup"))).click();
        Thread.sleep(1500);
        int updatedValue = Integer.parseInt(driver.findElement(By.xpath(props.getProperty("updatedhypersegmentedcount"))).getText());
        if (initialValue < updatedValue) {
            logger.info("hypersegmented value is incremented by one number");
        }

        return String.valueOf(updatedValue);
    }


    public boolean reclassification() {
        props = PropertiesFile.prop;
        driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
        WebElement element = driver.findElement(By.xpath(props.getProperty("firstPatchImage")));
        actions.moveToElement(element).perform();
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath(props.getProperty("clickOnReclassification")))).click();
        driver.manage().timeouts().pageLoadTimeout(10, TimeUnit.SECONDS);
        String textOnEdittab = driver.findElement(By.xpath(props.getProperty("allCellType"))).getText() + ",";
        //System.out.println(textOnEdittab);
        return true;
    }


    public String clickOnReclassification() throws Exception {
        reclassification();
        WebElement neutrophil = wait.until(ExpectedConditions.elementToBeClickable(By.xpath(props.getProperty("cellSelecttion"))));
        actions.moveToElement(neutrophil).build().perform();
        Thread.sleep(1000);
        actions.moveToElement(driver.findElement(By.xpath(props.getProperty("subCellSelection")))).click().build().perform();
        Thread.sleep(1000);
        String reclassifiedCell = wait.until(visibilityOfElementLocated(By.xpath(props.getProperty("selectedreclassifiedcell")))).getText();
        shonitRBCReport=new ShonitRBCReport(driver);
        shonitRBCReport.updateThereport();
//        #clickOnUpdate();
        return reclassifiedCell;
    }


    public String reclassifiedToHypersegmented() throws InterruptedException {
        Thread.sleep(2500);
        reclassification();
        WebElement neutrophil = wait.until(ExpectedConditions.elementToBeClickable(By.xpath(props.getProperty("cellSelecttion"))));
        Thread.sleep(1500);
        actions.moveToElement(neutrophil).build().perform();
        Thread.sleep(1000);
        actions.moveToElement(driver.findElement(By.xpath(props.getProperty("hypersegmented")))).click().build().perform();
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath(props.getProperty("updateButton")))).click();
        wait.until(visibilityOfElementLocated(By.xpath(props.getProperty("tableContent")))).isDisplayed();
        int initialValue = Integer.parseInt(driver.findElement(By.xpath(props.getProperty("initialcount"))).getText());
        driver.findElement(By.xpath(props.getProperty("clickOnUpdateButton"))).click();
        wait.until(visibilityOfElementLocated(By.xpath(props.getProperty("updationMessage")))).getText();
        driver.findElement(By.xpath(props.getProperty("clickOnClosePopup"))).click();
        driver.manage().timeouts().pageLoadTimeout(50, TimeUnit.SECONDS);
        int updatedValue = Integer.parseInt(driver.findElement(By.xpath(props.getProperty("updatedhypersegmentedcount"))).getText());
        if (initialValue < updatedValue) {
            logger.info("hypersegmented  cell count value is incremented by one ");
        }

        return String.valueOf(updatedValue);
    }


    public String lymphocytesToReactiveLymph() throws InterruptedException {
        Thread.sleep(2500);
        reclassification();
        WebElement neutrophil = wait.until(ExpectedConditions.elementToBeClickable(By.xpath(props.getProperty("lymphocyte"))));
        actions.moveToElement(neutrophil).build().perform();
        Thread.sleep(1500);
        actions.moveToElement(driver.findElement(By.xpath(props.getProperty("reactivelymph")))).click().build().perform();
        String hypersegmented = wait.until(ExpectedConditions.elementToBeClickable(By.xpath(props.getProperty("selectedreclassifiedcell")))).getText();
        Thread.sleep(1000);
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath(props.getProperty("updateButton")))).click();
        wait.until(visibilityOfElementLocated(By.xpath(props.getProperty("tableContent")))).isDisplayed();
        int initialValue = Integer.parseInt(driver.findElement(By.xpath(props.getProperty("initialcount"))).getText());
        driver.findElement(By.xpath(props.getProperty("clickOnUpdateButton"))).click();
        wait.until(visibilityOfElementLocated(By.xpath(props.getProperty("updationMessage")))).getText();
        driver.findElement(By.xpath(props.getProperty("clickOnClosePopup"))).click();
        driver.manage().timeouts().pageLoadTimeout(50, TimeUnit.SECONDS);
        int updatedValue = Integer.parseInt(driver.findElement(By.xpath(props.getProperty("updatedhypersegmentedcount"))).getText());
        if (initialValue < updatedValue) {
            logger.info("reactiveLymph cell count value is incremented by one ");
        }

        return String.valueOf(updatedValue);
    }

    public String monocyte() throws InterruptedException {
        Thread.sleep(2500);
        reclassification();
        Thread.sleep(2500);
        actions.moveToElement(driver.findElement(By.xpath(props.getProperty("monocyte")))).click().build().perform();
        // String hypersegmented = wait.until(ExpectedConditions.elementToBeClickable(By.xpath(props.getProperty("selectedreclassifiedcell")))).getText();
        Thread.sleep(1000);
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath(props.getProperty("updateButton")))).click();
        wait.until(visibilityOfElementLocated(By.xpath(props.getProperty("tableContent")))).isDisplayed();
        int initialValue = Integer.parseInt(driver.findElement(By.xpath(props.getProperty("initialMonocytevalue"))).getText());
        driver.findElement(By.xpath(props.getProperty("clickOnUpdateButton"))).click();
        wait.until(visibilityOfElementLocated(By.xpath(props.getProperty("updationMessage")))).getText();
        driver.findElement(By.xpath(props.getProperty("clickOnClosePopup"))).click();
        driver.manage().timeouts().pageLoadTimeout(50, TimeUnit.SECONDS);
        int updatedValue = Integer.parseInt(driver.findElement(By.xpath(props.getProperty("updatedmonocytedcount"))).getText());
        if (initialValue < updatedValue) {
            logger.info("monocyte  cell count value is incremented by one");
        }

        return String.valueOf(updatedValue);
    }


    public String esonophil() throws InterruptedException {
        Thread.sleep(2500);
        reclassification();
        Thread.sleep(1500);
        actions.moveToElement(driver.findElement(By.xpath(props.getProperty("eosinophil")))).click().build().perform();
        //String hypersegmented = wait.until(ExpectedConditions.elementToBeClickable(By.xpath(props.getProperty("selectedreclassifiedcell")))).getText();
        Thread.sleep(1000);
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath(props.getProperty("updateButton")))).click();
        wait.until(visibilityOfElementLocated(By.xpath(props.getProperty("tableContent")))).isDisplayed();
        int initialValue = Integer.parseInt(driver.findElement(By.xpath(props.getProperty("initialcount"))).getText());
        driver.findElement(By.xpath(props.getProperty("clickOnUpdateButton"))).click();
        wait.until(visibilityOfElementLocated(By.xpath(props.getProperty("updationMessage")))).getText();
        driver.findElement(By.xpath(props.getProperty("clickOnClosePopup"))).click();
        driver.manage().timeouts().pageLoadTimeout(50, TimeUnit.SECONDS);
        int updatedValue = Integer.parseInt(driver.findElement(By.xpath(props.getProperty("updatedeosinphilcount"))).getText());
        if (initialValue < updatedValue) {
            logger.info("esonophil cell  count value is incremented by one");
        }

        return String.valueOf(updatedValue);
    }

    public String basophil() throws InterruptedException {
        Thread.sleep(2500);
        reclassification();
        Thread.sleep(2000);
        actions.moveToElement(driver.findElement(By.xpath(props.getProperty("basophil")))).click().build().perform();
        //String hypersegmented = wait.until(ExpectedConditions.elementToBeClickable(By.xpath(props.getProperty("selectedreclassifiedcell")))).getText();
        Thread.sleep(1500);
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath(props.getProperty("updateButton")))).click();
        wait.until(visibilityOfElementLocated(By.xpath(props.getProperty("tableContent")))).isDisplayed();
        int initialValue = Integer.parseInt(driver.findElement(By.xpath(props.getProperty("initialcount"))).getText());
        driver.findElement(By.xpath(props.getProperty("clickOnUpdateButton"))).click();
        wait.until(visibilityOfElementLocated(By.xpath(props.getProperty("updationMessage")))).getText();
        driver.findElement(By.xpath(props.getProperty("clickOnClosePopup"))).click();
        driver.manage().timeouts().pageLoadTimeout(50, TimeUnit.SECONDS);
        int updatedValue = Integer.parseInt(driver.findElement(By.xpath(props.getProperty("updatedbasophilcount"))).getText());
        if (initialValue < updatedValue) {
            logger.info("basophil cell  count value is incremented by one");
        }

        return String.valueOf(updatedValue);
    }


    public String reclassifiedToIGPromyelocytes() throws InterruptedException {
        Thread.sleep(2500);
        reclassification();
        Thread.sleep(1500);
        actions.moveToElement(driver.findElement(By.xpath(props.getProperty("IG")))).click().build().perform();
        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
        actions.moveToElement(driver.findElement(By.xpath(props.getProperty("Promyelocytes")))).click().build().perform();
        //String hypersegmented = wait.until(ExpectedConditions.elementToBeClickable(By.xpath(props.getProperty("selectedreclassifiedcell")))).getText();
        Thread.sleep(1000);
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath(props.getProperty("updateButton")))).click();
        wait.until(visibilityOfElementLocated(By.xpath(props.getProperty("tableContent")))).isDisplayed();
        int initialValue = Integer.parseInt(driver.findElement(By.xpath(props.getProperty("initialcount"))).getText());
        driver.findElement(By.xpath(props.getProperty("clickOnUpdateButton"))).click();
        wait.until(visibilityOfElementLocated(By.xpath(props.getProperty("updationMessage")))).getText();
        driver.findElement(By.xpath(props.getProperty("clickOnClosePopup"))).click();
        driver.manage().timeouts().pageLoadTimeout(50, TimeUnit.SECONDS);
        int updatedValue = Integer.parseInt(driver.findElement(By.xpath(props.getProperty("updatedIGcount"))).getText());
        if (initialValue < updatedValue) {
            logger.info("cell  count value is incremented by one");
        }

        return String.valueOf(updatedValue);
    }

    public String reclassifiedToAtypical() throws InterruptedException {
        Thread.sleep(2500);
        reclassification();
        Thread.sleep(1500);
        actions.moveToElement(driver.findElement(By.xpath(props.getProperty("Atypical")))).click().build().perform();
        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
        actions.moveToElement(driver.findElement(By.xpath(props.getProperty("myloidyblast")))).click().build().perform();
        //String hypersegmented = wait.until(ExpectedConditions.elementToBeClickable(By.xpath(props.getProperty("selectedreclassifiedcell")))).getText();
        Thread.sleep(1000);
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath(props.getProperty("updateButton")))).click();
        wait.until(visibilityOfElementLocated(By.xpath(props.getProperty("tableContent")))).isDisplayed();
        int initialValue = Integer.parseInt(driver.findElement(By.xpath(props.getProperty("initialcount"))).getText());
        driver.findElement(By.xpath(props.getProperty("clickOnUpdateButton"))).click();
        wait.until(visibilityOfElementLocated(By.xpath(props.getProperty("updationMessage")))).getText();
        driver.findElement(By.xpath(props.getProperty("clickOnClosePopup"))).click();
        driver.manage().timeouts().pageLoadTimeout(50, TimeUnit.SECONDS);
        int updatedValue = Integer.parseInt(driver.findElement(By.xpath(props.getProperty("udatedMyloidBlast"))).getText());
        if (initialValue < updatedValue) {
            logger.info("cell  count value is incremented by one");
        }

        return String.valueOf(updatedValue);
    }


    public String reclassifiedToRejectedCell() throws InterruptedException {
        Thread.sleep(2500);
        reclassification();
        Thread.sleep(1500);
        actions.moveToElement(driver.findElement(By.xpath(props.getProperty("rejectedcell")))).click().build().perform();
        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
        //String hypersegmented = wait.until(ExpectedConditions.elementToBeClickable(By.xpath(props.getProperty("selectedreclassifiedcell")))).getText();
        Thread.sleep(1000);
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath(props.getProperty("updateButton")))).click();
        wait.until(visibilityOfElementLocated(By.xpath(props.getProperty("tableContent")))).isDisplayed();
        int initialValue = Integer.parseInt(driver.findElement(By.xpath(props.getProperty("initialcount"))).getText());
        driver.findElement(By.xpath(props.getProperty("clickOnUpdateButton"))).click();
        wait.until(visibilityOfElementLocated(By.xpath(props.getProperty("updationMessage")))).getText();
        driver.findElement(By.xpath(props.getProperty("clickOnClosePopup"))).click();
        driver.manage().timeouts().pageLoadTimeout(50, TimeUnit.SECONDS);
        int updatedValue = Integer.parseInt(driver.findElement(By.xpath(props.getProperty("updatedrejectedcell"))).getText());
        if (initialValue < updatedValue) {
            logger.info("cell  count value is incremented by one");
        }

        return String.valueOf(updatedValue);
    }


    public String reclassifiedToGiantPlatelets() throws InterruptedException {
        Thread.sleep(2500);
        this.reclassification();
        Thread.sleep(1500);
        actions.moveToElement(driver.findElement(By.xpath(props.getProperty("giantplatelet")))).click().build().perform();
        //String hypersegmented = wait.until(ExpectedConditions.elementToBeClickable(By.xpath(props.getProperty("selectedreclassifiedcell")))).getText();
        Thread.sleep(1500);
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath(props.getProperty("updateButton")))).click();
        wait.until(visibilityOfElementLocated(By.xpath(props.getProperty("tableContent")))).isDisplayed();
        int initialValue = Integer.parseInt(driver.findElement(By.xpath(props.getProperty("initialcount"))).getText());
        driver.findElement(By.xpath(props.getProperty("clickOnUpdateButton"))).click();
        wait.until(visibilityOfElementLocated(By.xpath(props.getProperty("updationMessage")))).getText();
        driver.findElement(By.xpath(props.getProperty("clickOnClosePopup"))).click();
        Thread.sleep(1500);
        // switch to platelet tab to verify the giant platelet count
        super.clickonTab(props.getProperty("plttab"));
        // switch to  morphology
        super.clickonTab(props.getProperty("morphology"));
        Thread.sleep(1000);
        int updatedValue = Integer.parseInt(driver.findElement(By.xpath(props.getProperty("updatedGiantPlateletcount"))).getText());
        this.clickonTab(props.getProperty("wbctab"));
        if (initialValue < updatedValue) {
            logger.info("cell  count value is incremented by one");
        }

        return String.valueOf(updatedValue);
    }


    public String reclassifiedToPlateletClumps() throws InterruptedException {
        Thread.sleep(2500);
        this.reclassification();
        Thread.sleep(3500);
        actions.moveToElement(driver.findElement(By.xpath(props.getProperty("plateletClumps")))).click().build().perform();
        //String hypersegmented = wait.until(ExpectedConditions.elementToBeClickable(By.xpath(props.getProperty("selectedreclassifiedcell")))).getText();
        Thread.sleep(1500);
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath(props.getProperty("updateButton")))).click();
        wait.until(visibilityOfElementLocated(By.xpath(props.getProperty("tableContent")))).isDisplayed();
        int initialValue = Integer.parseInt(driver.findElement(By.xpath(props.getProperty("initialcount"))).getText());
        driver.findElement(By.xpath(props.getProperty("clickOnUpdateButton"))).click();
        wait.until(visibilityOfElementLocated(By.xpath(props.getProperty("updationMessage")))).getText();
        driver.findElement(By.xpath(props.getProperty("clickOnClosePopup"))).click();
        Thread.sleep(1500);
        // switch to platelet tab to verify the giant platelet count
        super.clickonTab(props.getProperty("plttab"));
        // switch to  morphology
        super.clickonTab(props.getProperty("morphology"));
        Thread.sleep(1000);
        int updatedValue = Integer.parseInt(driver.findElement(By.xpath(props.getProperty("updatedPlateletClump"))).getText());
        this.clickonTab(props.getProperty("wbctab"));
        if (initialValue < updatedValue) {
            logger.info("cell  count value is incremented by one");
        }

        return String.valueOf(updatedValue);
    }


    public String unclassified() throws InterruptedException {
        Thread.sleep(2500);
        reclassification();
        Thread.sleep(1500);
        actions.moveToElement(driver.findElement(By.xpath(props.getProperty("unclassified")))).click().build().perform();
        //String hypersegmented = wait.until(ExpectedConditions.elementToBeClickable(By.xpath(props.getProperty("selectedreclassifiedcell")))).getText();
        Thread.sleep(1000);
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath(props.getProperty("updateButton")))).click();
        wait.until(visibilityOfElementLocated(By.xpath(props.getProperty("tableContent")))).isDisplayed();
        int initialValue = Integer.parseInt(driver.findElement(By.xpath(props.getProperty("initialcount"))).getText());
        driver.findElement(By.xpath(props.getProperty("clickOnUpdateButton"))).click();
        wait.until(visibilityOfElementLocated(By.xpath(props.getProperty("updationMessage")))).getText();
        driver.findElement(By.xpath(props.getProperty("clickOnClosePopup"))).click();
        driver.manage().timeouts().pageLoadTimeout(50, TimeUnit.SECONDS);
        int updatedValue = Integer.parseInt(driver.findElement(By.xpath(props.getProperty("updatedunclassifiedcount"))).getText());
        if (initialValue < updatedValue) {
            logger.info("unclassified cell  count value is incremented by one");
        }

        return String.valueOf(updatedValue);
    }


    //clicking on Lymphocyte cell for reclassification & subclassification with other cell
   /* public String clickOnLymphocyte(){
       doClick(By.xpath(props.getProperty("LymphocytesCell")));
        return getTextFromElement(By.xpath(props.getProperty("cellnameonpatch")));
    }

    */


    //clicking on Lymphocyte cell for reclassification & subclassification with other cell
    public String clickOnLymphocytes() throws InterruptedException {
        driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);
       return super.clickOnMainCell(props.getProperty("LymphocytesCell"));
    }

    // subclassified Lymphocytes to Reactive Lymph
    public String subclassifiedLymphocyteToReactiveLymph() throws InterruptedException {
        driver.manage().timeouts().pageLoadTimeout(20,TimeUnit.SECONDS);
        super.clickOnMainCell(props.getProperty("LymphocytesCell"));
        clickOnSubclassification();
        Thread.sleep(4000);
        WebElement reactivelymph=driver.findElement(By.xpath(props.getProperty("reactivelymph")));
        actions.moveToElement(reactivelymph).click().build().perform();
        Thread.sleep(1000);
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath(props.getProperty("updateButton")))).click();
        wait.until(visibilityOfElementLocated(By.xpath(props.getProperty("tableContent")))).isDisplayed();
        int initialValue = Integer.parseInt(driver.findElement(By.xpath(props.getProperty("initialcount"))).getText());
        driver.findElement(By.xpath(props.getProperty("clickOnUpdateButton"))).click();
        wait.until(visibilityOfElementLocated(By.xpath(props.getProperty("updationMessage")))).getText();
        driver.findElement(By.xpath(props.getProperty("clickOnClosePopup"))).click();
        driver.manage().timeouts().pageLoadTimeout(50, TimeUnit.SECONDS);
        int updatedValue = Integer.parseInt(driver.findElement(By.xpath(props.getProperty("updatedhypersegmentedcount"))).getText());
        if (initialValue < updatedValue) {
            logger.info("reactiveLymph cell count value is incremented by one ");
        }

        return String.valueOf(updatedValue);
    }

    // reclassified Lymphocytes to neutrophil bandnuet
    public String LymphocytesToHypersegmented() throws InterruptedException {
       this.clickOnLymphocytes();
        return this.reclassifiedToHypersegmented();
    }

    //reclassified lymphocyte to Monocyte

    public String lymphocyteToMonocyte() throws InterruptedException {
        this.clickOnLymphocytes();
        return this.monocyte();
    }


    // reclassified lymphocytes to Eosnophil
    public String lymphocyteToEosnophil() throws InterruptedException {
        this.clickOnLymphocytes();
        return this.esonophil();
    }

    // reclassified lymphocytes to basophill
    public String lymphocyteToBasophill() throws InterruptedException {
       this.clickOnLymphocytes();
        return this.basophil();
    }

    // reclassified lymphocyte to IG
    public String lymphocyteToIGPromyelocytes() throws InterruptedException {
        this.clickOnLymphocytes();
        return this.reclassifiedToIGPromyelocytes();
    }


    // reclassified lymphocyte to Atypical
    public String lymphocyteToAtypical() throws InterruptedException {
        this.clickOnLymphocytes();
        return this.reclassifiedToAtypical();
    }

    //reclassified lymphocyte to rejected cell
    public String lymphocyteToRejectedCell() throws InterruptedException {
        this.clickOnLymphocytes();
        return this.reclassifiedToRejectedCell();
    }


    // reclassified lymphocyte to Giant platelet
    public String lymphocyteToGiantPlatelet() throws InterruptedException {
        this.clickOnLymphocytes();
        return this.reclassifiedToGiantPlatelets();
    }

    // reclassified lymphocyte to platelet clump
    public String lymphocyteToPlateletClump() throws InterruptedException {
        this.clickOnLymphocytes();
        return this.reclassifiedToPlateletClumps();
    }

    public String lymphocyteToUnclassified() throws InterruptedException {
        this.clickOnLymphocytes();
        return this.unclassified();
    }

    // clicked on monocytes on wbc tab
    public String clickOnMonocyte() {
        driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
        return super.clickOnMainCell(props.getProperty("monocytesCell"));
    }

    // reclassified  monocytes to basophil
    public String monocytesToBasophil() throws InterruptedException {
        this.clickOnMonocyte();
        return this.basophil();

    }


    // clicked on ig cell on wbc tab
    public String clickOnIG() {
        driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);
        return super.clickOnMainCell(props.getProperty("IGCell"));
    }


    // subclassified IG to Myelocytes
    public String iGToPromyelocytes() throws InterruptedException {
        this.clickOnSubclassification();
        Thread.sleep(1000);
        actions.moveToElement(driver.findElement(By.xpath(props.getProperty("Myelocytes")))).click().build().perform();
        Thread.sleep(1000);
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath(props.getProperty("updateButton")))).click();
        wait.until(visibilityOfElementLocated(By.xpath(props.getProperty("tableContent")))).isDisplayed();
        int initialValue = Integer.parseInt(driver.findElement(By.xpath(props.getProperty("initialcount"))).getText());
        driver.findElement(By.xpath(props.getProperty("clickOnUpdateButton"))).click();
        wait.until(visibilityOfElementLocated(By.xpath(props.getProperty("updationMessage")))).getText();
        driver.findElement(By.xpath(props.getProperty("clickOnClosePopup"))).click();
        driver.manage().timeouts().pageLoadTimeout(50, TimeUnit.SECONDS);
        int updatedValue = Integer.parseInt(driver.findElement(By.xpath(props.getProperty("Myelocytesupdatecount"))).getText());
        if (initialValue < updatedValue) {
            logger.info("cell value is incremented by one number");
        }
        return String.valueOf(updatedValue);
    }

    // reclassify Ig to BAndnuet
    public String IGToHypersegmented() throws InterruptedException {
        this.clickOnIG();
        return this.reclassifiedToHypersegmented();

    }

    // reclassify IG to Monocyte
    public String iGToMonocyte() throws InterruptedException {
        this.clickOnIG();
        return this.monocyte();
    }

    // reclassify  ig  to basophil
    public String igToBasophil() throws InterruptedException {
        this.clickOnIG();
        return this.basophil();
    }

    //reclassify IG to Eosinophil
    public String iGToEsonophil() throws InterruptedException {
        this.clickOnIG();
        //checkfullfov();
        return this.esonophil();
    }

    // reclassify IG to Atypical
    public String igToAtypical() throws InterruptedException {
        this.clickOnIG();
        return this.reclassifiedToAtypical();
    }


    // ckicked on Atypical/Blast
    public String clickOnAtypicalBlast() {
        driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
        return super.clickOnMainCell(props.getProperty("Atypical/Blast"));
    }



    // subclassified Atypical to myloid blast
    public String subclassifiedAtypicalToMyloidBlast() throws InterruptedException {
        this.clickOnSubclassification();
        actions.moveToElement(driver.findElement(By.xpath(props.getProperty("reactivelymph")))).click().build().perform();
        Thread.sleep(1000);
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath(props.getProperty("updateButton")))).click();
        wait.until(visibilityOfElementLocated(By.xpath(props.getProperty("tableContent")))).isDisplayed();
        int initialValue = Integer.parseInt(driver.findElement(By.xpath(props.getProperty("initialcount"))).getText());
        driver.findElement(By.xpath(props.getProperty("clickOnUpdateButton"))).click();
        wait.until(visibilityOfElementLocated(By.xpath(props.getProperty("updationMessage")))).getText();
        driver.findElement(By.xpath(props.getProperty("clickOnClosePopup"))).click();
        driver.manage().timeouts().pageLoadTimeout(50, TimeUnit.SECONDS);
        int updatedValue = Integer.parseInt(driver.findElement(By.xpath(props.getProperty("Myelocytesupdatecount"))).getText());
        if (initialValue < updatedValue) {
            logger.info("cell value is incremented by one number");
        }
        return String.valueOf(updatedValue);
    }


    // all expand button is visible and its clickable at a time
    public boolean expandAllMaincell() {
        List<WebElement> allexpandbuttons = driver.findElements(By.xpath(props.getProperty("listofexpandbutton")));
        allexpandbuttons.size();
        for (int i = 1; i <= allexpandbuttons.size(); i++) {
            allexpandbuttons.get(i).click();
        }
        return true;
    }


    // functionality of  expand (-) icon on the main cell at WBC tab
    public boolean neutrophilExpandButton() {
        driver.findElement(By.xpath(props.getProperty("expandIcons"))).click();
        driver.findElement(By.xpath(props.getProperty("expandIcons"))).click();
        return wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(props.getProperty("expandIcons")))).isDisplayed();
    }

    // click on  IG  expand button on  wbc tab
    public boolean lymphocytesExpandButton() {
        driver.findElement(By.xpath(props.getProperty("lymphocytesExpandIcon"))).click();
        driver.findElement(By.xpath(props.getProperty("lymphocytesExpandIcon"))).click();
        return waitForElementToDisplay(By.xpath(props.getProperty("lymphocytesExpandIcon"))).isDisplayed();

    }


    // click on  IG  expand button on  wbc tab
    public boolean iGExpandButton() {
        doClick(By.xpath(props.getProperty("IGExpandIcon")));
        doClick(By.xpath(props.getProperty("IGExpandIcon")));
        return waitForElementToDisplay(By.xpath(props.getProperty("IGExpandIcon"))).isDisplayed();
    }

    // click on  IG  expand button on  wbc tab
    public boolean atypicalExpandButton() {
        doClick(By.xpath(props.getProperty("AtypicalExpandIcon")));
        doClick(By.xpath(props.getProperty("AtypicalExpandIcon")));

        return waitForElementToDisplay(By.xpath(props.getProperty("AtypicalExpandIcon"))).isDisplayed();
    }


    // Verify the message for WBC cell extraction in at the bottom of WBC count card
    public String wbcCellExtractionMessage() {
        return getTextFromElement(By.xpath(props.getProperty("extractionmeesage")));
    }

    // Verify the * mark present on the subcell name
    public String starMarkOnSubCell() {
        List<WebElement> allCells = driver.findElements(By.xpath(props.getProperty("allcell")));
        String cellname = "";
        for (WebElement allcell : allCells) {
            if (allCells.contains("*")) {
                cellname = allcell.getText().trim();
            }
        }

        return cellname;
    }


    //verify LYMPHOCYTE cell name is present on references image tab
    public String neutrophilRefImg() throws InterruptedException {
        //doClick(By.xpath(props.getProperty("lymphocytesExpandIcon")));
        super.clickOnMainCell(props.getProperty("NeutrophillCell"));
        this.ClickOnRefImag();
        return dropDownAtRefImg();
    }


    //verify LYMPHOCYTE cell name is present on references image tab
    public String lymphocyteRefImg() throws InterruptedException {
        //doClick(By.xpath(props.getProperty("lymphocytesExpandIcon")));
        super.clickOnMainCell(props.getProperty("LymphocytesCell"));
        this.ClickOnRefImag();
        return dropDownAtRefImg();
    }

    //verify IG cell name is present on references image tab
    public String igReferenceImg() throws InterruptedException {
        //iGExpandButton();
        //doClick(By.xpath(props.getProperty("IGExpandIcon")));
        super.clickOnMainCell(props.getProperty("IGCell"));
        this.ClickOnRefImag();
        return dropDownAtRefImg();
    }

    public String myelocytesReferenceImg() throws InterruptedException {
        // iGExpandButton();
        // doClick(By.xpath(props.getProperty("IGExpandIcon")));
        super.clickOnMainCell(props.getProperty("MyelocytesSubCell"));
        this.ClickOnRefImag();
        return dropDownAtRefImg();
    }

    //verify Atypical cell name is present on references image tab
    public String atypicalReferenceImg() throws InterruptedException {
        // atypicalExpandButton();
        //doClick(By.xpath(props.getProperty("AtypicalExpandIcon")));
        super.clickOnMainCell(props.getProperty("Atypical/Blast"));
        this.ClickOnRefImag();
        return dropDownAtRefImg();

    }

    //verify monocytes cell name is present on references image tab
    public String monocyteReferenceImg() throws InterruptedException {
        // atypicalExpandButton();
        //doClick(By.xpath(props.getProperty("AtypicalExpandIcon")));
        super.clickOnMainCell(props.getProperty("monocytesCell"));
        this.ClickOnRefImag();
        return dropDownAtRefImg();
    }

    //verify myelocytes cell name is present on references image tab


    //verify myloid cell name is present on references image tab
    public String myloidReferenceImg() throws InterruptedException {
        super.clickOnMainCell(props.getProperty("MyloidBlastSubCell"));
        this.ClickOnRefImag();
        return dropDownAtRefImg();
    }

    // comment on first patch
    public boolean commentOnPatch() throws InterruptedException {
        WebElement element = driver.findElement(By.xpath(props.getProperty("firstPatchImage")));
        actions.moveToElement(element).build().perform();
        Thread.sleep(4000);
        doClick(By.xpath(props.getProperty("firstcommentonpatch")));
        Thread.sleep(1500);
        driver.findElement(By.xpath(props.getProperty("wbccommentbox"))).isDisplayed();
        String makeAComment = driver.findElement(By.xpath(props.getProperty("commentinputbutton"))).getText();
        if (makeAComment.contains("Make a comment")) {
            logger.info("make a comment  note text is visible");
        }
        driver.findElement(By.xpath(props.getProperty("commentinputbutton"))).click();
        String remainingCount = driver.findElement(By.xpath(props.getProperty("remainingcount"))).getText();
        if (remainingCount.contains("0/300")) {
            logger.info("0/300 remainig count limitation is present on the textinput area");
        }
        Thread.sleep(2000);
        WebElement textinputarea = driver.findElement(By.xpath(props.getProperty("textareaonpatch")));
        textinputarea.click();
        textinputarea.clear();
        textinputarea.sendKeys(props.getProperty("commentlimitation"));
        wait.until(visibilityOfElementLocated(By.xpath(props.getProperty("cancle")))).isDisplayed();
        Thread.sleep(2300);
        doClick(By.xpath(props.getProperty("Save")));
        Thread.sleep(2000);
        // actions.sendKeys(Keys.PAGE_DOWN).build().perform();

        return driver.findElement(By.xpath(props.getProperty("enteredComment"))).isDisplayed();
    }


    // edit the existing comment
    public String editComment() throws InterruptedException {
        Thread.sleep(2000);
        doClick(By.xpath(props.getProperty("threedotIcon")));
        Thread.sleep(1000);
        WebElement editicon = driver.findElement(By.xpath(props.getProperty("editIcon")));
        actions.moveToElement(editicon).click().build().perform();
        Thread.sleep(1000);
        WebElement commentinput = driver.findElement(By.xpath(props.getProperty("textareaonpatch")));
        commentinput.click();
        commentinput.sendKeys(props.getProperty("comments"));
        Thread.sleep(2500);
        driver.findElement(By.xpath(props.getProperty("Save"))).click();
        Thread.sleep(1000);
        //actions.sendKeys(Keys.PAGE_DOWN).build().perform();
        return driver.findElement(By.xpath(props.getProperty("enteredComment"))).getText();

    }

    // reply tyhe comment
    public boolean commentReply() throws InterruptedException {
        props = PropertiesFile.prop;
        Thread.sleep(1000);
        doClick(By.xpath(props.getProperty("commentreply")));
        for (int i = 0; i <=2; i++) {
            Thread.sleep(2000);
            doClick(By.xpath(props.getProperty("writeAReply")));
            WebElement textinputarea = driver.findElement(By.xpath(props.getProperty("textareaonpatch")));
            textinputarea.click();
            textinputarea.clear();
            textinputarea.sendKeys(props.getProperty("commentlimitation"));
            Thread.sleep(3000);
            doClick(By.xpath(props.getProperty("reply")));
        }
        return true;
    }


    // deleted comment
    public boolean deleteComment() throws InterruptedException {
        doClick(By.xpath(props.getProperty("threedotIcon")));
        Thread.sleep(1000);
        WebElement delete = wait.until(ExpectedConditions.elementToBeClickable(By.xpath(props.getProperty("deleteIcon"))));
        actions.moveToElement(delete).click().build().perform();
        Thread.sleep(1200);
        //actions.sendKeys(Keys.PAGE_DOWN).build().perform();
        boolean commentInvisible = wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath(props.getProperty("enteredComment"))));
        Thread.sleep(1000);
        driver.navigate().refresh();
        return commentInvisible;
    }


    // comenting on Lymphocyte first patch
    public String commentOnLymphocyte() throws InterruptedException {
        Thread.sleep(3000);
        super.clickOnMainCell(props.getProperty("LymphocytesCell"));
        Thread.sleep(3000);
        this.commentOnPatch();
        Thread.sleep(2000);
        this.editComment();
        Thread.sleep(2000);
        this.commentReply();
        String givenComment = driver.findElement(By.xpath(props.getProperty("enteredComment"))).getText();
        Thread.sleep(2000);
        this.deleteComment();
        Thread.sleep(2000);
        return givenComment;
    }

    //comment on Monocytes first patch
    public String commentOnMonocytes() throws InterruptedException {
        Thread.sleep(3500);
        super.clickOnMainCell(props.getProperty("monocytesCell"));
        this.commentOnPatch();
        this.editComment();
        this.deleteComment();
        return driver.findElement(By.xpath(props.getProperty("enteredComment"))).getText();
    }


    // randomly clicking on any image to enter the comment
    public boolean randomlyCommentOnAnyPatch() throws InterruptedException {
        List<WebElement> Wbccells = driver.findElements(By.xpath("//table//tbody//tr//td[1]/span"));
        List<WebElement> wbccount = driver.findElements(By.xpath("//table//tbody//tr//td[2]"));
        // int k=0;
        for (int i = 0; i <= Wbccells.size() -4; i++) {
            Wbccells.get(i).click();
            Thread.sleep(4000);
            this.commentOnPatch();
            Thread.sleep(3000);
            this.editComment();
            Thread.sleep(2000);
            this.commentReply();
            Thread.sleep(2000);
            this.deleteComment();
        }
        Thread.sleep(2000);


        return true;
    }


    //  verify presence of image setting
    public String imageSettingIcon() throws InterruptedException {
        Thread.sleep(3500);
        WebElement imageSetting = wait.until(ExpectedConditions.elementToBeClickable(By.xpath(props.getProperty("imagesetting"))));
        if (imageSetting.isDisplayed()) {
            imageSetting.click();
        }
        return imageSetting.getText();
    }


    //scrolling right side to increase image size
    public boolean rightSideImgSroll() throws InterruptedException {
        WebElement bydefaultImgPosition = driver.findElement(By.xpath(props.getProperty("bydefaultimagpointingposition")));
        Dimension offsetDimension = bydefaultImgPosition.getSize();
        System.out.println(offsetDimension);
        // if(offsetDimension=50)
        Thread.sleep(1000);
        actions.dragAndDropBy(bydefaultImgPosition, 80, 0).perform();
        return true;
    }

    //scrolling left side to decrease  image size
    public boolean leftSideImgSroll() throws InterruptedException {
        WebElement bydefaultImgPosition = driver.findElement(By.xpath(props.getProperty("bydefaultimagpointingposition")));
        Dimension offsetDimension = bydefaultImgPosition.getSize();
        System.out.println(offsetDimension);
        // if(offsetDimension=50)
        Thread.sleep(1000);
        actions.dragAndDropBy(bydefaultImgPosition, -100, 0).perform();
        Thread.sleep(1000);
        driver.findElement(By.xpath(props.getProperty("resetImg"))).click();
        return true;
    }

    // increase the image brightness
    public boolean rightSideScrollBrightness() throws InterruptedException {
        Thread.sleep(1500);
        doClick(By.xpath(props.getProperty("imagesetting")));
        Thread.sleep(1500);
        WebElement bydefaultbrightPosition = driver.findElement(By.xpath(props.getProperty("brightnessPoiniting")));
        Dimension offsetDimension = bydefaultbrightPosition.getSize();
        System.out.println(offsetDimension);
        // if(offsetDimension=50)
        Actions actions = new Actions(driver);
        Thread.sleep(1500);
        actions.dragAndDropBy(bydefaultbrightPosition, 100, 0).perform();
        Thread.sleep(2500);
        // driver.findElement(By.xpath(props.getProperty("resetImg"))).click();
        return true;
    }


    // decrease the image  brightness
    public boolean decreaseBrightness() throws InterruptedException {
        doClick(By.xpath(props.getProperty("imagesetting")));
        Thread.sleep(1500);
        WebElement bydefaultImgPosition = driver.findElement(By.xpath(props.getProperty("brightnessPoiniting")));
        Dimension offsetDimension = bydefaultImgPosition.getSize();
        System.out.println(offsetDimension);
        // if(offsetDimension=50)
        Actions actions = new Actions(driver);
        Thread.sleep(1000);
        actions.dragAndDropBy(bydefaultImgPosition, -100, 0).perform();
        driver.findElement(By.xpath(props.getProperty("resetImg"))).click();
        Thread.sleep(1000);
        return true;
    }

    //increasing image contrast
    public boolean increaseImgContrast() throws InterruptedException {
        Thread.sleep(1500);
        doClick(By.xpath(props.getProperty("imagesetting")));
        Thread.sleep(1500);
        WebElement bydefaultContrastPosition = driver.findElement(By.xpath(props.getProperty("contrastSetting")));
        Dimension offsetDimension = bydefaultContrastPosition.getSize();
        System.out.println(offsetDimension);
        // if(offsetDimension=50)
        Actions actions = new Actions(driver);
        Thread.sleep(1000);
        actions.dragAndDropBy(bydefaultContrastPosition, 100, 0).perform();
        Thread.sleep(2000);
        //  driver.findElement(By.xpath(props.getProperty("resetImg"))).click();
        return true;
    }

    //decreasing image contrast
    public boolean decreasingImgContrast() throws InterruptedException {
        // Thread.sleep(1500);
        doClick(By.xpath(props.getProperty("imagesetting")));
        Thread.sleep(1000);
        WebElement bydefaultContrastPosition = driver.findElement(By.xpath(props.getProperty("contrastSetting")));
        Dimension offsetDimension = bydefaultContrastPosition.getSize();
        System.out.println(offsetDimension);
        // if(offsetDimension=50)
        Actions actions = new Actions(driver);
        Thread.sleep(1000);
        actions.dragAndDropBy(bydefaultContrastPosition, -100, 0).perform();
        Thread.sleep(1000);
        driver.findElement(By.xpath(props.getProperty("resetImg"))).click();
        return true;
    }

    // combination of image setting
    public boolean combinationOfImgSetting() throws InterruptedException {
        Thread.sleep(1500);
        doClick(By.xpath(props.getProperty("imagesetting")));
        Thread.sleep(2500);
        WebElement bydefaultContrastPosition = driver.findElement(By.xpath(props.getProperty("contrastSetting")));
        Thread.sleep(1000);
        actions.dragAndDropBy(bydefaultContrastPosition, -80, 0).build().perform();
        WebElement bydefaultImgPosition = driver.findElement(By.xpath(props.getProperty("brightnessPoiniting")));
        Thread.sleep(2000);
        actions.dragAndDropBy(bydefaultImgPosition, 80, 0).build().perform();
        Thread.sleep(1000);
        driver.findElement(By.xpath(props.getProperty("resetImg"))).click();
        // driver.switchTo().defaultContent();
        return true;
    }


    public boolean rightandleftSideImgSroll() throws InterruptedException {
        List<WebElement> wbccells = driver.findElements(By.xpath("//table//tbody//tr//td[1]/span"));
        for (int i = 0; i <= wbccells.size()-4; i++) {
            Thread.sleep(1000);
            wbccells.get(i).click();
            Thread.sleep(2000);
            WebElement imageSetting = wait.until(ExpectedConditions.elementToBeClickable(By.xpath(props.getProperty("imagesetting"))));
            imageSetting.click();
            WebElement bydefaultImgPosition = driver.findElement(By.xpath(props.getProperty("bydefaultimagpointingposition")));
            Dimension offsetDimension = bydefaultImgPosition.getSize();
            System.out.println(offsetDimension);
            Actions actions = new Actions(driver);
            Thread.sleep(5000);
            actions.dragAndDropBy(bydefaultImgPosition, 80, 0).perform();
            WebElement bydefaultImgPosition1 = driver.findElement(By.xpath(props.getProperty("bydefaultimagpointingposition")));
            Thread.sleep(5000);
            actions.dragAndDropBy(bydefaultImgPosition1, -80, 0).perform();
            Thread.sleep(5000);
            driver.findElement(By.xpath("//i[@class='material-icons replay-icon']")).click();
        }
        return true;
    }


    // increasing and decresing  the image brightness
    public boolean rightandleftSideScrollBrightness() throws InterruptedException {
        List<WebElement> rbccells = driver.findElements(By.xpath("//table//tbody//tr//td[1]/span"));
        for (int i = 0; i <= rbccells.size() - 4; i++) {
            rbccells.get(i).click();
            Thread.sleep(5000);
            WebElement imageSetting = wait.until(ExpectedConditions.elementToBeClickable(By.xpath(props.getProperty("imagesetting"))));
            imageSetting.click();
            WebElement bydefaultbrightPosition = driver.findElement(By.xpath(props.getProperty("brightnessPoiniting")));
            Dimension offsetDimension = bydefaultbrightPosition.getSize();
            System.out.println(offsetDimension);
            // if(offsetDimension=50)
            Actions actions = new Actions(driver);
            actions.dragAndDropBy(bydefaultbrightPosition, 80, 0).perform();
            Thread.sleep(5000);
            WebElement bydefaultbrightPosition1 = driver.findElement(By.xpath(props.getProperty("brightnessPoiniting")));
            Thread.sleep(5000);
            actions.dragAndDropBy(bydefaultbrightPosition1, -80, 0).perform();
            Thread.sleep(5000);
            driver.findElement(By.xpath(props.getProperty("resetImg"))).click();
        }
        return true;
    }

    //increasing and decreasing image contrast
    public boolean increaseanddecreaseImgContrast() throws InterruptedException {
        List<WebElement> rbccells = driver.findElements(By.xpath("//table//tbody//tr//td[1]/span"));
        for (int i = 0; i <= rbccells.size() - 4; i++) {
            rbccells.get(i).click();
            Thread.sleep(5000);
            WebElement imageSetting = wait.until(ExpectedConditions.elementToBeClickable(By.xpath(props.getProperty("imagesetting"))));
            imageSetting.click();
            WebElement bydefaultContrastPosition = driver.findElement(By.xpath(props.getProperty("contrastSetting")));
            Dimension offsetDimension = bydefaultContrastPosition.getSize();
            System.out.println(offsetDimension);
            // if(offsetDimension=50)
            Actions actions = new Actions(driver);
            actions.dragAndDropBy(bydefaultContrastPosition, 80, 0).perform();
            Thread.sleep(5000);
            WebElement bydefaultContrastPosition1 = driver.findElement(By.xpath(props.getProperty("contrastSetting")));
            Thread.sleep(5000);
            actions.dragAndDropBy(bydefaultContrastPosition1, -80, 0).perform();
            Thread.sleep(5000);
            driver.findElement(By.xpath(props.getProperty("resetImg"))).click();
        }
        return true;
    }

//
//    public boolean clickOnExpandButtonInWbc() throws Exception {
//        props = PropertiesFile.prop;
//        String firstPatchImage = "//img[@id='patchImg0']";
//        String secondPatchImage = "//img[@id='patchImg1']";
//        String thirdPatchImage = "//img[@id='patchImg2']";
//        String forthPatchImage = "//img[@id='patchImg3']";
//        String fifthPatchImage = "//img[@id='patchImg4']";
//        String firstexpandview = "//div[@class='position-relative']//box//img[@id='patchImg0']/following-sibling::div[@class='hover-show full-patch ng-star-inserted']";
//        String secondexpandview = "//div[@class='position-relative']//box//img[@id='patchImg1']/following-sibling::div[@class='hover-show full-patch ng-star-inserted']";
//        String thirdexpandview = "//div[@class='position-relative']//box//img[@id='patchImg2']/following-sibling::div[@class='hover-show full-patch ng-star-inserted']";
//        String forthexpandview = "//div[@class='position-relative']//box//img[@id='patchImg3']/following-sibling::div[@class='hover-show full-patch ng-star-inserted']";
//        String fifthexpandview = "//div[@class='position-relative']//box//img[@id='patchImg4']/following-sibling::div[@class='hover-show full-patch ng-star-inserted']";
//        String[] expand = {firstexpandview, secondexpandview, thirdexpandview, forthexpandview, fifthexpandview};
//        String[] patches = {firstPatchImage, secondPatchImage, thirdPatchImage, forthPatchImage, fifthPatchImage};
//        List<WebElement> wbccells = driver.findElements(By.xpath("//table/tbody//tr//td[1]//span"));
//        List<WebElement> wbccount = driver.findElements(By.xpath("//table//tbody//tr//td[3]"));
//        // int k=0;
//        for (int i = 0; i <= wbccells.size() - 1; i++) {
//            Thread.sleep(3000);
//            String count = wbccount.get(i).getText();
//            int countofcell = 0;
//            try {
//                countofcell = Integer.parseInt(Arrays.toString(count.split("%")));
//            } catch (NumberFormatException e) {
//            }
//            if (countofcell != 0) {
//                wbccells.get(i).click();
//                Actions actions = new Actions(driver);
//                if (countofcell >= 5) {
//                    for (int j = 0; j <= 4; j++) {
//                        WebElement element = driver.findElement(By.xpath(patches[j]));
//                        actions.moveToElement(element).perform();
//                        wait.until(ExpectedConditions.elementToBeClickable(By.xpath(expand[j]))).click();
//                        // driver.manage().timeouts().pageLoadTimeout(20, TimeUnit.SECONDS);
//                        WebElement canvasVisibility = wait.until(visibilityOfElementLocated(By.xpath(props.getProperty("ImageVisibility"))));
//                        canvasVisibility.isDisplayed();
//                        Thread.sleep(2000);
//                        actions.moveToElement(canvasVisibility).build().perform();
//                        //((JavascriptExecutor) driver ).executeScript("arguments[0].scrollIntoView(true);" ,canvasVisibility);
//                        String text = driver.findElement(By.xpath(props.getProperty("extractedCellText"))).getText();
//                        microscopicview.verifyImageZoomIn();
//                        microscopicview.verifyZoomouticon();
//                        microscopicview.verifyZoomInicon();
//                        microscopicview.verifyRESETicon();
//                        microscopicview.verifypaginationtextbox();
//                        if (countofcell > 6) {
//                            microscopicview.verifygotobottomicon();
//                        }
//                        // m.verifygotoupicon();
//                        wait.until(ExpectedConditions.elementToBeClickable(By.xpath(props.getProperty("clickOnClose")))).click();
//                        driver.manage().timeouts().pageLoadTimeout(10, TimeUnit.SECONDS);
//                        // k=k+1;
//                    }
//                }
//            }
//        }
//        return true;
//
//    }


    // visibility of send button on selected reviewer
    public boolean sendButton() {
        WebElement sendIcon = driver.findElement(By.xpath(props.getProperty("send")));
        if (sendIcon.isDisplayed()) {
            sendIcon.click();
        }
        String message = driver.findElement(By.xpath(props.getProperty("sendingpopupmessage"))).getText();
        if (message.contains("select image sent for review")) {
        }
        return true;
    }


    // visibility of cancel button on selected reviewer while sending the patch for reviewer
    public boolean cancelButton() {

        WebElement cancel = driver.findElement(By.xpath(props.getProperty("cancelButton")));
        if (cancel.isDisplayed()) {
            cancel.click();
        }
        return true;
    }


    //Verify whether the user is able to send a single patch for review
    public boolean singlePatchForReview() throws InterruptedException {
        Thread.sleep(4000);
        List<WebElement> listOfPatches = driver.findElements(By.xpath("//div[@class='position-relative']//img"));
        System.out.println(listOfPatches.size());
        for (int i = 0; i <= listOfPatches.size() - 1; i++) {
            //listOfPatches.get(2).click();
            Thread.sleep(2000);
            actions.keyDown(Keys.SHIFT).click(listOfPatches.get(2)).keyUp(Keys.SHIFT).build().perform();
            break;
        }

        WebElement status = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(props.getProperty("sendIcon"))));
        if (!status.isEnabled()) ;

        return true;
    }

//            doClick(By.xpath(props.getProperty("sendIcon")));


    // two patches are selected from any cell type of wbc tab to review the patches
    public String patchForReview() throws InterruptedException {
        Thread.sleep(4000);
        super.clickOnMainCell(props.getProperty("LymphocytesCell"));
        Thread.sleep(5000);
        List<WebElement> listOfPatches = driver.findElements(By.xpath("//div[@class='position-relative']//img"));
        System.out.println(listOfPatches.size());
        for (int i = 0; i <= listOfPatches.size() - 1; i++) {
            // listOfPatches.get(i).click();
            Thread.sleep(2000);
            actions.keyDown(Keys.SHIFT).click(listOfPatches.get(2)).keyUp(Keys.SHIFT).build().perform();
            Thread.sleep(1000);
            actions.keyDown(Keys.SHIFT).click(listOfPatches.get(4)).keyUp(Keys.SHIFT).build().perform();
            break;
        }

        Thread.sleep(2000);
        doClick(By.xpath(props.getProperty("sendIcon")));
        Thread.sleep(1800);
        WebElement patchViewReviewer = driver.findElement(By.xpath(props.getProperty("PatchViewReviewer")));
        String placeholderText = patchViewReviewer.getText();
        if (placeholderText.contains("Search with Username or Email ID")) {
            logger.info("pass");
        }
        if (patchViewReviewer.isDisplayed()) {
            patchViewReviewer.click();
            patchViewReviewer.sendKeys(props.getProperty("username7"));
        }
        Thread.sleep(2000);

        List<WebElement> reviewerNames = driver.findElements(By.cssSelector(props.getProperty("dropdownvalues")));
        for (WebElement reviewerName : reviewerNames) {
            reviewerValue = reviewerName.getText().trim();
            System.out.println(reviewerName);
            if (reviewerValue.startsWith(props.getProperty("reviewerMailId"))) {
                reviewerName.click();
                break;

            }
        }
        driver.findElement(By.xpath(props.getProperty("deselectReviewer"))).click();
        Thread.sleep(2500);
        WebElement patchViewReviewer1 = driver.findElement(By.xpath(props.getProperty("patchReviewer2")));
        patchViewReviewer1.click();
        patchViewReviewer1.sendKeys(props.getProperty("secondReviewerMailId"));
        Thread.sleep(2000);
        actions.moveToElement(driver.findElement(By.xpath(props.getProperty("secondReviewer")))).click().build().perform();
        Thread.sleep(1000);
        patchViewReviewer1.sendKeys(props.getProperty("username9"));
        actions.moveToElement(driver.findElement(By.xpath(props.getProperty("secondReviewer")))).click().build().perform();
        String reviewername = wait.until(visibilityOfElementLocated(By.xpath(props.getProperty("assignedReviewerPatchView")))).getText();
        // sendButton();
        return reviewername;
    }


    public boolean clickOnCancel() {
        cancelButton();
        return true;
    }


    // selecting multiple reviewer to review the patches
    public String selectMultipleReviewer() throws InterruptedException {
        WebElement againSearchReviewr = driver.findElement(By.xpath(props.getProperty("patchReviewer2")));
        againSearchReviewr.sendKeys(props.getProperty("username4"));
        Thread.sleep(2000);
        List<WebElement> revieweRNames = driver.findElements(By.cssSelector(props.getProperty("dropdownvalues")));
        for (WebElement reviewerName : revieweRNames) {
            for (int i = 0; i <= revieweRNames.size() - 1; i++) {
                revieweRNames.get(i).getText();
                reviewerValue = reviewerName.getText().trim();
                System.out.println(revieweRNames);
                if (reviewerValue.startsWith(props.getProperty("reviewerMailIds"))) {
                    reviewerName.click();
                    break;
                }
            }
        }

        String reviewername = wait.until(visibilityOfElementLocated(By.xpath(props.getProperty("assignedReviewerPatchView")))).getText();
        sendButton();
        Thread.sleep(4000);
        return reviewername;
    }


    public String allPatchForReview() throws InterruptedException {
        Thread.sleep(4000);
        super.clickOnMainCell(props.getProperty("LymphocytesCell"));
        Thread.sleep(5000);
        List<WebElement> listOfPatches = driver.findElements(By.xpath("//div[@class='position-relative']//img"));
        System.out.println(listOfPatches.size());
        for (int i = 0; i <= listOfPatches.size() - 1; i++) {
            // listOfPatches.get(i).click();
            Thread.sleep(1500);
            actions.keyDown(Keys.SHIFT).click(listOfPatches.get(i)).keyUp(Keys.SHIFT).build().perform();
            Thread.sleep(1000);

        }
        Thread.sleep(2000);
        driver.findElement(By.xpath(props.getProperty("sendIcon"))).click();
        Thread.sleep(1800);
        WebElement patchViewReviewer = driver.findElement(By.xpath(props.getProperty("PatchViewReviewer")));
        String placeholderText = patchViewReviewer.getText();
        if (placeholderText.contains("Search with Username or Email ID")) {
            logger.info("pass");
        }
        if (patchViewReviewer.isDisplayed()) {
            patchViewReviewer.click();
            patchViewReviewer.sendKeys(props.getProperty("username7"));
            Thread.sleep(1000);
        }
        List<WebElement> reviewerNames = driver.findElements(By.cssSelector(props.getProperty("dropdownvalues")));
        Thread.sleep(1000);
        for (WebElement reviewerName : reviewerNames) {
            reviewerValue = reviewerName.getText().trim();
            if (reviewerValue.startsWith(props.getProperty("username5"))) {
                reviewerName.click();
                break;
            }
        }

        selectMultipleReviewer();
        // doClick(By.xpath(props.getProperty("send")));
        String reviewer = wait.until(visibilityOfElementLocated(By.xpath(props.getProperty("assignedReviewerPatchView")))).getText();

        return reviewer;

    }






















































    public String modifiedReportAfterAssignement() throws InterruptedException {
        props = PropertiesFile.prop;
        Thread.sleep(1000);
        return wait.until(visibilityOfElementLocated(By.xpath(props.getProperty("modifiedReport")))).getText();
        //System.out.println(Modify);

    }


    public String CorrectionCountUpdation() {

        WebElement summaryTab = driver.findElement(By.xpath(props.getProperty("summaryTab")));
        summaryTab.click();
        WebElement bandNeutInputtField = driver.findElement(By.xpath(props.getProperty("bandNeutCorrectionFiled")));
        bandNeutInputtField.click();
        bandNeutInputtField.clear();
        bandNeutInputtField.sendKeys("100");
        bandNeutInputtField.sendKeys(Keys.ENTER);
        driver.findElement(By.xpath(props.getProperty("updateButton"))).click();
        wait.until(visibilityOfElementLocated(By.xpath(props.getProperty("tableContent")))).isDisplayed();
        driver.findElement(By.xpath(props.getProperty("clickOnUpdateButton"))).click();
        //Update Report Successful

        String popupMessage = driver.findElement(By.xpath(props.getProperty("updationMessage"))).getText();
        driver.findElement(By.xpath(props.getProperty("clickOnClosePopup"))).click();
        return popupMessage;
    }


    public String clickOnExpandButton() throws InterruptedException {
        props = PropertiesFile.prop;
        WebElement element = driver.findElement(By.xpath(props.getProperty("firstPatchImage")));
        actions.moveToElement(element).perform();
        driver.findElement(By.xpath(props.getProperty("clickOnViewFullImage"))).click();
        WebElement canvasVisibility = wait.until(visibilityOfElementLocated(By.xpath(props.getProperty("ImageVisibility"))));
        canvasVisibility.isDisplayed();
        Thread.sleep(2000);
        actions.moveToElement(canvasVisibility).build().perform();
        String text = getTextFromElement(By.xpath(props.getProperty("extractedCellText")));
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath(props.getProperty("clickOnClose")))).click();
        driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
        return text;
    }

    public boolean navigationInFullPatchView() {
        props = PropertiesFile.prop;
        doClick(By.xpath(props.getProperty("navigateToWBC")));
        doClick(By.xpath(props.getProperty("navigateToRBC")));
        doClick(By.xpath(props.getProperty("navigateToPlatelet")));
        doClick(By.xpath(props.getProperty("navigateToWBC")));
        doClick(By.xpath(props.getProperty("navigateToRBC")));
        doClick(By.xpath(props.getProperty("clickOnClose")));
        driver.manage().timeouts().pageLoadTimeout(10, TimeUnit.SECONDS);
        return true;
    }


    public String approveReport() {
        driver.findElement(By.xpath(props.getProperty("approveButton"))).click();
        WebElement commentTextArea = driver.findElement(By.xpath(props.getProperty("ApproveComment")));
        commentTextArea.click();
        commentTextArea.sendKeys("report approved");
        commentTextArea.sendKeys(Keys.ENTER);
        driver.findElement(By.xpath(props.getProperty("clickOnApprove"))).click();
        driver.navigate().refresh();
        String approvedby = driver.findElement(By.xpath(props.getProperty("reassignment"))).getText();
        System.out.println(approvedby);
        return approvedby;

    }


    //collect table data
    public void getWBCAbsoluterowsNew() throws InterruptedException {
        this.WBCdata = super.collectTableData(props.getProperty("wbcrows"), props.getProperty("wbcheaders"));
    }

    //Get list of rows in External metrics
    public Map<String, Map<String, String>> sendWBCAbsoluterows() throws InterruptedException {
        if (this.WBCdata.size() == 0)
            this.getWBCAbsoluterowsNew();
        return this.WBCdata;
    }

    //Get total percentage of WBC absolute
    public boolean verifyWBCAbsolutePercentageTotal() throws InterruptedException {
        props = PropertiesFile.prop;
        return super.verifyTotalPercentageAndCount(props.getProperty("wbcrows"));
    }

    //Validate date for wbc absolute table
    public boolean VerifyWBCAbsoluteTableData(String product) throws Exception {
        props = PropertiesFile.prop;
        this.getWBCAbsoluterowsNew();
        ArrayList<String> columns = new ArrayList<String>();
        columns.add("Name");
        columns.add("Count");
        columns.add("Percentage");
        return super.createCSVFortable(product, WBCdata, "WBCAbsoluteCounts", columns);
    }

//---------------------------------- Report Metrics ------------------------------

    //Get header of Shonit Metrics
    public String getReportedMetricsColumns() throws InterruptedException {
        props = PropertiesFile.prop;
        return wait.until(visibilityOfElementLocated(
                By.cssSelector(props.getProperty("reportedheader")))).getText();
    }

    //Get list of rows in Shonit metrics
    public String getReportedMeticsRows() throws InterruptedException {
        String listofrows = super.gettablerows(props.getProperty("reportedrows"));
        return listofrows;
    }

    //collect table data
    public void getReportedMeticsRowsNew() throws InterruptedException {
        this.Reportdata = super.collectTableData(props.getProperty("reportedrows"), props.getProperty("reportedheaders"));
    }

    //Validate date for wbc absolute table
    public boolean VerifyReportedMeticsTableData(String product) throws Exception {
        props = PropertiesFile.prop;
        this.getReportedMeticsRowsNew();
        ArrayList<String> columns = new ArrayList<String>();
        columns.add("Ref");
        columns.add("Percentage");
        columns.add("Value");
        columns.add("Unit");
        return super.createCSVFortable(product, Reportdata, "MandaraReportedMetics", columns);
    }


    public Boolean reclassificationOfClumpTOGiant(String cell11) throws InterruptedException
    {
        props=PropertiesFile.prop;

        Boolean flag=false;


        String CountOFGiantPlatelet=driver.findElement(By.xpath(props.getProperty("CountOFPlateletClump"))).getText();
        int Count=Integer.parseInt(CountOFGiantPlatelet);
        if(Count!=0) {

            String CountOFPlateletClump = driver.findElement(By.xpath(props.getProperty("CountOFGiantPlatelet"))).getText();
            int Beforecount = Integer.parseInt(CountOFPlateletClump);
            Thread.sleep(2500);
          //  reclassification(cell11);
            Thread.sleep(2000);
            actions.moveToElement(driver.findElement(By.xpath(props.getProperty("GiantPlateletNote")))).click().build().perform();

            Thread.sleep(1500);
            wait.until(ExpectedConditions.elementToBeClickable(By.xpath(props.getProperty("updateButton")))).click();
            wait.until(visibilityOfElementLocated(By.xpath(props.getProperty("tableContent")))).isDisplayed();
            int initialValue = Integer.parseInt(driver.findElement(By.xpath(props.getProperty("initialcount"))).getText());
            driver.findElement(By.xpath(props.getProperty("clickOnUpdateButton"))).click();
            wait.until(visibilityOfElementLocated(By.xpath(props.getProperty("updationMessage")))).getText();
            driver.findElement(By.xpath(props.getProperty("clickOnClosePopup"))).click();
            //shonitRBCReport.updateThereport();
            driver.manage().timeouts().pageLoadTimeout(50, TimeUnit.SECONDS);
            // int updatedValue = Integer.parseInt(driver.findElement(By.xpath(props.getProperty("updatedbasophilcount"))).getText());
            Thread.sleep(3000);
            //clickonpltMorphologyTab();
            Thread.sleep(3000);
            String CountOFPlateletClump1 = driver.findElement(By.xpath(props.getProperty("CountOFGiantPlatelet"))).getText();
            int Aftercount = Integer.parseInt(CountOFPlateletClump1);
            System.out.println("Before reclassification count is"+Beforecount);
            System.out.println("After reclassification count is"+Aftercount);
            if (Aftercount == Beforecount + 1) {
                flag = true;
            } else {
                flag = false;
            }
        }else {
            flag=true;
            System.out.println("Count is zero so reclassification was not handled");
        }

        System.out.println("reclassified  happened successfully from Giant Platelet  to Platelet clump  is verified ");

        return flag;
    }












}

