package com.Common;
import com.data.Shonit_data.PropertiesFile;
import com.utilities.BrowserSetUp;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import java.util.List;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

public class HappyListReportTest extends BrowserSetUp {

    public Properties props;
    public ListReport listreport;
    private final Logger logger = LogManager.getLogger(HappyListReportTest.class);
    public BrowserSetUp pageload;
    boolean productcard;

    @BeforeSuite
    public void setUp() throws Exception {
        driver = getDriver();
        listreport = new ListReport(driver);
        props = PropertiesFile.prop;
        productcard=false;
        PropertiesFile.readShonitListReportFile();

    }
 
    
    //Click on Shonit List Report
    @Parameters({"product"})
    @Test(priority = 2)
    public void clickonListReportTest(String product) throws InterruptedException {
    	//Thread.sleep(3000);
        driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
    	test = extent.createTest("List Report Test");
        Assert.assertTrue(listreport.clickonListReport("Shonit"));
        logger.info("Clicked on List Report Successfully to load");
    }


    //Verify the List Report Page loaded
    @Test(priority = 3)
    public void visibilityOfVersionCard() throws InterruptedException {
    	if(listreport.verifyVersionCard()) {
    		Assert.assertTrue(true);
    		logger.info("about app is opened");
    		productcard=true;
    	}
    }
    
    //Verify the List Report Page loaded
    @Test(priority = 5)
    public void visibilityOfPlateformVersion() throws InterruptedException {
    	if(productcard) {
    		Assert.assertTrue(listreport.verifyPlateformVersion().contains(props.getProperty("plateformversiontext")));
    		logger.info("plateform version is verified");
    	}
    }
    @Test(priority = 15)
    public void visibilityOfHelpIcon(){
        if(productcard){
            Assert.assertTrue(listreport.verifyHelpButton().contains(props.getProperty("helpbuttontext")));
            logger.info("help icon is verified");
            driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
        }
    }
    @Test(priority = 17,enabled = true)
    public void VerifyClickOnNotificationIcon() throws InterruptedException {
        Assert.assertTrue(listreport.verifyNotificationIcon("Shonit"));
        logger.info("Clicked on notification icon Successfully ");
    }

    //Verify the List Report Page loaded
    @Test(priority = 7)
    public void visibilityOfProductName() throws InterruptedException {
    	if(productcard) {
    		Assert.assertTrue(listreport.verifyProductName().contains(props.getProperty("productnametext")));
    		logger.info("product name is verified");
    	}
    } 
    
    //Verify the List Report Page loaded
    @Test(priority = 9)
    public void visibilityOfSoftwareVersion() throws InterruptedException {
    	if(productcard) {
    		Assert.assertTrue(listreport.verifySoftwareVersion().contains(props.getProperty("softwareversiontext")));
    		logger.info("software version is verified");
    	}
    } 
    
    //Verify the List Report Page loaded
    @Test(priority = 11)
    public void closeproductVersionCard() throws InterruptedException {
    	if(productcard) {
    		Assert.assertTrue(listreport.closeproductVersionCard());
    		logger.info("about app is closed");
    	}
    }
    
    //Verify the List Report Page loaded
    @Test(priority = 13)
    public void verifyListReportpage() throws InterruptedException {
    	//Thread.sleep(2000);
    	props = PropertiesFile.prop;
        String verifyListReportpage = listreport.verifyListReportPage();
        Assert.assertEquals(verifyListReportpage,"Analysis Reports");
        logger.info("List Report page loaded");
    }
  /*  @Test(priority = 19, enabled = true)
    public void verifyVisibiliotyOfAutomaticFlag() {
        // String flagColour = String.valueOf(listreport.verifyAutomaticFlag());
        String actualText =listreport.verifyFlaggedWithColor();
        Assert.assertEquals(actualText," ");
        logger.info(" automatically flag colour is verified");




    }*/


}
