package com.Common;

import com.data.Shonit_data.PropertiesFile;
import com.utilities.BrowserSetUp;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import java.awt.*;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

public class SystemReleaseTest extends BrowserSetUp {

    public SystemRelease systemRelease;
    public Properties props;
    String sideproductnames = "";


    private final Logger logger = LogManager.getLogger(SystemReleaseTest.class);

    @BeforeSuite
    public void setUp() throws Exception {
        driver = getDriver();
        systemRelease = new SystemRelease(driver);
        props = PropertiesFile.prop;

    }


    @Test(priority = 1, enabled = true)
    public void verifySideMenu() throws InterruptedException {
        String selectTheProduct = systemRelease.clickonsidemenu();
        Assert.assertEquals(selectTheProduct, "System Release Configuration");
        logger.info("common settings options are taken from side menu and clicked on system release is verified");
    }

    @Test(priority = 3, enabled = true)
    public void verifyFunctionalityOfSelectTheProduct() throws InterruptedException {
        String selectTheProduct = systemRelease.SelectTheProduct();
        Assert.assertEquals(selectTheProduct, "QA System ReleaseVersion NumberRelease DateDescription");
        logger.info("shonit is selected in a drop down");
    }

    @Test(priority = 6, enabled = true)
    public void verifyClickOnNewRelease() throws InterruptedException {

        String newReleaseText = systemRelease.clickOnNewRelease();
        Assert.assertEquals(newReleaseText, "New System Release");
        logger.info(" clicked on new Release button successfully");
    }

    @Test(priority = 8, enabled = true)
    public void presenceOfShonitProductName() throws InterruptedException {
        String productName = systemRelease.ShonitAtNewSystemReleasePage();
        Assert.assertEquals(productName, "Shonit");
        logger.info(" Shonit product name is present on New System release page");

    }


    @Test(priority = 10, enabled = true)
    public void verifyReleaseversionNumber() {
        WebElement element = systemRelease.ReleaseVersionNumber();
        Assert.assertTrue(element.isDisplayed());
        logger.info(" release version  is visible at New  asystem release page ");
    }

    @Test(priority = 12, enabled = true)
    public void selectingReleaseType() throws InterruptedException {
       String selectedReleaseType = systemRelease.ReleaseType();
        Assert.assertEquals(selectedReleaseType, props.getProperty("TypeOfrelease"));
        logger.info(" release type  is selected successfully");
    }
    @Test(priority = 14, enabled = true)
    public void presenceOfDescriptionOption() throws InterruptedException {
       String descriptionOption =systemRelease.descriptionOptional();
        Assert.assertEquals(descriptionOption,"Description (Optional)");
        logger.info("Description option is visible at New System Release");
    }
    @Test(priority = 16, enabled = true)
    public  void visibilityOfInstructionOfDeployment(){
        String Text=systemRelease.instructionOfDeployment();
        Assert.assertEquals(Text,"Instructions for Deployment (Optional)");
        logger.info("instruction of deployment is visible at System Rlease page");
    }
    @Test(priority = 18, enabled = true)
    public void presenceOfVasuki() throws InterruptedException {
        String vasuki =systemRelease.vasuki();
        Assert.assertEquals(vasuki,"Vasuki");
        logger.info("Vasuki is present at  New System Release page");
    }
    @Test(priority = 20, enabled = true)
    public void verifyUploadingPdfFile() throws InterruptedException, AWTException, IOException {
        String releaseNotetext =systemRelease.uploadPdfReleaseNote();
        Assert.assertEquals(releaseNotetext,props.getProperty("selectedPdffile"));
        logger.info(" Release note pdf file is uploaded successfully");

    }
    @Test(priority = 21,enabled = true)
    public void visibilityOfReportTemplate(){
        String reportTemplate=systemRelease.visibilityOfReportTemplate();
        Assert.assertEquals(reportTemplate,"Report template");
        logger.info("Report template is visibile at new System Release page ");
    }
    @Test(priority = 22,enabled = true)
    public void visibilityOfUserManualPdf(){
        String reportTemplate=systemRelease.visibilityOfUserManual();
        Assert.assertEquals(reportTemplate,"User Manual (PDF)");
        logger.info("User Manual (PDF) is visibile at new System Release page ");
    }
    @Test(priority = 25, enabled = true)
    public void UploadingUserManualPdfFile() throws InterruptedException {
        String releaseNotetext =systemRelease.UserMAnulaPdfFile();
        Assert.assertEquals(releaseNotetext,props.getProperty("selectedUserManualPdfFile"));
        logger.info("User Manual Pdf File is uploaded successfully");
    }
    @Test(priority = 27, enabled = true)
    public void UploadingReportTemplateJsonFile() throws InterruptedException {
        String releaseNotetext =systemRelease.uploadingReportTemplateJsonFile();
        Assert.assertEquals(releaseNotetext,props.getProperty("uploadReportTemplate"));
        logger.info("Report Template Pdf File is uploaded successfully");
    }


    @Test(priority = 29, enabled = true)
    public void UploadingEmailTemplateJsonFile() throws InterruptedException {
        String releaseNotetext =systemRelease.uploadingEmailtTemplateJsonFile();
        Assert.assertEquals(releaseNotetext,props.getProperty("uploadReportTemplate"));
        logger.info("Email Template Pdf File is uploaded successfully");
    }

    @Test(priority = 35, enabled = true)
    public void selectingPackageVersionType() throws InterruptedException {
        String selectedPackageVersion = systemRelease.clickOnPackageVersion();
        Assert.assertEquals(selectedPackageVersion,props.getProperty("TypeOfPackageVersion"));
        logger.info("package version is selected successfully");
    }
    @Test(priority = 38,enabled = true)
    public void VerifyingVisibilityOfAnalyser(){
        String Analyser=systemRelease.visibilityOfAnalyserIcon();
        Assert.assertEquals(Analyser,"Analyser");
        logger.info(" Analyser  is present at New System release tab");
    }
    @Test(priority = 39, enabled = true)
    public void UploadingAnalyserJsonFile() throws InterruptedException {
        String releaseNotetext =systemRelease.uloadAnalyserJsonFile();
        Assert.assertEquals(releaseNotetext,props.getProperty("uploadedAnalyserJsonFile"));
        logger.info("Analyser json file is uploaded successfully");
    }


    @Test(priority = 41, enabled = true)
    public void selectingProductVersionType() throws InterruptedException {
       String selectedProductVersion = systemRelease.ClickOnProductVersion();
        Assert.assertEquals(selectedProductVersion,props.getProperty("TypeOfProductVersion"));
        logger.info("product version is selected successfully");
    }

    @Test(priority = 44, enabled = true)
    public void selectingAnalyserVersionType() throws InterruptedException {
       String  selectedAnalyserVersion = systemRelease.clickOnAnalyserVersion();
        Assert.assertEquals(selectedAnalyserVersion,props.getProperty("TypeOfAnalyserVersion"));
        logger.info("Analyser version is selected successfully");
    }
    @Test(priority = 47,enabled = true)
    public void visibilityOfCancelButton(){
        String cancel=systemRelease.visibilityOfCancelButton();
        Assert.assertEquals(cancel,"Cancel");
        logger.info("cancel button is visibile at new System Release page ");
    }

    @Test(priority = 50,enabled = true)
    public void clickOnUpdate() throws InterruptedException {
        String actualReleaseVersion=systemRelease.clickOnUpdate();
        Assert.assertEquals(actualReleaseVersion,props.getProperty("releaseVersionText"));
        logger.info("clicked on update button & release version is visibile at Qa System release Page");
    }











}
