package com.Common;

import com.data.Shonit_data.PropertiesFile;
import com.utilities.BrowserSetUp;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;
import org.testng.annotations.*;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import java.util.List;
import java.util.Properties;

public class SampleApproveTest extends BrowserSetUp {

    public Properties props;
    public SampleRejectApprove approve;
    private SearchFilter searchfilter;
    private ShonitWBCReport  WBCReport;
    private final Logger logger = LogManager.getLogger(SampleApproveTest.class);
    public BrowserSetUp pageload;

    @BeforeClass
    public void setUp() throws Exception {
        driver = getDriver();
        approve = new SampleRejectApprove(driver);
        WBCReport=new ShonitWBCReport(driver);
        searchfilter=new SearchFilter(driver);
        props = PropertiesFile.prop;
        PropertiesFile.readMandaraHomePropertiesFile();
        PropertiesFile.readSearchFilterFile();
        PropertiesFile.readApproveRejectFile();
    }

    //Click on sigtuple icon to go to home page
    @Test(priority = 1,enabled = false)
    public void clickOnSigupleIcon() throws InterruptedException {
        test = extent.createTest("Sample Approve");
        Assert.assertTrue(approve.gotohomeviesigtupleicon());
        logger.info("Clicked on sigtuple icon and home page loaded ");
    }
    
   /* @Parameters({"product"})
    @Test(priority = 2)
    public void getReportCountFromHome(String product) throws InterruptedException
    { 
    	String productpath=props.getProperty("productpath_first")+product+props.getProperty("productpath_second");
        Assert.assertTrue(approve.getReportCountFromHome(productpath));
        logger.info("Approve/Reject Count is collected from home page");
    }*/



//    @Parameters({"product"})
//    @Test(priority = 6)
//    public void searchsampleID(String product) throws InterruptedException {
//    	boolean samplestatus = approve.searchSampelID(product);
//    	Thread.sleep(5000);
//        Assert.assertTrue(samplestatus);
//        logger.info("sample is searched for get the reprot for page");
//
//    }


//---------------------------  Approve sample -------------------------------------


    //find  Approve button
    @Test(priority = 201, enabled = true)
    public void verifyApprovebtn() throws InterruptedException {
        Thread.sleep(2000);
        Assert.assertTrue(approve.verifyApprovebtn());
        logger.info("Approve button is visible and clickable");
    }

    @Test(priority = 202, enabled = true)
    public void clickonApprovebutton() throws InterruptedException {
        Thread.sleep(2000);
        Assert.assertTrue(approve.clickonApprovebutton());
        logger.info("clicked on Approve button");
    }

    @Test(priority = 203, enabled = true)
    public void verifyenteringthecomment() throws InterruptedException {
        approve.enterCommentOnApprovedReport();
        logger.info("comment entered");
    }



    //click on Approve button

    @Test(priority = 205, enabled = true)
    public void verifyApprovingTheReport() throws InterruptedException {
        approve.verifytheApprovedsample();
        logger.info("report rejected successfully");
    }

    //Verify reject confirm popup
   /* @Test(priority =204,enabled=true)
    public void verifyReportApproveAlert() throws InterruptedException {
    	Assert.assertTrue(approve.getalertmsg().contains(props.getProperty("confirmapprovealert")));
        logger.info("verifyReportApproveAlert");
    }*/




//    //Verify Approve confirm popup
//    @Test(priority =205,enabled=true)
//    public void verifyApprovepop() throws InterruptedException {
//    	Assert.assertTrue(approve.verifyApprovepop());
//        logger.info("Approve popup verified");
//    }
//    
//    
//    //Verify Approve and cancel button in approve popup
//    @Test(priority =207,enabled=true)
//    public void verifydialogbuttons() throws InterruptedException {
//    	Assert.assertTrue(approve.verifydialogbuttons());
//        logger.info("list of buttons in dialog box is verified");
//    }
//    
//    
//    //Verify content table and email IDs with note
//    @Test(priority =209,enabled=true)
//    public void verifytableAndemailsection() throws InterruptedException {
//    	Assert.assertTrue(approve.verifytableAndemailsection());
//        logger.info("list of buttons in dialog box is verified");
//    }
//   
//    
//    //click cancel button from approve dialog box
//    @Test(priority =213, enabled=true)
//    public void clickoncancelbuttonofdialog() throws InterruptedException {
//    	Assert.assertTrue(approve.clickoncancelbuttonofdialog());
//        logger.info("click to cancel button form popup window is verified");
//    }
//    
//    //click Approve button from approve dialog box
//    @Test(priority =215, enabled=true)
//    public void clickonApprovebuttonofdialog() throws Exception {
//    	Assert.assertTrue(approve.clickonApprovebuttonofdialog());
//        logger.info("click to Approve button form popup window is verified");
//    }





    //Verify Sample Approved
    @Test(priority = 217, enabled = true)
    public void verifyReportApproved() throws InterruptedException {
        Thread.sleep(2000);
        Assert.assertTrue(approve.verifyReportRejectOrApproveDone());
        logger.info("Sample Approved successfully");
    }

    //Verify downlaod report button
    @Test(priority = 219, enabled = true)
    public void visibilityOfDownlaodButton() throws InterruptedException {
        Thread.sleep(5000);
        Assert.assertTrue(approve.visibilityOfDownlaodButton());
        logger.info("download report button is visible and clickable");
    }

    //Verify downlaod report button
    @Test(priority = 220, enabled = true)
    public void visibilityOfPrintReportButton() throws InterruptedException {
        Assert.assertTrue(approve.visibilityOfPrintReportButton());
        logger.info("print report button is visible and clickable");
    }

   /* @Test(priority = 221, enabled = true)
    public void clickOnSigupleIcon1() throws InterruptedException {
        Assert.assertTrue(approve.clickOnSigupleIcon());
        logger.info("Clicked on sigtuple icon and home page loaded ");
    }
    //Click on Shonit List Report
    @Parameters({"product"})
    @Test(priority = 222,enabled = true)
    public void clickonListReportTest(String product) throws InterruptedException {
        Thread.sleep(2000);
        Assert.assertTrue(approve.clickonListReport(product));
        logger.info("Clicked on List Report Successfully to load");
    }


    @Test(priority = 223,enabled = true)
    public void getFirstSampleForReview() throws Exception {
        Thread.sleep(3000);
        boolean flag1 = searchfilter.selectUnassignedReview();
        Assert.assertTrue(flag1);
       //  Assert.assertTrue(approve.assigneAndOpenReport());
        logger.info("sample is assigned to reviewer and report opend for validation");
    }
    @Test(priority = 224,enabled = true)
      public void clickOnFirstSampleForReview() throws InterruptedException {
        boolean flag=approve.clickOnFirstSample();
       Assert.assertTrue(flag);
       logger.info("first sample is selected for review");

    }

    @Test(priority = 226)
    public void switchtoWBCTab() throws InterruptedException {
        Thread.sleep(2000);
        Assert.assertTrue(WBCReport.clickonWBCTab());
        logger.info("Clicked on WBC Tab of Report page");
    }
    @Test(priority = 228, enabled = true)
    public void verifyReclassificationContent() {
        String updationMessage = WBCReport.clickOnReclassification();
        // Assert.assertEquals(updationMessage,props.getProperty("reclassificationCell"));
        Assert.assertEquals(updationMessage, "Neutrophil\n" +
                "Lymphocyte\n" +
                "Monocyte\n" +
                "Eosinophil\n" +
                "Basophil\n" +
                "IG\n" +
                "Atypical/Blast\n" +
                "Unclassified\n" +
                "Rejected\n" +
                "NRBC\n" +
                "Giant Platelets\n" +
                "Platelet Clumps,");
        logger.info(" all cell name is present when click on edit menu");
    }

    @Test(priority = 230, enabled = true)
    public void clickonApprovebuttonForVarFeature() throws InterruptedException {
        Thread.sleep(2000);
        Assert.assertTrue(approve.clickonApprovebutton());
        logger.info("clicked on Approve button");
    }

     @Test(priority = 232,enabled = true)
    public void clickOnYesButtonOnApprovePopUP(){
        String actualPopUPHeader=approve.clickOnYesButtonOnApprovePopUp();
            Assert.assertEquals(actualPopUPHeader,"Preview and Approve Report");
            logger.info("clicked  on yes button on Approve Pop Up is verified");
         }

    @Test(priority = 234,enabled = true)
    public void verifyReportIncludingPsImpression(){
        Assert.assertTrue(approve.ReportWithPsImpression());
       logger.info("Report is verified  Including  the Ps Impression ");
    }
    @Test(priority = 236,enabled = true)
    public  void ReportApproveIncludingPSImpression(){
        Assert.assertTrue(approve.clickOnApproveButton());
        logger.info("report is approved including Ps Impression");

    }
    @Test(priority = 238, enabled = true)
    public void DownlaodReportIncludingPSImpression() throws InterruptedException {
        Thread.sleep(5000);
        Assert.assertTrue(approve.visibilityOfDownlaodButton());
        logger.info("download report button is visible and clickable");
    }

    //Verify downlaod report button
    @Test(priority = 240, enabled = true)
    public void PrintReportIncludingPSImpression() throws InterruptedException {
        Assert.assertTrue(approve.visibilityOfPrintReportButton());
        logger.info("print report button is visible and clickable");
    }
*/


    @Test(priority = 242, enabled = true)
    public void clickOnSigupleIcon2() throws InterruptedException {
        Assert.assertTrue(approve.clickOnSigupleIcon());
        logger.info("Clicked on sigtuple icon and home page loaded ");
    }
    //Click on Shonit List Report
    @Parameters({"product"})
    @Test(priority = 244,enabled = true)
    public void clickonListReportTestForVarFeature(String product) throws InterruptedException {
        Thread.sleep(2000);
        Assert.assertTrue(approve.clickonListReport(product));
        logger.info("Clicked on List Report Successfully to load");
    }


    @Test(priority = 246,enabled = true)
    public void getFirstSampleForExcludingPSImpression() throws Exception {
        Thread.sleep(3000);
        boolean flag1 = searchfilter.selectUnassignedReview();
       Assert.assertTrue(flag1);
        // Assert.assertTrue(approve.assigneAndOpenReport());
        logger.info("sample is assigned to reviewer and report opend for validation");
    }
    @Test(priority = 247,enabled = true)
    public void clickOnSampleToVerifyPSImpression() throws InterruptedException {
        boolean flag=approve.clickOnFirstSample();
        Assert.assertTrue(flag);
        logger.info("first sample is selected for review");

    }

    @Test(priority = 248)
    public void switchtoWBCTabToVerifyPSImpression() throws InterruptedException {
        Thread.sleep(4500);
        Assert.assertTrue(WBCReport.clickonWBCTab());
        logger.info("Clicked on WBC Tab of Report page");
    }
    @Test(priority = 250, enabled = true)
    public void verifyReclassificationContentForEXCLUDINGPSImpression() throws Exception {
        String updationMessage = WBCReport.clickOnReclassification();
        // Assert.assertEquals(updationMessage,props.getProperty("reclassificationCell"));
        Assert.assertEquals(updationMessage, "Neutrophil\n" +
                "Lymphocyte\n" +
                "Monocyte\n" +
                "Eosinophil\n" +
                "Basophil\n" +
                "IG\n" +
                "Atypical/Blast\n" +
                "Unclassified\n" +
                "Rejected\n" +
                "NRBC\n" +
                "Giant Platelets\n" +
                "Platelet Clumps,");
        logger.info(" all cell name is present when click on edit menu");
    }


    @Test(priority = 252, enabled = true)
    public void clickonApproveButtonExcludingPSImpression() throws InterruptedException {
        Thread.sleep(2000);
        Assert.assertTrue(approve.clickonApprovebutton());
        logger.info("clicked on Approve button");
    }

    @Test(priority = 254,enabled = true)
    public void clickOnYesButtonExcludingPSImpression(){
        String actualPopUPHeader=approve.clickOnYesButtonOnApprovePopUp();
        Assert.assertEquals(actualPopUPHeader,"Preview and Approve Report");
        logger.info("clicked  on yes button on Approve Pop Up is verified");
    }


    @Test(priority = 256,enabled = true)
    public void ReportExcludingPsImpression() throws InterruptedException {
        Assert.assertTrue(approve.ReportWithoutPsImpression());
        logger.info("Report is verified  Excluding  the Ps Impression ");
    }

    @Test(priority = 257,enabled = true)
    public  void verifyCheckBoxesForAllTheReport() throws InterruptedException {
        Thread.sleep(3000);
        Assert.assertTrue(approve.clickOnCheckedBoxesForAllTheReport());
        logger.info("clicked on selected boxes which is enabled ");
    }




     @Test(priority = 264,enabled = true)
    public  void ReportApprovedWithoutPSImpression(){

        Assert.assertTrue(approve.clickOnApproveButton());
        logger.info("report is approved including Ps Impression");

    }
    @Test(priority = 266, enabled = true)
    public void DownlaodReportWithoutPSImpression() throws InterruptedException {
        Thread.sleep(5000);
        Assert.assertTrue(approve.visibilityOfDownlaodButton());
        logger.info("download report button is visible and clickable");
    }

    //Verify downlaod report button
    @Test(priority = 268, enabled = true)
    public void PrintReportWithoutPSImpression() throws InterruptedException {
        Assert.assertTrue(approve.visibilityOfPrintReportButton());
        logger.info("print report button is visible and clickable");
    }



















    
  /*  @Parameters({"product"})
    @Test(priority = 223)
    public void verifyApproveCountFromHome(String product) throws InterruptedException {
    	String productpath=props.getProperty("productpath_first")+product+props.getProperty("productpath_second");
    	Assert.assertTrue(approve.verifyApproveCountFromHome(productpath));
         logger.info("Updated Approve count is verified from home page ");
    }*/


}
