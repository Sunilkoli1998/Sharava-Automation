package com.Common;

import com.data.Shonit_data.PropertiesFile;
import com.utilities.BrowserSetUp;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import java.util.List;
import java.util.Properties;

import com.Common.SampleRejectApprove;

public class SampleRejectTest extends BrowserSetUp {

    public Properties props;
    public SampleRejectApprove reject;
    private SearchFilter searchfilter;
    private SampleRejectApprove approve;
    private final Logger logger = LogManager.getLogger(SampleRejectTest.class);
    public BrowserSetUp pageload;



    @BeforeSuite
    public void setUp() throws Exception {
        driver = getDriver();
        reject = new SampleRejectApprove(driver);
        searchfilter = new SearchFilter(driver);
        approve= new SampleRejectApprove(driver);
        props = PropertiesFile.prop;
        PropertiesFile.readApproveRejectFile();
        PropertiesFile.readMandaraHomePropertiesFile();
        PropertiesFile.readShonitListReportFile();
        PropertiesFile.readSearchFilterFile();
    }

    //Click on sigtuple icon to go to home page
    @Test(priority = 2, enabled = true)
    public void clickOnSigupleIcon() throws InterruptedException {
        test = extent.createTest("Sample Rejection");
        Assert.assertTrue(reject.clickOnSigupleIcon());
        logger.info("Clicked on sigtuple icon and home page loaded ");
    }

    @Parameters({"product"})
    @Test(priority = 3, enabled =false)
    public void getReportCountFromHome(String product) throws InterruptedException {
        String productpath = props.getProperty("productpath_first") + product + props.getProperty("productpath_second");
        Assert.assertTrue(reject.getReportCountFromHome(productpath));
        logger.info("Approve/Reject Count is collected from home page");
    }

    //Click on Shonit List Report
    @Parameters({"product"})
    @Test(priority = 4, enabled = true)
    public void clickonListReportTest(String product) throws InterruptedException {
        Assert.assertTrue(reject.clickonListReport(product));
        logger.info("Clicked on List Report Successfully to load");
    }

    @Parameters({"product"})
    @Test(priority = 6, enabled = false)
    public void searchsampleID(String product) throws InterruptedException {
        boolean samplestatus = reject.searchSampelID(product);
        Thread.sleep(3000);
        Assert.assertTrue(samplestatus);
        logger.info("sample is searched for get the reprot for page");
    }

    @Test(priority = 7, enabled = true)
    public void getFirstSampleForReview() throws Exception {
        Thread.sleep(3000);
        //Assert.assertTrue(reject.assigneAndOpenReport());
        boolean flag1 = searchfilter.selectUnassignedReview();
        Assert.assertTrue(flag1);
        logger.info("sample is assigned to reviewer and report opend for validation");
    }

    @Test(priority = 8,enabled = true)
    public void clickOnFirstSampleFrRejection() throws InterruptedException {
        boolean flag=approve.clickOnFirstSample();
        Assert.assertTrue(flag);
        logger.info("first sample is selected for review");

    }


//---------------------------  Reject Sample -------------------------------------


    //find reject button
    @Test(priority = 101, enabled = true)
    public void verifyrejectbtn() throws InterruptedException {
        Thread.sleep(2000);
        Assert.assertTrue(reject.verifyrejectbtn());
        logger.info("Reject button is visible and clickable");
    }

    //click on Reject button
    @Test(priority = 102, enabled = true)
    public void clickonRejectbutton() throws InterruptedException {
        Thread.sleep(2000);
        Assert.assertTrue(reject.clickonRejectbutton());
        logger.info("clicked on reject button");
    }

    //Verify reject confirm popup
    /*@Test(priority =103,enabled=true)
    public void verifyRejectpop() throws InterruptedException {
    	Assert.assertTrue(reject.verifyRejectpop());
        logger.info("Reject popup verified");
    }*/

    @Test(priority = 104, enabled = true)
    public void verifythepresenceofcancelbutton() throws InterruptedException {
        String cancelbutton = reject.verifythecancellbutton();
        Assert.assertEquals(cancelbutton, "Cancel");
        logger.info("cancel button is present with place holder as " + cancelbutton);
    }

    @Test(priority = 105, enabled = true)
    public void verifythepresenceofRejectbutton() throws InterruptedException {
        String rejectbutton = reject.verifytheRejectbutton();
        Assert.assertEquals(rejectbutton, "Reject");
        logger.info("cancel button is present with place holder as " + rejectbutton);
    }


    @Test(priority = 106, enabled = true)
    public void verifyenteringthecomment() throws InterruptedException {
        reject.enterComment();
        logger.info("comment entered");
    }

    @Test(priority = 107, enabled = true)
    public void verifyrejectingthereport() throws InterruptedException {
        reject.verifytheRejectingthesample();
        logger.info("report rejected successfully");
    }

    @Test(priority = 108, enabled = true)
    public void verifyStatusoftheRejectedreport() throws InterruptedException {
        String status = reject.verifytheStatusofTherejectedSample();
        Assert.assertEquals(status, "Rejected");
        logger.info("The status of the report is " + status);
    }

    @Test(priority = 108, enabled = true)
    public void verifyTheRejectedcomment() throws InterruptedException {
        String comment = reject.verifyTheRejectedComment();
        Assert.assertEquals(comment, props.getProperty("rejectionComment"));
        logger.info("The status of the report is " + comment);
    }


    //Verify cancel the sample rejection
   /* @Test(priority =109,enabled=false)
    public void cancesampleRejection() throws InterruptedException {
    	Assert.assertTrue(reject.cancesampleRejection());
        logger.info("cancel on sample rejection is verified");
    }*/


    //Verify Accept the sample rejection
    @Test(priority = 111, enabled = false)
    public void AcceptsampleRejection() throws InterruptedException {
        Assert.assertTrue(reject.AcceptsampleRejection());
        logger.info("accept on sample rejection is verified");
    }

    //Verify Reported Metrics headers
    @Test(priority = 115, enabled = false)
    public void verifyReportRejected() throws InterruptedException {
        Assert.assertTrue(reject.verifyReportRejectOrApproveDone());
        logger.info("Sample Rejected successfully");
    }

    @Test(priority = 117, enabled = false)
    public void clickOnSigupleIcon1() throws InterruptedException {
        Assert.assertTrue(reject.clickOnSigupleIcon());
        logger.info("Clicked on sigtuple icon and home page loaded ");
    }

    @Parameters({"product"})
    @Test(priority = 119, enabled = false)
    public void verifyRejectCountFromHome(String product) throws InterruptedException {
        String productpath = props.getProperty("productpath_first") + product + props.getProperty("productpath_second");
        Assert.assertTrue(reject.verifyRejectCountFromHome(productpath));
        logger.info("Updated Reject count is verified from home page ");
    }

}
