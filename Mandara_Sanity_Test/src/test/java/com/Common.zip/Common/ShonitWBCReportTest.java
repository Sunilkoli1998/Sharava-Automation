package com.Common;

import com.data.Shonit_data.PropertiesFile;
import com.utilities.BrowserSetUp;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import java.util.List;
import java.util.Properties;

public class ShonitWBCReportTest extends BrowserSetUp {

    public Properties props;
    public ShonitWBCReport WBCReport;
    private Comment comment;
    private final Logger logger = LogManager.getLogger(ShonitWBCReportTest.class);
    public BrowserSetUp pageload;

    @BeforeSuite
    public void setUp() throws Exception {
        driver = getDriver();
        WBCReport = new ShonitWBCReport(driver);
        comment=new Comment(driver);
        props = PropertiesFile.prop;
    }


//---------------------------  WBC Tab -------------------------------------

    //Switch to WBC tab
    @Test(priority = 54)
    public void switchtoWBCTab() throws InterruptedException {
        Thread.sleep(2000);
        test = extent.createTest("Shonit WBC Tab");
        Assert.assertTrue(WBCReport.clickonWBCTab());
        logger.info("Clicked on WBC Tab of Report page");
    }

    //Verify list of Tabels
    @Test(priority = 56)
    public void verifyWBCTab() throws InterruptedException {
        Thread.sleep(2000);
        String tabs = WBCReport.getWBCListofTabels();
        Assert.assertEquals(tabs, props.getProperty("wbctabelsnames"));
        logger.info("List of tabels in WBC tab is verified");
    }

    //Verify WBC Absolute headers
    @Test(priority = 58, enabled = true)
    public void verifyWBCAbsoluteColumns() throws InterruptedException {
        String metricscolumns = WBCReport.getWBCAbsoluteColoumns();
        Assert.assertEquals(metricscolumns, props.getProperty("wbcheaderdata"));
        logger.info("List of columns of WBCAbsolute is verified");
    }

    //Verify list of rows of WBC Absolute Couts tabel
    @Test(priority = 60, enabled = true)
    public void verifyWBCAbsoluteRows() throws InterruptedException {
        String metricsrows = WBCReport.getWBCAbsoluterows();
        Assert.assertEquals(metricsrows, props.getProperty("wbcrowsdata"));
        logger.info("List of Rows in WBCAbsolute is verified");
    }

//    @Test(priority = 61, enabled = true)
//    public void verifySameCellOnTopOfPatches() throws InterruptedException {
//        String acutalCellName = WBCReport.CellNameSelection();
//        Assert.assertEquals(acutalCellName, "Neutrophil   \n" +
//                "tune");
//        logger.info("Neutrophil is present on above of images");
//    }

    @Test(priority = 62, enabled = true)
    public void verifycellNameOnREferences() {
        String actualCellNameOnReferences = WBCReport.cellNameOnREferenceTab();
        Assert.assertEquals(actualCellNameOnReferences, "Neutrophils");
        logger.info("Neutrophil is present on references");
    }


    @Test(priority = 63, enabled = true)
    public void verifyAllOptionsOnViewSetting() throws InterruptedException {
        String options = WBCReport.viewTabSetting();
        Assert.assertEquals(options, "View   \n" +
                "All");
        logger.info(" all options are present on view setting ");
    }

    @Test(priority = 64, enabled = true)
    public void verifyEnableOrDisableViewSetting() {
        Assert.assertTrue(WBCReport.diableViewbeforeSelection());
        logger.info(" view setting is disabled before selection of any cell ");
    }

    @Test(priority = 65, enabled = true)
    public void verifyExpandButton() throws InterruptedException {
        String actualText = WBCReport.clickOnExpandButton();
        Assert.assertEquals(actualText, "- Extracted Cell");
        logger.info("after click on image  extracted cell text is present ");
    }
    @Test(priority = 66, enabled = true)
    public void verifyNavigationInFullPatchView(){
        Assert.assertTrue(WBCReport.navigationInFullPatchView());
        logger.info("Microscopic navigation in full patch view is verified");
    }




    @Test(priority = 68, enabled = true)
    public void verifySubClasssificationContent() throws InterruptedException {
        String actualText = WBCReport.clickOnSubclassification();
        Assert.assertEquals(actualText, "Band Neut\n" +
                "Hypersegmented");
        logger.info(" all cell name is present when click on subclassification menu");

    }


    @Test(priority = 70, enabled = true)
    public void verifyReclassificationContent() throws Exception {
        String updationMessage = WBCReport.clickOnReclassification();
        // Assert.assertEquals(updationMessage,props.getProperty("reclassificationCell"));
        Assert.assertEquals(updationMessage, "Neutrophil\n" +
                "Lymphocyte\n" +
                "Monocyte\n" +
                "Eosinophil\n" +
                "Basophil\n" +
                "IG\n" +
                "Atypical/Blast\n" +
                "Unclassified\n" +
                "Rejected\n" +
                "NRBC\n" +
                "Giant Platelets\n" +
                "Platelet Clumps,");
        logger.info(" all cell name is present when click on edit menu");
    }

    @Test(priority = 72, enabled = true)
    public void correctionCountOnSummaryTab() {
        String actualpopup = WBCReport.CorrectionCountUpdation();
        Assert.assertEquals(actualpopup, "Update Report Successful");
        logger.info("alert message is verified on summary tab");
    }


//    @Test(priority = 74)
//    public void verifyingModifiedReport() throws InterruptedException {
//       // String originalText = WBCReport.modifiedReportAfterAssignement();
//        Assert.assertTrue(WBCReport.modifiedReportAfterAssignement());
//        logger.info("Modified repport is visible on report page");
//    }



    @Test(priority = 76, enabled = true)
    public void clickoncommenticon() throws InterruptedException {
        Assert.assertTrue(comment.clickoncommentIcon());
        logger.info("Clicked on Comment Icon Successfully");
    }

    @Test(priority = 77, enabled = true)
    public void loadcommentbox() throws InterruptedException {
        Assert.assertTrue(comment.commentboxlaod());
        logger.info("Comment Box laoded succssfully");
    }

    @Test(priority = 78, enabled = true)
    public void validatebox() throws InterruptedException {
        //  Assert.assertTrue(comment.validatecommentbox());
        Assert.assertEquals(comment.validatecommentbox(), "Comments");
        logger.info("Comment Box is verified successfully");
    }

    @Test(priority = 79, enabled = true)
    public void closecommentbox() throws InterruptedException {
        Assert.assertTrue(comment.closecommentbox());
        logger.info("Clicked on Comment close Icon Successfully");
    }

    @Test(priority = 80, enabled = true)
    public void clickoncommenticon1() throws InterruptedException {
        comment.clickonCommentIcon();
        logger.info("Clicked on Comment Icon Successfully");
    }

    @Test(priority = 81, enabled = true)
    public void checkuser() throws InterruptedException {
        Assert.assertTrue(comment.checkuser());
        logger.info("user can update the comment");}


    @Test(priority = 83, enabled = true, dependsOnMethods = "checkuser")
    public void checkpostbtnclickable() throws InterruptedException {
        Assert.assertTrue(comment.checkpostbtnclickable());
        logger.info("Post button is clickable ");
    }

    @Test(priority = 85, enabled = false, dependsOnMethods = "checkuser")
    public void checkaleartmsg() throws InterruptedException {
        String actualAlerMessage = comment.validatealertmsg();
        Assert.assertEquals(actualAlerMessage, "?\n" +
                "Oops!\n" +
                "Please enter your comment");
        logger.info("Alert message is verified");
    }

    @Test(priority = 87, enabled = true, dependsOnMethods = "checkuser")
    public void checkcommentbox() throws InterruptedException {
        Assert.assertTrue(comment.entercomment());
        logger.info("comment box is editable for entring the comments ");
    }

    //----------------------- Validation of comments pushing in all tab  ------------------

    @Test(priority = 89, enabled = true, dependsOnMethods = "checkuser")
    public void WBC_entercomment() throws InterruptedException {
        String tab = "wbctab";
        Assert.assertTrue(comment.entercomment(tab));
        logger.info("comment pushed successfully for wbc tab");
    }

    @Test(priority = 91, enabled = true, dependsOnMethods = "checkuser")
    public void WBC_checkcomment() throws InterruptedException {
        String tab = "wbctab";
        Assert.assertTrue(comment.verify_pushedcomment(tab));
        logger.info("comment verificaiton Done successfully for wbc tab");
    }








































  /*  @Test(priority = 24)
    public void verifyApproveReport() {
        String approvedBy = WBCReport.approveReport();
        Assert.assertEquals(approvedBy, "Reassigned By:\n" +
                "Rupa kumari");
    }*/


    //Get total percentage of WBC absolute
   /* @Test(priority = 61,enabled=true)
    public void verifyWBCAbsolutePercentageTotal() throws InterruptedException
    {
    	Assert.assertTrue(WBCReport.verifyWBCAbsolutePercentageTotal());
    	logger.info("Total percentage of WBCAbsolute is verified");
    }
    
    //Verify list of rows of WBC Absolute Couts tabel
   @Parameters({"product"})
    @Test(priority = 62,enabled=true)
    public void VerifyWBCAbsoluteTableData(String product) throws Exception {
    	Assert.assertTrue(WBCReport.VerifyWBCAbsoluteTableData(product));
        logger.info("List of data in WBCAbsolute is verified");
    }*/

    //Verify list of rows of WBC Absolute Couts tabel
  /*  @Test(priority = 63,enabled=true)
    public void verifyWBCAbsolutepatches() throws InterruptedException {
    	Assert.assertTrue(WBCReport.getWBCAbsolutepatches());
        logger.info("List of shown patches in WBCAbsolute is verified");
    }*/

//---------------------------  Report Metrics  -------------------------------------

    //Verify Reported Metrics headers
  /*  @Test(priority = 64, enabled=true)
    public void verifyReportedMeticsColumns() throws InterruptedException {
    	String shonitmetricscolumns=WBCReport.getReportedMetricsColumns();
    	Assert.assertEquals(shonitmetricscolumns,props.getProperty("reportedheaderdata"));
        logger.info("List of Columns of Reported Metrics is verified");
    }

    //Verify Reported Metrics list of rows
    @Test(priority = 65, enabled=true)
    public void verifyReportedMeticsRows() throws InterruptedException {
    	String shonitmetricsrows=WBCReport.getReportedMeticsRows();
    	Assert.assertEquals(shonitmetricsrows,props.getProperty("reportedrowsdata"));
        logger.info("List of Rows of Reported Metics is verified");
    }*/

    //Verify list of rows of WBC Absolute Couts tabel
   /* @Parameters({"product"})
    @Test(priority = 67,enabled=true)
    public void VerifyReportedMeticsTableData(String product) throws Exception {
    	Assert.assertTrue(WBCReport.VerifyReportedMeticsTableData(product));
        logger.info("List of data in Reported Metrics is verified");
    }*/


}
