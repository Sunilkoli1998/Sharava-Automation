package com.Common;

import com.data.Shonit_data.PropertiesFile;
import com.sun.xml.internal.ws.api.ha.StickyFeature;
import com.utilities.BrowserSetUp;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import java.io.IOException;
import java.util.List;
import java.util.Properties;

public class ShonitPlateleteReportTest extends BrowserSetUp {

    public Properties props;
    private Comment comment;
    private MicroscopicView microscopicview;
    public ShonitPlateleteReport PlateleteReport;
    private final Logger logger = LogManager.getLogger(ShonitPlateleteReportTest.class);
    public BrowserSetUp pageload;

    public ShonitPlateleteReportTest() throws InterruptedException {
    }

    @BeforeSuite
    public void setUp() throws Exception {
        driver = getDriver();
        PlateleteReport = new ShonitPlateleteReport(driver);
        comment=new Comment(driver);
        microscopicview = new MicroscopicView(driver);
        props = PropertiesFile.prop;
    }


//---------------------------  Platelet Tab -------------------------------------

    //Switch to plt tab
    @Test(priority = 86)
    public void switchtopltTab() throws InterruptedException {
        Thread.sleep(5000);
        test = extent.createTest("Shonit Platelet Tab");
        Assert.assertTrue(PlateleteReport.clickonpltTab());
        logger.info("Clicked on plt Tab of Report page");
    }

    //Verify list of Tabels
    @Test(priority = 88)
    public void verifypltTab() throws InterruptedException {
        Thread.sleep(3000);
        String tabs = PlateleteReport.getpltListofTabels();
        Assert.assertEquals(tabs, "Name\n" +
                "Average Count/ 100X FOVCount\n" +
                "Morphology");
        logger.info("List of tabels in plt tab is verified");
    }

    //Verify platelet Absolute headers
    @Test(priority = 90, enabled = true)
    public void verifypltAbsoluteColumns() throws InterruptedException {
        String metricscolumns = PlateleteReport.getpltAbsoluteColoumns();
        Assert.assertEquals(metricscolumns, "Count\n" +
                "Morphology");
        logger.info("List of columns of plt Absolute is verified");
    }

    //Verify the platelet modified note
    @Test(priority = 92, enabled = true)
    public void verifyPlateletModifiedNote() throws InterruptedException {
        String PlateletModifiedNote = PlateleteReport.getPlateletModifiedNote();
        Assert.assertEquals(PlateletModifiedNote, "Platelet counts can be modified at FOV level as needed and clicking on ’Update’ will save all the changes.");
        logger.info("The platelet modified note is "+PlateletModifiedNote);
    }

    //Verify list of rows of plt Absolute Couts tabel
    @Test(priority = 93, enabled = true)
    public void verifypltAbsoluteRows() throws InterruptedException {
        String metricsrows = PlateleteReport.getpltAbsoluterows();
        Assert.assertEquals(metricsrows, props.getProperty("pltrowsdata"));
        logger.info("The platelet cell name ara "+metricsrows);
    }
    //Verify list of rows of plt Absolute Couts tabel
    @Test(priority = 94, enabled = true)
    public void verfyAvarageCount() throws InterruptedException {
        float AverageCount = PlateleteReport.compareavarageCount();
        String ExpectedCount = driver.findElement(By.xpath(props.getProperty("AvarageCountXpath"))).getText();
//        int Expect=Integer.parseInt(ExpectedCount);
        float ExpectedCount1=Float.parseFloat(ExpectedCount);
        Assert.assertEquals(AverageCount,ExpectedCount1);
        logger.info("The average count is "+AverageCount+" And Expected count is "+ExpectedCount1);
    }

    @Test(priority = 95, enabled = true)
    public void getDetectionText() {
        String actualText = PlateleteReport.ImpressionDetection();
        //Assert.assertEquals(actualText,props.getProperty("DetectionText"));
        Assert.assertEquals(actualText, "Detected");
        logger.info(actualText+" The text is present on table");
    }

    @Test(priority = 100, enabled = true)
    public void VerifyNMGwithColourCode() {
        String actualText = PlateleteReport.verifytheNMGnoteWithColourcode();
        //Assert.assertEquals(actualText,props.getProperty("DetectionText"));
        Assert.assertEquals(actualText, "NMG");
        logger.info(actualText+" The NMG and colour code are verified");
    }
    @Test(priority = 102, enabled = true)
    public void VerifyPresenceOf100xFOVnote() {
        String actualText = PlateleteReport.verifythe100xFOVnote();
        //Assert.assertEquals(actualText,props.getProperty("DetectionText"));
        Assert.assertEquals(actualText, props.getProperty("100xFOVnote"));
        logger.info("the 100x fov note is present and note as "+actualText);
    }

    @Test(priority = 105, enabled = true)
    public void VerifyNormalPlatletAveragecount() throws InterruptedException {
        //List<WebElement> NormalPlateletFOVXpath1=driver.findElements(By.xpath(props.getProperty("NormalPlateletFOVXpath")));
       String NormalPlateletFOVXpath1=props.getProperty("NormalPlateletFOVXpath");
       String N1stcell=props.getProperty("N1stcell");
      float AverageCount = PlateleteReport.VerifyTheaverageCountOfIndividualCells(NormalPlateletFOVXpath1,N1stcell);
     //   float AverageCount = PlateleteReport.VerifyTheaverageCountOfIndividualCells();
        String ExpectedCount = driver.findElement(By.xpath(props.getProperty("NormalPlatletCountXpath"))).getText();
        float ExpectedCount1=Float.parseFloat(ExpectedCount);
        Assert.assertEquals(AverageCount,ExpectedCount1 );
        logger.info("The Actual average count of Nomal Platelet "+AverageCount+" = Expected count is "+ExpectedCount1);
    }
    @Test(priority = 110, enabled = true)
    public void VerifymacroPlatletAveragecount() throws InterruptedException {
       // List<WebElement> MacroPlateletFOVXpath1=driver.findElements(By.xpath(props.getProperty("MacroPlateletFOVXpath")));
        String MacroPlateletFOVXpath1=props.getProperty("MacroPlateletFOVXpath");
        String M1stCell=props.getProperty("M1stCell");
        float AverageCount = PlateleteReport.VerifyTheaverageCountOfIndividualCells(MacroPlateletFOVXpath1,M1stCell);
        String ExpectedCount = driver.findElement(By.xpath(props.getProperty("MacroPlateletCountXpath"))).getText();
        float ExpectedCount1=Float.parseFloat(ExpectedCount);
        Assert.assertEquals(AverageCount,ExpectedCount1 );
        logger.info("The Actual average count of Macro Platelet "+AverageCount+" = Expected count is "+ExpectedCount1);
    }
    @Test(priority = 115, enabled = true)
    public void VerifyGiantPlatletAveragecount()throws InterruptedException {
       // List<WebElement> GiantPlateletFOVXpath1=driver.findElements(By.xpath(props.getProperty("GiantPlatletFOVXpath")));
       String GiantPlateletFOVXpath1= props.getProperty("GiantPlatletFOVXpath");
       String G1stCell=props.getProperty("G1stcell");
        float AverageCount = PlateleteReport.VerifyTheaverageCountOfIndividualCells(GiantPlateletFOVXpath1,G1stCell);
        String ExpectedCount = driver.findElement(By.xpath(props.getProperty("GiantPlateletCountXpath"))).getText();
        float ExpectedCount1=Float.parseFloat(ExpectedCount);
        Assert.assertEquals(AverageCount,ExpectedCount1 );
        logger.info("The Actual average count of Macro Platelet "+AverageCount+" = Expected count is "+ExpectedCount1);
    }

    @Test(priority =117, enabled = false)
    public void VerifytheNondetectednote() throws Exception {
//        String actualText = PlateleteReport.verifyFOVnumberwithtext();
//        //Assert.assertEquals(actualText,props.getProperty("DetectionText"));
//        Assert.assertEquals(actualText, "FOV 1FOV 2FOV 3FOV 4FOV 5FOV 6FOV 7FOV 8FOV 9FOV 10");
        PlateleteReport.plateletRevampingWithZero();
        logger.info(" There are 10 FOV are present");
    }

    @Test(priority =120, enabled = true)
    public void VerifyTotalNumberOfPlatleteFOVcount() {
        String actualText = PlateleteReport.verifyFOVnumberwithtext();
        //Assert.assertEquals(actualText,props.getProperty("DetectionText"));
        Assert.assertEquals(actualText, "FOV 1FOV 2FOV 3FOV 4FOV 5FOV 6FOV 7FOV 8FOV 9FOV 10");
        logger.info(actualText+" There are 10 FOV are present");
    }


    @Test(priority = 122, enabled = true)
    public void verifyGoToNextImage() throws InterruptedException, IOException {
        boolean status = false;
        if (PlateleteReport.verifyGoToNextImage()) {
            logger.info("next image is loaded successfully ");
            status = true;
        } else
            logger.info("Failed to load the next image");
        Assert.assertTrue(status);
    }

    @Test(priority = 123, enabled = true)
    public void verifyGoToPrevImage() throws InterruptedException, IOException {
        boolean status = false;
        if (PlateleteReport.verifyGoToPrevImage()) {
            logger.info("previous image is loaded successfully ");
            status = true;
        } else
            logger.info("Failed to load the prev image");
        Assert.assertTrue(status);
    }
    @Test(priority = 124,enabled = false)
    public void verifyClickOnRightArrowAndVerifyFOVnumber()throws InterruptedException{
        Assert.assertEquals(PlateleteReport.clickOnRightArrow(),"FOV 1FOV 2FOV 3FOV 4FOV 5FOV 6FOV 7FOV 8FOV 9");
        logger.info("clicked on right arrow on fov is verifioed");
    }

//doubt
//    @Test(priority = 123, enabled = true)
//    public void verifyPlateletAbsoluteGrading() throws Exception {
//        Assert.assertTrue(PlateleteReport.verifyPlateletAbsoluteGrading());
//        logger.info("Grading in Platelet Absolute is verified ");
//    }
    @Test(priority = 125,enabled = true)
    public void verifyPlateletRevapingForNormal() throws InterruptedException {
        String actualpopup=PlateleteReport.plateletRevampingfornormal();
             Assert.assertEquals(actualpopup, "Update Report Successful");
        logger.info("platlet revaping happen successfully for Normal");
}
    @Test(priority = 126,enabled = true)
    public void verifyPlateletRevapingForMacro() throws InterruptedException {
        String actualpopup=PlateleteReport.plateletRevampingforMacro();
        Assert.assertEquals(actualpopup, "Update Report Successful");
        logger.info("platlet revaping happen successfully for Macro");
    }
    @Test(priority = 127,enabled = true)
    public void verifyPlateletRevapingForGiant() throws InterruptedException {
        String actualpopup=PlateleteReport.plateletRevampingforGaint();
        Assert.assertEquals(actualpopup, "Update Report Successful");
        logger.info("platlet revaping happen successfully for Giant");
    }






    @Test(priority = 130, enabled = true)
    public void verifyImageZoomIn() throws InterruptedException, IOException {
        boolean status = false;
        if (microscopicview.verifyImageZoomIn()) {
            logger.info("The images were zoomed in successfully");
            status = true;
        } else
            logger.info("The images were not zoomed in successfully");
        Assert.assertTrue(status);
    }



    @Test(priority = 135, enabled = true)
    public void verifyImageZoomOut() throws InterruptedException, IOException {
        boolean status = false;
        if (microscopicview.verifyImageZoomOut()) {
            logger.info("The images were zoomed in successfully");
            status = true;
        } else
            logger.info("The images were not zoomed in successfully");
        Assert.assertTrue(status);
    }

    @Test(priority = 138, enabled = true)
    public void verifyMaximumZoomInPopup() throws InterruptedException, IOException {
        String popup=PlateleteReport.maximumZoomIn();
      Assert.assertEquals(popup,"×\n" +
              "Sorry\n" +
              "Maximum zoom in limit reached");
      logger.info("maximum zoom in popup is appear "+popup);

    }

    @Test(priority = 139, enabled = true)
    public void verifyImageSizeReset() throws InterruptedException, IOException {
        Thread.sleep(2000);
        boolean status = false;
        // Thread.sleep(1000);
        if (microscopicview.verifyImageSizeReset()) {
            logger.info("The images were zoomed in successfully");
            status = true;
        } else
            logger.info("The images were not zoomed in successfully");
        Assert.assertTrue(status);
    }
    @Test(priority = 140, enabled = true)
    public void verifyMaximumZoomOutPopup() throws InterruptedException, IOException {
        String popup=PlateleteReport.maximumZoomOut();
        Assert.assertEquals(popup,"Sorry\n" +
                "Minimum zoom out limit reached");
        logger.info("maximum zoom in popup is appear "+popup);

    }

    @Test(priority = 141)
    public void switchtopltMorphologyTab() throws InterruptedException {
        Thread.sleep(2500);
        Assert.assertTrue(PlateleteReport.clickonpltMorphologyTab());
        logger.info("Clicked on plt morphology Tab of Report page");
    }

    @Test(priority = 143, enabled = true)
    public void verifyTheHeaderNameForMorphologyTab() throws InterruptedException, IOException {
        String HeaderName=PlateleteReport.verifyTableHearderOfMorphology();
        Assert.assertEquals(HeaderName,props.getProperty("headerNameMorphology"));
        logger.info("The headers fo morphology tab are "+HeaderName);

    }
    @Test(priority = 144, enabled = true)
    public void verifyThePlateletDetectedNote() throws InterruptedException, IOException {
      Assert.assertTrue(PlateleteReport.verifyPlateletClumpsDetectedNote());
//        Assert.assertEquals(HeaderName,props.getProperty("headerNameMorphology"));
        logger.info("The note is verify");

    }
    @Test(priority = 145, enabled = true)
    public void verifyTheCellNameForMorphologyTab() throws InterruptedException, IOException {
        String CellName=PlateleteReport.verifyCellsNameOfMorphology();
        Assert.assertEquals(CellName,props.getProperty("CellNamesMorphology"));
        logger.info("The headers fo morphology tab are "+CellName);

    }

    @Test(priority = 150, enabled = true)
    public void verifyDefectedOrNotDetectedNoteOFGiant() throws InterruptedException {
        Assert.assertTrue(PlateleteReport.verifyGiantPlateltDetectedORnotDedected());
        logger.info("successufully varified");
    }

    @Test(priority = 155, enabled = true)
    public void verifyDefectedOrNotDetectedNoteOFPlateletClump() throws InterruptedException {
        Assert.assertTrue(PlateleteReport.verifyPlateletClumpDetectedORnotDedected());
        logger.info("successufully varified");
    }




    @Test(priority = 160, enabled = true)
    public void verifyTheGiantandClumpPlateletNote() throws InterruptedException, IOException {
        String Note=PlateleteReport.GiantandClumpPlateetNot();
        Assert.assertTrue(Note.contains(props.getProperty("Note")));
        logger.info("The note is  "+Note);

    }
    @Test(priority =161,enabled = true )
    public void verifypatcheHeader() throws InterruptedException {
        String Header = (props.getProperty("MorphologycellName"));
        Assert.assertTrue(PlateleteReport.verifypatcheHeader(Header));
        logger.info("Patches header is verified");
    }
    @Test(priority = 162, enabled = true)
    public void verifyExpandPatchOFgiantplattlet() throws InterruptedException {
        String cell=props.getProperty("GiantPlatelet");
        Assert.assertEquals(PlateleteReport.clickOnExpandButton(),"- Extracted Cell");
        logger.info("Reclassification happened successufully from giant to clump");
    }

    @Test(priority = 163, enabled = true)
    public void verifyReclassificationOFGaintTOClump() throws InterruptedException {
       String cell=props.getProperty("GiantPlatelet");
        Assert.assertTrue(PlateleteReport.reclassificationOfGaintTOClump(cell));
        logger.info("Reclassification happened successufully from giant to clump");
    }




    @Test(priority = 164, enabled = true)
    public void verifyReclassificationOFClumpTOGiant() throws InterruptedException {
        String cell=props.getProperty("ClumpPlatelt");
        Assert.assertTrue(PlateleteReport.reclassificationOfClumpTOGiant(cell));
        logger.info("Reclassification happened successufully from giant to clump");
    }




    @Test(priority = 165, enabled = true)
    public void verifyTheRefrenceImagesOfGiantAndPlateletClump() throws InterruptedException, IOException {
//        int Count=PlateleteReport.verifyTheReferenceImage();
//        Assert.assertEquals(Count,4);
        Assert.assertTrue(PlateleteReport.verifyTheReferenceImage());
        logger.info("The Refrence images count is 4 ");

    }



    @Test(priority = 345, enabled = true)
    public void clickoncommenticon() throws InterruptedException {
        Assert.assertTrue(comment.clickoncommentIcon());
        logger.info("Clicked on Comment Icon Successfully");
    }

    @Test(priority = 350, enabled = true)
    public void loadcommentbox() throws InterruptedException {
        Assert.assertTrue(comment.commentboxlaod());
        logger.info("Comment Box laoded succssfully");
    }

    @Test(priority = 355, enabled = true)
    public void validatebox() throws InterruptedException {
        //  Assert.assertTrue(comment.validatecommentbox());
        Assert.assertEquals(comment.validatecommentbox(), "Comments");
        logger.info("Comment Box is verified successfully");
    }

    @Test(priority = 360, enabled = true)
    public void closecommentbox() throws InterruptedException {
        Assert.assertTrue(comment.closecommentbox());
        logger.info("Clicked on Comment close Icon Successfully");
    }

    @Test(priority = 365, enabled = true)
    public void clickoncommenticon1() throws InterruptedException {
        comment.clickonCommentIcon();
        logger.info("Clicked on Comment Icon Successfully");
    }

    @Test(priority = 370, enabled = true)
    public void checkuser() throws InterruptedException {
        Assert.assertTrue(comment.checkuser());
        logger.info("user can update the comment");}


    @Test(priority = 375, enabled = true, dependsOnMethods = "checkuser")
    public void checkpostbtnclickable() throws InterruptedException {
        Assert.assertTrue(comment.checkpostbtnclickable());
        logger.info("Post button is clickable ");
    }

    @Test(priority = 380, enabled = false, dependsOnMethods = "checkuser")
    public void checkaleartmsg() throws InterruptedException {
        String actualAlerMessage = comment.validatealertmsg();
        Assert.assertEquals(actualAlerMessage, "?\n" +
                "Oops!\n" +
                "Please enter your comment");
        logger.info("Alert message is verified");
    }

    @Test(priority = 385, enabled = true, dependsOnMethods = "checkuser")
    public void checkcommentbox() throws InterruptedException {
        Assert.assertTrue(comment.entercomment());
        logger.info("comment box is editable for entring the comments ");
    }



    @Test(priority = 390, enabled = true, dependsOnMethods = "checkuser")
    public void Platelet_entercomment() throws InterruptedException {
        String tab = "platelettab";
        Assert.assertTrue(comment.entercomment(tab));
        logger.info("comment pushed successfully for platelettab tab");
    }


    @Test(priority = 400, enabled = true, dependsOnMethods = "checkuser")
    public void Platelet_checkcomment() throws InterruptedException {
        String tab = "platelettab";
        Assert.assertTrue(comment.verify_pushedcomment(tab));
        logger.info("comment verificaiton Done successfully for platelettab");
    }










   /* @Test(priority = 96,enabled=true)
    public void verifyNoteTextMessage(){
        String actualTextMessage=PlateleteReport.noteMessageOnPlatelet();
        Assert.assertEquals(actualTextMessage,props.getProperty("noteText"));
    }


   @Test(priority = 99, enabled = true)
    public void verifycellNameOnREferences() throws InterruptedException {
        String actualCellNameOnReferences = PlateleteReport.cellNameOnREferenceTab();
        Assert.assertEquals(actualCellNameOnReferences, "\n" +
                "Platelet");
        logger.info("Platelet is present on references");
    }*/


    //Verify list of rows of Platelet Absolute Couts tabel
  /*  @Test(priority = 95,enabled=true)
    public void verifypltAbsolutepatches() throws InterruptedException {
    	Assert.assertTrue(PlateleteReport.getpltAbsolutepatches());
        logger.info("List of shown patches in PltAbsolute is verified");
    }*/

    //verify RBC Poik grading


    //Get total percentage of WBC absolute
  /*  @Test(priority = 101,enabled=true)
    public void verifyPlateletAbsolutePercentageTotal() throws Exception
    {
    	Assert.assertTrue(PlateleteReport.verifyPlateletAbsolutePercentageTotal());
        logger.info("Total of Counts and Percentage is verified ");
    }*/
    
   /* //Verify Platelet Diameter headers
    @Test(priority = 103, enabled=true)
    public void verifypltDiameterColumns() throws InterruptedException {
    	String pltdiametercolumns=PlateleteReport.getPlateletDiameterColumns();
    	Assert.assertEquals(pltdiametercolumns,props.getProperty("diameterheaderdata"));
        logger.info("List of Columns of Platelet Diameter is verified");
    }   */

    //Verify list of rows of Platelet Absolute tabel
  /*  @Parameters({"product"})
    @Test(priority = 105,enabled=true)
    public void VerifyPlateletAbsoluteTableData(String product) throws Exception {
    	Assert.assertTrue(PlateleteReport.VerifyPlateletAbsoluteTableData(product));
        logger.info("List of data in Platelet Absolute is verified");
    }*/


}
