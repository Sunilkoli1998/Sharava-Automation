package com.Common;

import com.data.Shonit_data.PropertiesFile;
import com.utilities.BrowserSetUp;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import java.io.IOException;
import java.util.List;
import java.util.Properties;

public class MicroscopicViewTest extends BrowserSetUp {
    public MicroscopicView microscopicview;
    public Properties props;
    private Comment comment;
    private  ShonitWBCReport WBCReport;

    private final Logger logger = LogManager.getLogger(MicroscopicViewTest.class);


    @BeforeSuite
    public void setUp() throws Exception {
        driver = getDriver();
        microscopicview = new MicroscopicView(driver);
        comment=new Comment(driver);
        WBCReport = new ShonitWBCReport(driver);
        props = PropertiesFile.prop;

    }

    //Verify the Microscopic view tab
    @Test(priority = 3, enabled = true)
    public void clickOnMicroscopicViewTab() throws InterruptedException {
        Thread.sleep(5000);
        test = extent.createTest("Microscopic view");
        if (microscopicview.clickOnMicroscopicViewTab()) {
            Assert.assertTrue(true);
            logger.info("clicked on micorscopic view tab");
        } else {
            logger.info("Failed to click on microscopic view tab");
            Assert.assertTrue(false);
        }

    }
//Microscopic View Page load and sample ID match
  /*  @Test(priority = 5, enabled=true)
        public void verifyMicroscopicPageLoad() throws InterruptedException{
        if(microscopicview.verifyMicroscopicPageLoad()) {
        	Assert.assertTrue(true);
        	logger.info("Microscopic FOV Panel loaded successfully");
        }
        else {
        	logger.info("Failed to laod microscopic FOV Panel ");
        	Assert.assertTrue(false);
        }
    }*/

  /*  @Test(priority = 7, enabled=true)
    public void verifyFovSampleID() throws InterruptedException{
        if (microscopicview.verifyFovSampleID()) {
     	   Assert.assertTrue(true);
            logger.info("FOV slide id and opened sample id both are showing same");
        }
        else {
        	logger.info("FOV slide id and opened sample id both are showing same");
     	   Assert.assertTrue(false);
        }
    }*/
//    //Verify the number of FoV and FoV dots are matching
//    @Parameters({"product"})
//    @Test(priority = 9, enabled=true)
//    public void verifyNumberOfFovDots(String product) throws InterruptedException{
//       if (microscopicview.verifyNumberOfFovDots(product)){
//    	   Assert.assertTrue(true);
//           logger.info("Count of FOV dots are same as expected ");
//       }
//       else{
//    	   logger.info("Count of FOV dots are not same as expected ");
//    	   Assert.assertTrue(false);
//       }
//    }

    //Open the FoV by clicking on FoV dot
    @Test(priority = 11, enabled = false)
    public void SelectAnyRandomDot() throws InterruptedException {
        if (microscopicview.SelectAnyRandomDot()) {
            Assert.assertTrue(true);
            logger.info("clicked on any random FOV Dot");
        } else {
            logger.info("failed to click on any random FOV Dot");
            Assert.assertTrue(false);
        }
    }

//    //Open the FoV by clicking on FoV dot
//    @Test(priority = 13, enabled=true)
//    public void verifyListOfAttributs() throws InterruptedException{
//        if (microscopicview.verifyListOfAttributs()){
//     	   Assert.assertTrue(true);
//            logger.info("All expected number of attributes are shonwing");
//        }
//        else{
//        	logger.info("failed to show all expected number of attributes");
//     	   Assert.assertTrue(false);
//        }
//    }

    //Open the FoV by clicking on FoV dot
  /*  @Test(priority = 15, enabled=true)
    public void SelectAnyRandomAttribute() throws InterruptedException{
        if (microscopicview.SelectAnyRandomAttribute()){
     	   Assert.assertTrue(true);
            logger.info("clicked on any random attribut of opened sample to show Full FOV");
        }
        else{
        	logger.info("failed to click on any random attribut to show full FOV");
     	   Assert.assertTrue(false);
        }
    }*/

    //Verification of successful canvas FoV Image load
    @Test(priority = 17, enabled = true)
    public void verifyCanvasImageLoaded() throws InterruptedException {
        if (microscopicview.verifyCanvasImageLoaded()) {
            Assert.assertTrue(true);
            logger.info("Images is loaded in the canvas ");
        } else {
            logger.info("failed to load images in the canvas ");
            Assert.assertTrue(false);
        }
    }

    //Verification of successful canvas FoV Image load
   /* @Test(priority = 19, enabled=true)
    public void verifyCanvasSize() throws InterruptedException {
        if (microscopicview.verifyCanvasSize()){
      	   Assert.assertTrue(true);
             logger.info("canvas diamention to show full FOV is same as expected ");
         }
         else{
         	logger.info("failed to show canvas in expected diamention ");
      	   Assert.assertTrue(false);
         }
    }*/

    //Correctness of opened foV
   /* @Test(priority = 21, enabled=true)
    public void verifyImageCountSection() throws InterruptedException {
        if (microscopicview.verifyImageCountSection()){
       	   Assert.assertTrue(true);
              logger.info("image count section is visible along with one edit box");
          }
          else{
          	logger.info("failed to show image count section along with one edit box");
       	   Assert.assertTrue(false);
          }
    }*/

    //Verify the necessary buttons are present
    @Test(priority = 23, enabled = true)
    public void verifyFovButtons() throws InterruptedException {
        if (microscopicview.verifyFovButtons()) {
            Assert.assertTrue(true);
            logger.info("All Fov buttons are visible on the convas");
        } else {
            logger.info("failed to show All Fov buttons on the convas");
            Assert.assertTrue(false);
        }
    }

    @Test(priority = 25, enabled = true)
    public void verifyImageZoomIn() throws InterruptedException, IOException {
        boolean status = false;
        if (microscopicview.verifyImageZoomIn()) {
            logger.info("The images were zoomed in successfully");
            status = true;
        } else
            logger.info("The images were not zoomed in successfully");
        Assert.assertTrue(status);
    }

    @Test(priority = 27, enabled = true)
    public void verifyImageSizeReset() throws InterruptedException, IOException {
        boolean status = false;
        if (microscopicview.verifyImageSizeReset()) {
            logger.info("The images were zoomed in successfully");
            status = true;
        } else
            logger.info("The images were not zoomed in successfully");
        Assert.assertTrue(status);
    }

    @Test(priority = 29, enabled = true)
    public void verifyImageZoomOut() throws InterruptedException, IOException {
        boolean status = false;
        if (microscopicview.verifyImageZoomOut()) {
            logger.info("The images were zoomed in successfully");
            status = true;
        } else
            logger.info("The images were not zoomed in successfully");
        Assert.assertTrue(status);
    }
    //Verify the next and previous buttons to load images
    @Test(priority = 31, enabled = true)
    public void verifyGoToNextImage() throws InterruptedException, IOException {
        boolean status = false;
        if (microscopicview.verifyGoToNextImage()) {
            logger.info("next image is loaded successfully ");
            status = true;
        } else
            logger.info("Failed to load the next image");
        Assert.assertTrue(status);
    }

    @Test(priority = 32, enabled = true)
    public void verifyGoToPrevImage() throws InterruptedException, IOException {
        boolean status = false;
        if (microscopicview.verifyGoToPrevImage()) {
            logger.info("previous image is loaded successfully ");
            status = true;
        } else
            logger.info("Failed to load the prev image");
        Assert.assertTrue(status);
    }
    @Test(priority = 33, enabled = true)
    public void verifyGoToDownImage() throws InterruptedException, IOException {
        boolean status = false;
        if (microscopicview.verifyGoToBottomImage()) {
            logger.info("Bottom image is loaded successfully ");
            status = true;
        } else
            logger.info("Failed to load the bottom image");
        Assert.assertTrue(status);
    }

    @Test(priority = 34, enabled = true)
    public void verifyGoToUpImage() throws InterruptedException, IOException {
        boolean status = false;
        if (microscopicview.verifyGoToTopImage()) {
            logger.info("Top image is loaded successfully ");
            status = true;
        } else
            logger.info("Failed to load the top image");
        Assert.assertTrue(status);
    }

    @Test(priority = 36, enabled = true)
    public void verifyenterNumberInTextbox() {
        String actualFOVnumber = microscopicview.enterNumberInTextbox();
        Assert.assertEquals(actualFOVnumber,props.getProperty("FovNumberatCanvas"));
        logger.info(" same FOV Number displayed on  microscopic view cell ");
    }


    @Test(priority = 37, enabled = true)
    public void verifyMarkAll() {
        String actualtext = microscopicview.verifyMArkAll();
        Assert.assertEquals(actualtext, "Mark All");
        logger.info(" Mark All text is present on microscopic view page");
    }

    @Test(priority = 38, enabled = true)
    public void verifyingMinimisingOfFullFov() {
        Assert.assertTrue(microscopicview.minimisingOfFullFov());
        logger.info("The images were zoomed in successfully");
    }

    @Test(priority = 39, enabled = true)
    public void verifyingMaximisingOfFullFov() {
        Assert.assertTrue(microscopicview.maximisingOfFullFov());
        logger.info("The images were zoomed out successfully");
    }


    @Test(priority = 42, enabled = true)
    public void verifyListOfAttributes() throws InterruptedException, IOException {
        boolean status = false;
        if (microscopicview.verifyListOfAttributes()) {
            logger.info("All expected list of attrites are visible at right side of canvas");
            status = true;
        } else
            logger.info("failes to show All expected list of attrites at right side of canvas");
        Assert.assertTrue(status);
    }


    @Test(priority = 43,enabled = true)
    public void verifyFullImange(){
        boolean status=microscopicview.viewFullImage();
        Assert.assertTrue(status);
        logger.info(" Microscopic Image is expanded successfully to view the full Image  ");
    }




    @Test(priority = 44, enabled = true)
    public void verifyNavigationInFullPatchView(){
        Assert.assertTrue(WBCReport.navigationInFullPatchView());
        logger.info("Microscopic navigation in full patch view is verified");
    }







    @Test(priority = 71, enabled = true)
    public void clickoncommenticon() throws InterruptedException {
        Assert.assertTrue(comment.clickoncommentIcon());
        logger.info("Clicked on Comment Icon Successfully");
    }

    @Test(priority = 73, enabled = true)
    public void loadcommentbox() throws InterruptedException {
        Assert.assertTrue(comment.commentboxlaod());
        logger.info("Comment Box laoded succssfully");
    }

    @Test(priority = 75, enabled = true)
    public void validatebox() throws InterruptedException {
        //  Assert.assertTrue(comment.validatecommentbox());
        Assert.assertEquals(comment.validatecommentbox(), "Comments");
        logger.info("Comment Box is verified successfully");
    }

    @Test(priority = 77, enabled = true)
    public void closecommentbox() throws InterruptedException {
        Assert.assertTrue(comment.closecommentbox());
        logger.info("Clicked on Comment close Icon Successfully");
    }

    @Test(priority = 79, enabled = true)
    public void clickoncommenticon1() throws InterruptedException {
        comment.clickonCommentIcon();
        logger.info("Clicked on Comment Icon Successfully");
    }

    @Test(priority = 81, enabled = true)
    public void checkuser() throws InterruptedException {
        Assert.assertTrue(comment.checkuser());
        logger.info("user can update the comment");}


    @Test(priority = 83, enabled = true, dependsOnMethods = "checkuser")
    public void checkpostbtnclickable() throws InterruptedException {
        Assert.assertTrue(comment.checkpostbtnclickable());
        logger.info("Post button is clickable ");
    }

    @Test(priority = 85, enabled = false, dependsOnMethods = "checkuser")
    public void checkaleartmsg() throws InterruptedException {
        String actualAlerMessage = comment.validatealertmsg();
        Assert.assertEquals(actualAlerMessage, "?\n" +
                "Oops!\n" +
                "Please enter your comment");
        logger.info("Alert message is verified");
    }

    @Test(priority = 87, enabled = true, dependsOnMethods = "checkuser")
    public void checkcommentbox() throws InterruptedException {
        Assert.assertTrue(comment.entercomment());
        logger.info("comment box is editable for entring the comments ");
    }

    //----------------------- Validation of comments pushing in all tab  ------------------

    @Test(priority = 89, enabled = true, dependsOnMethods = "checkuser")
    public void MICROSCOPY_entercomment() throws InterruptedException {
        String tab = "microscopytab";
        Assert.assertTrue(comment.entercomment(tab));
        logger.info("comment pushed successfully for wbc tab");
    }

    @Test(priority = 91, enabled = true, dependsOnMethods = "checkuser")
    public void MICROSCOPY_checkcomment() throws InterruptedException {
        String tab = "microscopytab";
        Assert.assertTrue(comment.verify_pushedcomment(tab));
        logger.info("comment verificaiton Done successfully for wbc tab");
    }



















  /*  @Test(priority = 44, enabled=true)
    public void visibilityOfPatchesOnFov() throws InterruptedException, IOException{
        boolean status=false;
        if (microscopicview.visibilityOfPatchesOnFov())
        {
            logger.info("patches on FOV are founded(if not found checking only next 10 images) ");
            status=true;
        }
        else
            logger.info("patches are not found in current and next 10 FOVs");
        Assert.assertTrue(status);
    }*/
    
   /* @Test(priority = 39, enabled=true)
    public void verifyClearAllButton() throws InterruptedException, IOException{
        boolean status=false;
        if (microscopicview.verifyClearAllButton()){
            logger.info("clear All is working as expected ");
            status=true;
        }
        else
            logger.info("clear All is not working as expected ");
        Assert.assertTrue(status);
    }
    @Test(priority = 41, enabled=true)
    public void closeCanvas() throws InterruptedException{
        boolean status=false;
        if (microscopicview.closeCanvas()){
            logger.info("canvas closed ");
            status=true;
        }
        else
            logger.info("canvas could'nt close");
        Assert.assertTrue(status);
    }*/


}
