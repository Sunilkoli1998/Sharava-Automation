package com.Common;

import com.data.Shonit_data.PropertiesFile;
import com.utilities.BrowserSetUp;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import java.util.Properties;

import com.Common.Comment;

public class CommentTest extends BrowserSetUp {

    public Properties props;
    public Comment comment;
    private final Logger logger = LogManager.getLogger(CommentTest.class);

    @BeforeSuite
    public void setUp() throws Exception {
        driver = getDriver();
        comment = new Comment(driver);
        PropertiesFile.readCommentPropertiesFile();
        props = PropertiesFile.prop;
    }
    //---------------------------------- Basic features ----------------------------

     @Test(priority = 101, enabled = true)
    public void gotoMetricsTab() throws InterruptedException {
        test = extent.createTest("Comment Test");
        String tab = "metricstab";
        Assert.assertTrue(comment.clickonTab(props.getProperty(tab)));
        logger.info("metrics tab opened Successfully");
    }

    @Test(priority = 106, enabled = true)
    public void clickoncommenticon() throws InterruptedException {
        Assert.assertTrue(comment.clickoncommentIcon());
        logger.info("Clicked on Comment Icon Successfully");
    }

    @Test(priority = 103, enabled = true)
    public void loadcommentbox() throws InterruptedException {
        Assert.assertTrue(comment.commentboxlaod());
        logger.info("Comment Box laoded succssfully");
    }

    @Test(priority = 104, enabled = true)
    public void validatebox() throws InterruptedException {
        //  Assert.assertTrue(comment.validatecommentbox());
        Assert.assertEquals(comment.validatecommentbox(), "Comments");
        logger.info("Comment Box is verified successfully");
    }

    @Test(priority = 105, enabled = true)
    public void closecommentbox() throws InterruptedException {
        Assert.assertTrue(comment.closecommentbox());
        logger.info("Clicked on Comment close Icon Successfully");
    }

    @Test(priority = 102, enabled = true)
    public void clickoncommenticon1() throws InterruptedException {
        comment.clickonCommentIcon();
        logger.info("Clicked on Comment Icon Successfully");
    }

    @Test(priority = 107, enabled = true)
    public void checkuser() throws InterruptedException {
        Assert.assertTrue(comment.checkuser());
        logger.info("user can update the comment");
    }

    @Test(priority = 108, enabled = true, dependsOnMethods = "checkuser")
    public void checkpostbtnclickable() throws InterruptedException {
        Assert.assertTrue(comment.checkpostbtnclickable());
        logger.info("Post button is clickable ");
    }

    @Test(priority = 109, enabled = false, dependsOnMethods = "checkuser")
    public void checkaleartmsg() throws InterruptedException {
        String actualAlerMessage = comment.validatealertmsg();
        Assert.assertEquals(actualAlerMessage, "?\n" +
                "Oops!\n" +
                "Please enter your comment");
        logger.info("Alert message is verified");
    }

    @Test(priority = 111, enabled = true, dependsOnMethods = "checkuser")
    public void checkcommentbox() throws InterruptedException {
        Assert.assertTrue(comment.entercomment());
        logger.info("comment box is editable for entring the comments ");
    }

    //----------------------- Validation of comments pushing in all tab  ------------------

   /* @Test(priority = 201, enabled = true, dependsOnMethods = "checkuser")
    public void Metrics_entercomment() throws InterruptedException {
        String tab = "metricstab";
        Assert.assertTrue(comment.entercomment(tab));
        logger.info("comment pushed successfully metrics tab");
    }

    @Test(priority = 203, enabled = true, dependsOnMethods = "checkuser")
    public void WBC_entercomment() throws InterruptedException {
        String tab = "wbctab";
        Assert.assertTrue(comment.entercomment(tab));
        logger.info("comment pushed successfully for wbc tab");
    }

    @Test(priority = 205, enabled = false, dependsOnMethods = "checkuser")
    public void RBC_entercomment() throws InterruptedException {
        String tab = "rbctab";
        Assert.assertTrue(comment.entercomment(tab));
        logger.info("comment pushed successfully for rbctab");
    }

    @Test(priority = 207, enabled = true, dependsOnMethods = "checkuser")
    public void Platelet_entercomment() throws InterruptedException {
        String tab = "platelettab";
        Assert.assertTrue(comment.entercomment(tab));
        logger.info("comment pushed successfully for platelettab");
    }

//    @Test(priority = 209,enabled=true,dependsOnMethods= "checkuser")
//    public void Visual_entercomment() throws InterruptedException {
//    	String tab="visualstab";
//        Assert.assertTrue(comment.entercomment(tab));
//        logger.info("comment pushed successfully for visualstab");
//    }*/

    @Test(priority = 211, enabled = true, dependsOnMethods = "checkuser")
    public void Microscopy_entercomment() throws InterruptedException {
        String tab = "microscopytab";
        Assert.assertTrue(comment.entercomment(tab));
        logger.info("comment pushed successfully for microscopytab");
    }

    @Test(priority = 213, enabled = true, dependsOnMethods = "checkuser")
    public void Quality_entercomment() throws InterruptedException {
        String tab = "qualitytab";
        Assert.assertTrue(comment.entercomment(tab));
        logger.info("comment pushed successfully for qualitytab");
    }

    //----------------------- Validation of comments pushing in all tab  ------------------

   /* @Test(priority = 301, enabled = true, dependsOnMethods = "checkuser")
    public void Metrics_checkcomment() throws InterruptedException {
        String tab = "metricstab";
        Assert.assertTrue(comment.verify_pushedcomment(tab));
        logger.info("comment verificaiton Done successfully metrics tab");
    }

    @Test(priority = 303, enabled = true, dependsOnMethods = "checkuser")
    public void WBC_checkcomment() throws InterruptedException {
        String tab = "wbctab";
        Assert.assertTrue(comment.verify_pushedcomment(tab));
        logger.info("comment verificaiton Done successfully for wbc tab");
    }

    @Test(priority = 305, enabled = false, dependsOnMethods = "checkuser")
    public void RBC_checkcomment() throws InterruptedException {
        String tab = "rbctab";
        Assert.assertTrue(comment.verify_pushedcomment(tab));
        logger.info("comment verificaiton Done successfully for rbctab");
    }

    @Test(priority = 307, enabled = true, dependsOnMethods = "checkuser")
    public void Platelet_checkcomment() throws InterruptedException {
        String tab = "platelettab";
        Assert.assertTrue(comment.verify_pushedcomment(tab));
        logger.info("comment verificaiton Done successfully for platelettab");
    }

//    @Test(priority = 309,enabled=true,dependsOnMethods= "checkuser")
//    public void Visual_checkcomment() throws InterruptedException {
//    	String tab="visualstab";
//        Assert.assertTrue(comment.verify_pushedcomment(tab));
//        logger.info("comment verificaiton Done successfully for visualstab");
//    }*/

    @Test(priority = 311, enabled = true, dependsOnMethods = "checkuser")
    public void Microscopy_checkcomment() throws InterruptedException {
        String tab = "microscopytab";
        Assert.assertTrue(comment.verify_pushedcomment(tab));
        logger.info("comment verificaiton Done successfully for microscopytab");
    }

    @Test(priority = 313, enabled = true, dependsOnMethods = "checkuser")
    public void Quality_checkcomment() throws InterruptedException {
        String tab = "qualitytab";
        Assert.assertTrue(comment.verify_pushedcomment(tab));
        logger.info("comment verificaiton Done successfully for qualitytab");
    }

//----------------------- Validation of comment sequence in metrics tab  ------------------  

    @Test(priority = 401, enabled =false, dependsOnMethods = "checkuser")
    public void verifyMetricsFullComments() throws InterruptedException {
        Assert.assertTrue(comment.verifyMetricsFullComments());
        logger.info("comment sequnce is verified in metrics tab");
    }


}