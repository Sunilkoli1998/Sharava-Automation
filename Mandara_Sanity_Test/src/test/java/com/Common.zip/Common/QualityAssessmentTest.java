package com.Common;

import com.data.Shonit_data.PropertiesFile;
import com.utilities.BrowserSetUp;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import java.util.Properties;

public class QualityAssessmentTest extends BrowserSetUp {

    public QualityAssessment qualityAssessment;
    public Properties props;
    private Comment comment;

    private final Logger logger = LogManager.getLogger(QualityAssessmentTest.class);


    @BeforeSuite
    public void setUp() throws Exception {
        driver = getDriver();
        qualityAssessment = new QualityAssessment(driver);
        comment = new Comment(driver);
        props = PropertiesFile.prop;

    }


    @Test(priority = 1, enabled = true)
    public void clickOnQualityAssessmentTab() throws InterruptedException {
        Thread.sleep(3000);
        test = extent.createTest("Quality Assessment");
        if (qualityAssessment.clickOnQualityAssessmentTab()) {
            Assert.assertTrue(true);
            logger.info("clicked on Quality Assessment tab");
        } else {
            logger.info("Failed to click on Quality Assessment tab");
            Assert.assertTrue(false);
        }

    }

    @Test(priority = 2, enabled = true)
    public void verifyQualityAssessmentHeader() {
        String actualHeader = qualityAssessment.qualityAssessmentHeader();
        Assert.assertEquals(actualHeader, "Quality Assessment");
        logger.info(" header is verified on Quality Assessment tab ");
    }

    @Test(priority = 3, enabled = false)
    public void verifySuggestionOnQualityAssessment() {
        String actualSuggestion = qualityAssessment.suggestionOnQualityAssessmentTab();
        Assert.assertEquals(actualSuggestion, "Qi: Sample Is Degenerated,Qi: Stain Quality Is Suboptimal,");
        logger.info(" suggestion is verified on Quality Assessment tab ");
    }


    @Test(priority = 5, enabled = true)
    public void clickoncommenticon() throws InterruptedException {
        Assert.assertTrue(comment.clickoncommentIcon());
        logger.info("Clicked on Comment Icon Successfully");
    }

    @Test(priority = 7, enabled = true)
    public void loadcommentbox() throws InterruptedException {
        Assert.assertTrue(comment.commentboxlaod());
        logger.info("Comment Box laoded succssfully");
    }

    @Test(priority = 9, enabled = true)
    public void validatebox() throws InterruptedException {
        //  Assert.assertTrue(comment.validatecommentbox());
        Assert.assertEquals(comment.validatecommentbox(), "Comments");
        logger.info("Comment Box is verified successfully");
    }

    @Test(priority = 11, enabled = true)
    public void closecommentbox() throws InterruptedException {
        Assert.assertTrue(comment.closecommentbox());
        logger.info("Clicked on Comment close Icon Successfully");
    }

    @Test(priority = 13, enabled = true)
    public void clickoncommenticon1() throws InterruptedException {
        comment.clickonCommentIcon();
        logger.info("Clicked on Comment Icon Successfully");
    }

   @Test(priority = 14, enabled = true)
    public void checkuser() throws InterruptedException {
        Assert.assertTrue(comment.checkuser());
        logger.info("user can update the comment");
    }

    @Test(priority = 17, enabled = true)
    public void checkpostbtnclickable() throws InterruptedException {
        Assert.assertTrue(comment.checkpostbtnclickable());
        logger.info("Post button is clickable ");
    }

    @Test(priority = 19, enabled = false)
    public void checkaleartmsg() throws InterruptedException {
        String actualAlerMessage = comment.validatealertmsg();
        Assert.assertEquals(actualAlerMessage, "?\n" +
                "Oops!\n" +
                "Please enter your comment");
        logger.info("Alert message is verified");
    }

    @Test(priority = 21, enabled = true)
    public void checkcommentbox() throws InterruptedException {
        Assert.assertTrue(comment.entercomment());
        logger.info("comment box is editable for entring the comments ");
    }

    //----------------------- Validation of comments pushing in all tab  ------------------

    @Test(priority = 25, enabled = true)
    public void Quality_entercomment() throws InterruptedException {
        String tab = "qualitytab";
        Assert.assertTrue(comment.entercomment(tab));
        logger.info("comment pushed successfully for quality tab");
    }

    @Test(priority = 27, enabled = true)
    public void Quality_checkcomment() throws InterruptedException {
        String tab = "qualitytab";
        Assert.assertTrue(comment.verify_pushedcomment(tab));
        logger.info("comment verificaiton Done successfully for quality tab");
    }


    @Test(priority = 29, enabled = false)
    public void visibilityOfBacktolist() throws InterruptedException {
        String Verifybacktolist = qualityAssessment.visibilityOfBacktolist();
        Assert.assertEquals(Verifybacktolist, props.getProperty("backtolistdata"));
        logger.info("visibility of Back to list is verified " + Verifybacktolist);
    }

    // verify availability of back to list button
    @Test(priority = 31, enabled = false)
    public void verifyBacktolist() throws InterruptedException {
        Assert.assertTrue(qualityAssessment.verifyBacktolist());
        logger.info("Functionality of back to list is verified");
    }

    @Test(priority = 33, enabled = false)
    public void verifyLogOut() throws InterruptedException {
        Assert.assertTrue(qualityAssessment.checkLogout());
        logger.info(" user has successfully logged out from application ");
    }


}
