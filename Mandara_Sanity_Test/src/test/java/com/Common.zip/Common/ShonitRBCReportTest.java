package com.Common;

import com.data.Shonit_data.PropertiesFile;
import com.utilities.BrowserSetUp;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import java.io.IOException;
import java.util.List;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

public class ShonitRBCReportTest extends BrowserSetUp {

    public Properties props;
    public ShonitRBCReport RbcReport;
    private ShonitWBCReport WBCReport;
    private Comment comment;
    private final Logger logger = LogManager.getLogger(ShonitRBCReportTest.class);
    public BrowserSetUp pageload;

    @BeforeSuite
    public void setUp() throws Exception {
        driver = getDriver();
        RbcReport = new ShonitRBCReport(driver);
        WBCReport = new ShonitWBCReport(driver);
        comment=new Comment(driver);
        props = PropertiesFile.prop;
    }

//------------------------------ RBC Tab ------------------------

    //Switch to RBC tab
    @Test(priority = 3)
    public void switchtoRBCTab() throws InterruptedException {
        Thread.sleep(5000);
        test = extent.createTest("Shonit RBC Tab");
        Assert.assertTrue(RbcReport.clickonRBCTab());
        logger.info("Clicked on RBC Tab of Report page");
    }

    //Verify list of Tabels
    @Test(priority = 5)
    public void verifyRBCTab() throws InterruptedException {
        Thread.sleep(3000);
        String tabs = RbcReport.getRBCListofTabels();
        Assert.assertEquals(tabs, "RBC Size\n" +
                "RBC Poikilocytes");
        logger.info("List of tabels in RBC tab is verified");
    }

//------------------------------ RBC Size ----------------------

    //Verify RBC Size headers
    @Test(priority = 107, enabled = true)
    public void verifyRBCSizeColumns() throws InterruptedException {
        String metricscolumns = RbcReport.getRBCSizeColoumns();
        Assert.assertEquals(metricscolumns, props.getProperty("rbcsizedata"));
        logger.info("List of columns of RBC Size is verified");
    }

    //Verify list of rows of RBC Size Couts tabel
    @Test(priority = 108, enabled = true)
    public void verifyRBCSizeRows() throws InterruptedException {
        String metricsrows = RbcReport.getRBCSizerows();
        Assert.assertEquals(metricsrows, "Microcyte,Normocyte,Round Macrocyte,Ovalo Macrocyte,");
        logger.info("List of Rows in RBC Size is verified");
    }

    //Verify the colour code based on the significant and nonsignificant for microcytes
    @Test(priority = 113, enabled = true)
    public void verifygradeColourForMicrocyte() throws InterruptedException {
//        String metricsrows = RbcReport.verifytheGradeForMicrocyte();
//        Assert.assertEquals(metricsrows, "non-significance","significance" );
//        logger.info("List of Rows in RBC Size is verified");
        WebElement grade = driver.findElement(By.xpath(props.getProperty("microcytedropdown")));
        WebElement gradecoulor = driver.findElement(By.xpath(props.getProperty("microcyteColour")));
        Assert.assertTrue(RbcReport.verifytheGradeForMicrocyte(grade,gradecoulor));
        logger.info("The grade colour is successfully verified");

    }
    //Verify the colour code based on the significant and nonsignificant for RoundMacrocyte
    @Test(priority = 114, enabled = true)
    public void verifygradeColourForNormocyte() throws InterruptedException {
        WebElement grade = driver.findElement(By.xpath(props.getProperty("Normocytedropdown")));
        WebElement gradecoulor = driver.findElement(By.xpath(props.getProperty("NormocyteColour")));
        Assert.assertTrue(RbcReport.verifytheGradeForNormocyte(grade,gradecoulor));
        logger.info("The grade colour is successfully verified");

    }
    //Verify the colour code based on the significant and nonsignificant for RoundMacrocyte
    @Test(priority = 114, enabled = true)
    public void verifygradeColourForRoundMacrocyte() throws InterruptedException {
        WebElement grade = driver.findElement(By.xpath(props.getProperty("RoundMacrocytedropdown")));
        WebElement gradecoulor = driver.findElement(By.xpath(props.getProperty("RoundMacrocyteColour")));
        Assert.assertTrue(RbcReport.verifytheGradeForMicrocyte(grade,gradecoulor));
        logger.info("The grade colour is successfully verified");

    }


    //Verify the colour code based on the significant and nonsignificant for OvaloMacrocyte
    @Test(priority = 115, enabled = true)
    public void verifygradeColourForOvaloMacrocyte() throws InterruptedException {
        WebElement grade = driver.findElement(By.xpath(props.getProperty("OvaloMacrocytedropdown")));
        WebElement gradecoulor = driver.findElement(By.xpath(props.getProperty("OvaloMacrocyteColour")));
        Assert.assertTrue(RbcReport.verifytheGradeForMicrocyte(grade,gradecoulor));
        logger.info("The grade colour is successfully verified");

    }






    @Test(priority = 117, enabled = true)
    public void verifySignificantAndSignificantText() {
        String actualText = RbcReport.typeOfSignificant();
        Assert.assertEquals(actualText, "Non Significant\n" +
                "Significant");
        logger.info("All significant text is verified ");
    }

    @Test(priority = 118, enabled = true)
    public void verifyNoteMessage() {
        String actualNote = RbcReport.noteMessage();
        //Assert.assertEquals(actualNote, props.getProperty("RBCNote"));
        Assert.assertTrue(actualNote.contains(props.getProperty("RBCNote")));
        logger.info("note message is displayed on below of report card");
    }
    //Verify the precent of the RBC size cell
    @Test(priority = 119, enabled = true)
public void verifythePercentageforRBCSize()
{
    Assert.assertTrue(RbcReport.VerifyPercentageForRBCSize());
    logger.info("The total percentage is 100%");
}






    //verify RBC size grading
    @Test(priority = 120, enabled = true)
    public void verifyRBCSizeGrading() throws Exception {
        Assert.assertTrue(RbcReport.verifyRBCSizeGrading());
        logger.info("Grading in RBC size is verified ");
    }


    @Test(priority = 121, enabled = true)
    public void verifyMetricNAme() {
        String actualText = RbcReport.metricsNameOnAovePatches();
        Assert.assertEquals(actualText, "Microcyte   \n" +
                "tune");
        logger.info("selected cell type  presented on RBC is verified ");
    }

    @Test(priority = 122, enabled = true)
    public void VerifyViewRBC() throws InterruptedException {
        String actualOptions = RbcReport.viewSettingRBC();
        Assert.assertEquals(actualOptions, "All\n" +
                "Modified\n" +
                "Marked for review");
        logger.info(" all view options are present on RBC ");

    }

    @Test(priority = 124, enabled = true)
    public void verifyEnableOrDisableViewSetting() {
        Assert.assertTrue(RbcReport.diableViewbeforeSelection());
        logger.info(" view setting is disabled before selection of any cell ");
    }


    @Test(priority = 125, enabled = false)
    public void verifyExpandButtonOnRbc() throws InterruptedException {
        String actualText = RbcReport.clickOnExpandButtonOnRBC();
        Assert.assertEquals(actualText, "- Extracted Cell");
        logger.info("after click on image  extracted cell text is present");
    }

    @Test(priority = 130, enabled = false)
    public void verifyNavigationInFullPatchView(){
        Assert.assertTrue(WBCReport.navigationInFullPatchView());
        logger.info("Microscopic navigation in full patch view is verified");
    }





       @Test(priority =140,enabled = false)
    public void navigateToRBCTab() throws InterruptedException {
        Thread.sleep(5000);
        Assert.assertTrue(RbcReport.clickonRBCTab());
        logger.info("Clicked on RBC Tab of Report page");
    }





    @Test(priority = 150, enabled = true)
    public void verifycellNameOnREferences() throws InterruptedException {
        String actualCellNameOnReferences = RbcReport.cellNameOnREferenceTab();
        Assert.assertEquals(actualCellNameOnReferences, "Microcyte");
        logger.info("Microcyte is present on references");
    }


    //verify RBCSize patches



//------------------------------ RBC Poikilocytes ----------------------


    //verify RBC Poik grading
    @Test(priority = 215, enabled = true)
    public void verifyRBCPoikGrading() throws Exception {
        Assert.assertTrue(RbcReport.verifyRBCPoikGrading());
        logger.info("Grading in RBC Poik is verified ");

    }
       @Test(priority =216,enabled = true )
        public void clickOnRBCRsizeGrading() throws InterruptedException{
        String actualpopup = RbcReport.rbcSizeRegrading();
        Assert.assertEquals(actualpopup, "Update Report Successful");
//        Assert.assertTrue(RbcReport.rbcSizeRegrading());
//        logger.info("the cell are regrade successfully");
}
    @Test(priority = 217)
    public void switchtoRBCPoikilocytesTab() throws InterruptedException {
        Assert.assertTrue(RbcReport.clickonRBCPoikilocytesTab());
        Thread.sleep(3000);
        logger.info("Clicked on RBC  poikilocytes Tab of Report page");
    }

    //Verify the colour code based on the significant and nonsignificant for Normanl
    @Test(priority = 218, enabled = true)
    public void verifygradeColourForNormal() throws InterruptedException {
        WebElement grade = driver.findElement(By.xpath(props.getProperty("Normaldropdown")));
        WebElement gradecoulor = driver.findElement(By.xpath(props.getProperty("NormalColour")));
        Assert.assertTrue(RbcReport.verifytheGradeForNormocyte(grade,gradecoulor));
        logger.info("The grade colour is successfully verified");

    }

    //Verify the colour code based on the significant and nonsignificant for Elliptocyte
    @Test(priority = 219, enabled = true)
    public void verifygradeColourForElliptocyte() throws InterruptedException {
        WebElement grade = driver.findElement(By.xpath(props.getProperty("Elliptocytedropdown")));
        WebElement gradecoulor = driver.findElement(By.xpath(props.getProperty("ElliptocyteColour")));
        Assert.assertTrue(RbcReport.verifytheGradeForMicrocyte(grade,gradecoulor));
        logger.info("The grade colour is successfully verified");

    }


    //Verify the colour code based on the significant and nonsignificant for Elliptocyte
    @Test(priority = 220, enabled = true)
    public void verifygradeColourForOvalocytr() throws InterruptedException {
        WebElement grade = driver.findElement(By.xpath(props.getProperty("Ovalocytedropdown")));
        WebElement gradecoulor = driver.findElement(By.xpath(props.getProperty("OvalocyteColour")));
        Assert.assertTrue(RbcReport.verifytheGradeForMicrocyte(grade,gradecoulor));
        logger.info("The grade colour is successfully verified");

    }
    //Verify the colour code based on the significant and nonsignificant for Target
    @Test(priority = 221, enabled = true)
    public void verifygradeColourForTarget() throws InterruptedException {
        WebElement grade = driver.findElement(By.xpath(props.getProperty("Targetdropdown")));
        WebElement gradecoulor = driver.findElement(By.xpath(props.getProperty("TargetColour")));
        Assert.assertTrue(RbcReport.verifytheGradeForMicrocyte(grade,gradecoulor));
        logger.info("The grade colour is successfully verified");

    }

    //Verify the colour code based on the significant and nonsignificant for TearDrop
    @Test(priority = 222, enabled = true)
    public void verifygradeColourFortearDrop() throws InterruptedException {
        WebElement grade = driver.findElement(By.xpath(props.getProperty("TearDropdropdown")));
        WebElement gradecoulor = driver.findElement(By.xpath(props.getProperty("TearDropColour")));
        Assert.assertTrue(RbcReport.verifytheGradeForMicrocyte(grade,gradecoulor));
        logger.info("The grade colour is successfully verified");

    }
    //Verify the colour code based on the significant and nonsignificant for Echinocyte
    @Test(priority = 223, enabled = true)
    public void verifygradeColourForEchinocyte() throws InterruptedException {
        WebElement grade = driver.findElement(By.xpath(props.getProperty("Echinocytedropdown")));
        WebElement gradecoulor = driver.findElement(By.xpath(props.getProperty("EchinocyteColour")));
        Assert.assertTrue(RbcReport.verifytheGradeForMicrocyte(grade,gradecoulor));
        logger.info("The grade colour is successfully verified");

    }

    //Verify the colour code based on the significant and nonsignificant for Fragmented
    @Test(priority = 224, enabled = true)
    public void verifygradeColourForFragmented() throws InterruptedException {
        WebElement grade = driver.findElement(By.xpath(props.getProperty("Fragmenteddropdown")));
        WebElement gradecoulor = driver.findElement(By.xpath(props.getProperty("FragmentedColour")));
        Assert.assertTrue(RbcReport.verifytheGradeForMicrocyte(grade,gradecoulor));
        logger.info("The grade colour is successfully verified");

    }

    @Test(priority =230,enabled = true )
    public void verifypatcheHeader() throws InterruptedException {
        String Header = (props.getProperty("rbcpoikrow"));
        Assert.assertTrue(RbcReport.verifypatcheHeader(Header));
        logger.info("Patches header is verified");
    }



    @Test(priority =235,enabled = true )
    public void clickOnGradeatRBCPoikilocytes() throws InterruptedException {
        String actualpopup = RbcReport.rbcPoikilocytesRegrading();
        Assert.assertEquals(actualpopup, "Update Report Successful");
        logger.info("alert message is verified on RBC tab");
    }








    @Test(priority = 240, enabled = true)
    public void verifySignificantAndSignificantInPoikilocytesText() {
        String actualText = RbcReport.typeOfSignificant();
        Assert.assertEquals(actualText, "Non Significant\n" +
                "Significant");
        logger.info("All significant text is verified ");
    }


    @Test(priority = 245, enabled = true)
    public void clickoncommenticon() throws InterruptedException {
        Assert.assertTrue(comment.clickoncommentIcon());
        logger.info("Clicked on Comment Icon Successfully");
    }

    @Test(priority = 250, enabled = true)
    public void loadcommentbox() throws InterruptedException {
        Assert.assertTrue(comment.commentboxlaod());
        logger.info("Comment Box laoded succssfully");
    }

    @Test(priority = 255, enabled = true)
    public void validatebox() throws InterruptedException {
        //  Assert.assertTrue(comment.validatecommentbox());
        Assert.assertEquals(comment.validatecommentbox(), "Comments");
        logger.info("Comment Box is verified successfully");
    }

    @Test(priority = 260, enabled = true)
    public void closecommentbox() throws InterruptedException {
        Assert.assertTrue(comment.closecommentbox());
        logger.info("Clicked on Comment close Icon Successfully");
    }

    @Test(priority = 265, enabled = true)
    public void clickoncommenticon1() throws InterruptedException {
        comment.clickonCommentIcon();
        logger.info("Clicked on Comment Icon Successfully");
    }

    @Test(priority = 270, enabled = true)
    public void checkuser() throws InterruptedException {
        Assert.assertTrue(comment.checkuser());
        logger.info("user can update the comment");}


    @Test(priority = 275, enabled = true, dependsOnMethods = "checkuser")
    public void checkpostbtnclickable() throws InterruptedException {
        Assert.assertTrue(comment.checkpostbtnclickable());
        logger.info("Post button is clickable ");
    }

    @Test(priority = 280, enabled = true, dependsOnMethods = "checkuser")
    public void checkaleartmsg() throws InterruptedException {
        String actualAlerMessage = comment.validatealertmsg();
        Assert.assertEquals(actualAlerMessage, "×\n" +
                "Oops!\n" +
                "Please enter your comment");
        logger.info("Alert message is verified");
    }


    @Test(priority = 285, enabled = true, dependsOnMethods = "checkuser")
    public void checkcommentbox() throws InterruptedException {
        Assert.assertTrue(comment.entercomment());
        logger.info("comment box is editable for entring the comments ");
    }

    //----------------------- Validation of comments pushing in all tab  ------------------

    @Test(priority = 290, enabled = true, dependsOnMethods = "checkuser")
    public void RBC_entercomment() throws InterruptedException {
        String tab = "rbctab";
        Assert.assertTrue(comment.entercomment(tab));
        logger.info("comment pushed successfully for wbc tab");
    }

    @Test(priority = 300, enabled = true, dependsOnMethods = "checkuser")
    public void RBC_checkcomment() throws InterruptedException {
        String tab = "rbctab";
        Assert.assertTrue(comment.verify_pushedcomment(tab));
        logger.info("comment verificaiton Done successfully for wbc tab");
    }



}
