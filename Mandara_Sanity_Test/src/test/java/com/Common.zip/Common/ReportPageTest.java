package com.Common;

import com.data.Shonit_data.PropertiesFile;
import com.utilities.BrowserSetUp;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import java.util.List;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

public class ReportPageTest extends BrowserSetUp {

    public static Properties props;
    public ReportPage reportpage;
    private final Logger logger = LogManager.getLogger(ReportPageTest.class);
    public BrowserSetUp pageload;
    public ListReport listreport;
    private Comment comment;



    @BeforeSuite
    public void setUp() throws Exception {
        driver = getDriver();
        reportpage = new ReportPage(driver);
        comment=new Comment(driver);
        props = PropertiesFile.prop;
        // PropertiesFile.readShonitListReportFile();
        //PropertiesFile.readPropertiesFIle();
        // PropertiesFile.readMandaraHomePropertiesFile();
        // PropertiesFile.readShonitPropertiesFile();
        // PropertiesFile.readSearchFilterFile();

    }

//--------------------------- List Report Page ----------------------------------


    @Parameters({"product"})
    @Test(priority = 1, enabled = true)
    public void searchsampleID(String product) throws InterruptedException {
        boolean samplestatus = reportpage.searchSampelID(product);
        Assert.assertTrue(samplestatus);
        logger.info("sample is searched for get the reprot for page");
    }

    @Parameters({"product"})
    @Test(priority = 2, enabled = true)
    public void verifysampleDetailAtReportPage(String product) throws InterruptedException {
        if (!product.contains("Shoni")) {
            Assert.assertTrue(reportpage.verifysampleDetailAtReportPage());
            logger.info("All Showing Sample details at top of the report are verified ");
        }
    }
    @Test(priority = 3)
    public void verifySlideID() throws Exception {
        String slidID = reportpage.verifySlideID();
        Assert.assertEquals(slidID, "Slide ID: " + props.getProperty("searchSampleID"));
        logger.info("Slid id is verified successfully " + slidID);
    }



    @Test(priority = 4, enabled = false)
    public void verifyAuditLog() throws InterruptedException {
        String audiLogText = reportpage.auditLog();
        Assert.assertEquals(audiLogText, "Audit Logs");
        logger.info("audit log is verified on report page");
    }

    @Test(priority = 5, enabled = true)
    public void verifyslideDetailAtReportPage() throws InterruptedException  {
        String slideDetails =reportpage.verifyslidedetails();
        Assert.assertEquals(slideDetails,"Description:Submitted By:Scan Mode:Product Version:Submitted At:");
        //Assert.assertEquals(slideDetails,props.getProperty("shonitslidedetails"));
//       Assert.assertTrue(slideDetails.contains(props.getProperty("shonitslidedetails")));
        logger.info("details are verified"+slideDetails);
    }



    @Test(priority = 6, enabled = true)
    public void verifyHeaderOnReportPage() throws Exception {
       // Thread.sleep(2000);
        String actualHeader = reportpage.reportPageHeader();
        Assert.assertEquals(actualHeader, "Summary\n" +
                "WBC\n" +
                "RBC\n" +
                "Platelet\n" +
                "Microscopic View\n" +
                "Quality Assessment");
        logger.info(" expected header is present on report page");
    }

    @Test(priority = 7)
    public void verifyPBSReportHeader() throws Exception {
        String pbsReportHeadings = reportpage.pbsReportHeader();
        Assert.assertEquals(pbsReportHeadings,
                "Name,Value (%),Correction,");
        logger.info(" expected header is present on report page");
    }


    @Test(priority = 8)
    public void verifyAllReportsName() throws Exception {
        String actualReportsName = reportpage.getListOfReportName();
        Assert.assertEquals(actualReportsName, "Neutrophils,Band Neut,Hypersegmented,Lymphocytes,Reactive Lymph,Monocytes,Eosinophils,Basophils,IG,Promyelocytes,Myelocytes,Metamyelocytes,Atypical/Blast,Atypical Lymph,Myloid Blast,Lymphoid Blast,NRBC,");
        logger.info("expected reports types are present on report page");
    }

    @Test(priority = 9)
    public void verifyPsImpressionHeader() throws Exception {
        String actualPSHeader = reportpage.psImpressiontHeader();
        Assert.assertEquals(actualPSHeader, "Name Impression,");
        logger.info(" expected header is present on  psImpression report page");
    }

    @Test(priority = 10)
    public void verifyPsImpressionsName() throws Exception {
        String actualName = reportpage.ListOfPSImpressiontName();
        Assert.assertEquals(actualName, "RBC MORPH,WBC MORPH,PLATELET MORPH,HEMOPARASITE,IMPRESSION,");
        logger.info(" all  expected names are present on report page");
    }

    @Test(priority = 11)
    public void verifyingOriginalReport() {
        String originalText = reportpage.originalReport();
        Assert.assertEquals(originalText, "Original");
        logger.info("original repport is visible on report page");
    }
    @Test(priority = 12)
    public void verifyDownloadReport() throws InterruptedException {
        String actualText = reportpage.downloadReport();
        Assert.assertEquals(actualText, "XLS\n" +
                "CSV");
        logger.info(" xls report format is present on downloads at report page ");
    }



    @Test(priority = 13,enabled = false)
    public void verifyreassingedWithDifferentUsers() throws InterruptedException {
        Assert.assertTrue(reportpage.reassingedWithDifferentUsers());
        logger.info("reassigned user name is displayed on ReassignedBy field ");
    }


    @Test(priority = 15,enabled = false)
    public void verifyAllAccessibilityButtonText() throws InterruptedException {
        String actualText = reportpage.reportAccessibilityButton();
        Assert.assertEquals(actualText, "restore Update\n" +
                "done Approve\n" +
                "close Reject,");
    }

    @Test(priority = 17,enabled = false)
    public void verifyUpadationOfImpresion() throws InterruptedException {
        String actualMessage = reportpage.getFirstImpressionComment();
        Assert.assertEquals(actualMessage, "Report Updated Successfully");
        // Assert.assertTrue(reportpage.getFirstImpressionComment());
        logger.info("first impression input filed is verified");
    }


    //verify Shonit report page is successfully open or not
    @Test(priority = 18, enabled = true)
    public void verifyReportPage() throws InterruptedException {
        driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
        test = extent.createTest("Report page");
        Assert.assertTrue(reportpage.verifyReportPage());
        // String actual= reportpage.verifyReportPage();
        // Assert.assertEquals(actual,"");
        logger.info("Report page is opened successfully ");
    }








   /* @Test(priority = 5)
    public void verifyAddingOfAllValues() {
        Integer actualValue = reportpage.additionOfAllValue();
        Assert.assertEquals(actualValue, "");
        logger.info("sum of all value is equals :  " + actualValue);
    }*/


    @Test(priority = 19,enabled = false)
    public void verifyCorrectionCount() throws InterruptedException {
        String message = reportpage.getCorrectValue();
        Assert.assertEquals(message, "Report Updated Successfully");
        // Assert.assertTrue(reportpage.getCorrectValue());
        logger.info("first correction filed is verified");
    }

    @Test(priority = 21,enabled = false)
    public void verifyReassignmentdetail() {
        String reassignedBy = reportpage.reassignmentdetails();
        Assert.assertEquals(reassignedBy, "Reassigned By:\n" + props.getProperty("username3"));
        logger.info("reassiged reviewer detail is verified on summary page" +reassignedBy );
    }


/*
    @Test(priority = 27, enabled = true)
    public void clickoncommenticon() throws InterruptedException {
        Thread.sleep(2000);
        Assert.assertTrue(comment.clickoncommentIcon());
        logger.info("Clicked on Comment Icon Successfully");
    }

    @Test(priority = 29, enabled = true)
    public void loadcommentbox() throws InterruptedException {
        Assert.assertTrue(comment.commentboxlaod());
        logger.info("Comment Box laoded succssfully");
    }

    @Test(priority = 31, enabled = true)
    public void validatebox() throws InterruptedException {
        //  Assert.assertTrue(comment.validatecommentbox());
        Assert.assertEquals(comment.validatecommentbox(), "Comments");
        logger.info("Comment Box is verified successfully");
    }

    @Test(priority = 33, enabled = true)
    public void closecommentbox() throws InterruptedException {
        Assert.assertTrue(comment.closecommentbox());
        logger.info("Clicked on Comment close Icon Successfully");
    }

    @Test(priority = 35, enabled = true)
    public void clickoncommenticon1() throws InterruptedException {
        comment.clickonCommentIcon();
        logger.info("Clicked on Comment Icon Successfully");
    }

    @Test(priority = 37, enabled = true)
    public void checkuser() throws InterruptedException {
        Assert.assertTrue(comment.checkuser());
        logger.info("user can update the comment");}


    @Test(priority = 39, enabled = true, dependsOnMethods = "checkuser")
    public void checkpostbtnclickable() throws InterruptedException {
        Assert.assertTrue(comment.checkpostbtnclickable());
        logger.info("Post button is clickable ");
    }

    @Test(priority = 41, enabled = false, dependsOnMethods = "checkuser")
    public void checkaleartmsg() throws InterruptedException {
        String actualAlerMessage = comment.validatealertmsg();
        Assert.assertEquals(actualAlerMessage, "?\n"+
                "Oops!\n"+
                "Please enter your comment");
        logger.info("Alert message is verified");
    }

    @Test(priority = 43, enabled = true, dependsOnMethods = "checkuser")
    public void checkcommentbox() throws InterruptedException {
        Assert.assertTrue(comment.entercomment());
        logger.info("comment box is editable for entring the comments ");
    }

    //----------------------- Validation of comments pushing in all tab  ------------------

    @Test(priority = 45, enabled = true, dependsOnMethods = "checkuser")
    public void Metrics_entercomment() throws InterruptedException {
        String tab = "metricstab";
        Assert.assertTrue(comment.entercomment(tab));
        logger.info("comment pushed successfully metrics tab");
    }

    @Test(priority =47, enabled = true, dependsOnMethods = "checkuser")
    public void Metrics_checkcomment() throws InterruptedException {
        String tab = "metricstab";
        Assert.assertTrue(comment.verify_pushedcomment(tab));
        logger.info("comment verificaiton Done successfully metrics tab");
    }


 */





    
   /* @Test(priority = 2 )
    public void verifyReviewerassignee() throws Exception {
        Assert.assertTrue(reportpage.verifyReviewerassignee());
        logger.info("sample is assigning is verified");
    }

    @Test(priority = 3)
    public void getFirstSampleForReview() throws Exception {
        String actualText = String.valueOf(reportpage.assigneAndOpenReport());
        Assert.assertEquals(actualText, "");
        // Assert.assertTrue(reportpage.assigneAndOpenReport());
        logger.info("sample is assigned to reviewer and report opend for validation");
    }*/

   /* @Parameters({"product"})
    @Test(priority = 4, enabled = true)
    public void changeVersion(String product) throws Exception {
        if (!product.contains("Digitizer") && (product.contains("Fundus") || product.contains("OCT"))) {
            Assert.assertTrue(reportpage.changeVersion());
            logger.info("Version is changed to Original");
        }
    }*/
//---------------------------  Verify Report page -------------------------------------


    //Verify Sample Details header
    
   /* @Test(priority = 13,enabled=true)
    public void verifySampleDetailsheader(String product) throws InterruptedException {
        String VerifyList=reportpage.getSampleDetailsHeader();
        Assert.assertEquals(VerifyList,props.getProperty(product+"headersdata"));
        logger.info("Sample page headers : "+VerifyList);
    }*/


    
   /* @Test(priority =17,enabled=true )
    public void getFirstSampleForReview1() throws Exception {
        Assert.assertTrue(reportpage.assigneAndOpenReport());
        logger.info("sample is selected for get the report details");
    }}*/

    //Verify Desclaimer message 
   /* @Parameters({"product"})
    @Test(priority = 18, enabled=true)
    public void verifyDesclaimer(String product) throws InterruptedException {
    	String Verifydesclaimer=reportpage.getDesclaimer();
    	Assert.assertEquals(Verifydesclaimer,props.getProperty(product+"disclaimerdata"));
        logger.info("Desclaimer is verified: "+Verifydesclaimer);
    }*/

    //Verify status container which contain black, Red and blue circles and labels
   /* @Parameters({"product"})
    @Test(priority = 19, enabled=true)
    public void verifyStausContainer(String product) throws InterruptedException {
    	if(product.contains("Shonit") || product.contains("Shrava")) {
    		String Verifystatus=reportpage.getStatusContainers();
    		Assert.assertEquals(Verifystatus,props.getProperty("statuscontainerdata"));
    		logger.info("Status containers : "+Verifystatus);
    	}
    }
    
    //Verify status container which contain black, Red and blue circles and labels
    @Parameters({"product"})
    @Test(priority = 21, enabled=true)
    public void getStatusContainersColors(String product) throws InterruptedException {
    	if(product.contains("Shonit") || product.contains("Shrava")) {
    		String Verifystatus=reportpage.getStatusContainersColors();
    		Assert.assertEquals(Verifystatus,props.getProperty("statuscontainercolordata"));
    		logger.info("Status containers colors: "+Verifystatus);
    	}
    }
     
    //visibility of export button
    @Parameters({"product"})
    @Test(priority = 23, enabled=true)
    public void visibilityOfExportButton(String product) throws InterruptedException
    {
    	if(product.contains("Shonit") || product.contains("Shrava")) {
    		Assert.assertTrue(reportpage.visibilityOfExportButton());
    		logger.info("Export button is visible at top of the page ");
    	}
    }
    
    //visibility of export button
    @Parameters({"product"})
    @Test(priority = 25, enabled=true)
    public void verifyOptionsInExportButton(String product) throws InterruptedException
    {
    	if(product.contains("Shonit") || product.contains("Shrava")) {
    		String options=reportpage.verifyOptionsInExportButton();
    		Assert.assertEquals(options,props.getProperty("listofexportoptions_data"));
    		logger.info("list of options : "+options);
    	}
    }
       
    //Verify All visible tabs
    @Parameters({"product"})
    @Test(priority = 27,enabled=true)
    public void verifyReportPagetabs(String product) throws InterruptedException {
    	String Verifytabs=reportpage.getAllTabs();
    	Assert.assertEquals(Verifytabs,props.getProperty(product+"tabs"));
        logger.info("Report page tabs are verified : "+Verifytabs);
    }
    
    //Verify status container which contain black, Red and blue circles and labels
    @Parameters({"product"})
    @Test(priority = 29, enabled=true)
    public void verifyDefauldLandingPage(String product) throws InterruptedException {
    	if(product.contains("Fundus")) {
    		Assert.assertTrue(reportpage.verifyDefauldLandingPage());
    		logger.info("Defauld landing page is verified");
    	}
    }*/

}

