package com.Common;

import com.data.Shonit_data.PropertiesFile;
import com.utilities.BrowserSetUp;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import java.util.List;
import java.util.Properties;

public class HappyListReportTest extends BrowserSetUp {

    public Properties props;
    public ListReport listreport;
    private final Logger logger = LogManager.getLogger(HappyListReportTest.class);
    public BrowserSetUp pageload;
    boolean productcard;

    @BeforeSuite
    public void setUp() throws Exception {
        driver = getDriver();
        listreport = new ListReport(driver);
        props = PropertiesFile.prop;
        productcard=false;
        PropertiesFile.readShonitListReportFile();

    }
 
    
    //Click on Shonit List Report
    @Parameters({"product"})
    @Test(priority = 2)
    public void clickonListReportTest(String product) throws InterruptedException {
    	Thread.sleep(5000);
    	test = extent.createTest("List Report Test");
        Assert.assertTrue(listreport.clickonListReport(product));
        logger.info("Clicked on List Report Successfully to load");
    }


    //Verify the List Report Page loaded
    @Test(priority = 3)
    public void visibilityOfVersionCard() throws InterruptedException {
    	if(listreport.verifyVersionCard()) {
    		Assert.assertTrue(true);
    		logger.info("about app is opened");
    		productcard=true;
    	}
    }
    
    //Verify the List Report Page loaded
    @Test(priority = 5)
    public void visibilityOfPlateformVersion() throws InterruptedException {
    	if(productcard) {
    		Assert.assertTrue(listreport.verifyPlateformVersion().contains(props.getProperty("plateformversiontext")));
    		logger.info("plateform version is verified");
    	}
    }
    
    //Verify the List Report Page loaded
    @Test(priority = 7)
    public void visibilityOfProductName() throws InterruptedException {
    	if(productcard) {
    		Assert.assertTrue(listreport.verifyProductName().contains(props.getProperty("productnametext")));
    		logger.info("product name is verified");
    	}
    } 
    
    //Verify the List Report Page loaded
    @Test(priority = 9)
    public void visibilityOfSoftwareVersion() throws InterruptedException {
    	if(productcard) {
    		Assert.assertTrue(listreport.verifySoftwareVersion().contains(props.getProperty("softwareversiontext")));
    		logger.info("software version is verified");
    	}
    } 
    
    //Verify the List Report Page loaded
    @Test(priority = 11)
    public void closeproductVersionCard() throws InterruptedException {
    	if(productcard) {
    		Assert.assertTrue(listreport.closeproductVersionCard());
    		logger.info("about app is closed");
    	}
    }
    
    //Verify the List Report Page loaded
    @Test(priority = 13)
    public void verifyListReportpage() throws InterruptedException {
    	Thread.sleep(2000);
    	props = PropertiesFile.prop;
        String verifyListReportpage = listreport.verifyListReportPage();
        Assert.assertEquals(verifyListReportpage,"Analysis Reports");
        logger.info("List Report page loaded");
    }

}
