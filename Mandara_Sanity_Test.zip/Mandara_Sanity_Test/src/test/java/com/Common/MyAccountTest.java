package com.Common;

import com.data.Shonit_data.PropertiesFile;
import com.utilities.BrowserSetUp;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.*;

import java.util.*;


public class MyAccountTest extends BrowserSetUp {
    public Properties props;
    public MyAccount myaccount;
    private static final Logger logger = LogManager.getLogger(MyAccountTest.class);

    @BeforeClass
    public void setUp() throws Exception {
        driver = getDriver();
        myaccount = new MyAccount(driver);
        props = PropertiesFile.prop;
        PropertiesFile.readMandaraHomePropertiesFile();
        PropertiesFile.readPropertiesFIle();
    }

    //To verify the successful load of Mandara Home Page
    @Test(priority = 0, enabled=true)
    public void checkMadaraHomePage() throws InterruptedException
    {
        test = extent.createTest("Mandara Home Test");
        Assert.assertTrue(myaccount.checkMadaraHomePage());
        logger.info("Mandara Home Page has loaded successfully");
    }
    
    //Verify presence of User Icon on Mandara Home Page
    @Test(priority =5, enabled=true)
    public void checkusericon() throws InterruptedException
    {
        Assert.assertTrue(myaccount.checkusericon());
        logger.info("User Icon is present on static bar is present on top right and is clickable");
    }
    //Verify the options present under user icon
    @Test(priority =10, enabled=true)
    public void verifyOptionFromUserIcon() throws InterruptedException
    {
    	String user=props.getProperty("username3");
    	user=user.substring(0, 1).toUpperCase() + user.substring(1);
		String options="Hi! "+user+" "+props.getProperty("usericonoptions_text");
        Assert.assertEquals(myaccount.verifyOptionFromUserIcon(),options);
        logger.info("All expected option are available after click on user icon");
    }
    
    //Verify the Opening of My Account Section
    @Test(priority =15, enabled=true)
    public void verifyClickMyAccount() throws InterruptedException
    {
        Assert.assertTrue(myaccount.clickMyAccountOption());
        logger.info("My Accound Page is opened after clicking My Account Option under User Icon");
    }
    
    //Verify the Presence of Back Button on My Account Page
    @Test(priority =20, enabled=true)
    public void verifyBackButton() throws InterruptedException
    {
        Assert.assertTrue(myaccount.checkBackButtonPresence());
        logger.info("Back Button is present on My Account Page");
    }
    
    //Verify the Presence of User profile Section on My Account Page
    @Test(priority =25, enabled=true)
    public void verifyUserProfileSection() throws InterruptedException
    {
        Assert.assertTrue(myaccount.checkUserProfileSectionPresence());
        logger.info("User Profile Section is present on My Account Page");
    }
    
    //Verify the Presence of Change Password Section on My Account Page
    @Test(priority =30, enabled=true)
    public void verifyChangePasswordSection() throws InterruptedException
    {
        Assert.assertTrue(myaccount.checkChangePasswordSectionPresence());
        logger.info("Change Passowrd Section is present on My Account Page");
    }
    
  //====================================== User Profile Section ===========================================================
    
    //Verify User Profile Header
    @Test(priority =35, enabled=true)
    public void verifyUserProfileHeader() throws InterruptedException
    {
        Assert.assertTrue(myaccount.checkUserProfileHeaderPresence());
        logger.info("User Profile Header is proper under user Profile Section on My Account Page");
    }
   
    //Verify UserName Label And Corresponding value
    @Test(priority =40, enabled=true)
    public void verifyUserNameAndValue() throws InterruptedException
    {
        Assert.assertTrue(myaccount.checkUserNameAndValue());
        logger.info("User Name and Value is proper under user Profile Section on My Account Page");
    }
   
    //Verify Name Label And Corresponding value
    @Test(priority =45, enabled=true)
    public void verifyNameAndValue() throws InterruptedException
    {
        Assert.assertTrue(myaccount.checkNameAndValue());
        logger.info("Name and Value is proper under user Profile Section on My Account Page");
    }
    
    //Verify Email ID Label And Corresponding value
    @Test(priority =50, enabled=true)
    public void verifyEmailIdAndValue() throws InterruptedException
    {
        Assert.assertTrue(myaccount.checkEmailIDAndValue());
        logger.info("Email ID and Value is proper under user Profile Section on My Account Page");
    }
    
    //Verify Partner Label And Corresponding value
    @Test(priority =55, enabled=true)
    public void verifyPartnerAndValue() throws InterruptedException
    {
        Assert.assertTrue(myaccount.checkPartnerAndValue());
        logger.info("Partner and Value is proper under user Profile Section on My Account Page");
    }
    
    //Verify Presence of Edit button on User Profile Section
    @Test(priority =60, enabled=true)
    public void verifyEditButton() throws InterruptedException
    {
        Assert.assertTrue(myaccount.checkEditButtonPresence());
        logger.info("Edit Button is present under user Profile Section on My Account Page");
    }
    
    //Verify Edit Button Functionality
    @Test(priority =65, enabled=true)
    public void verifyEditButtonFunctionality() throws InterruptedException
    {
        Assert.assertTrue(myaccount.clickEditButton());
        logger.info("Edit Button is clickable ");
    }
    
    //Verify Presence of Input Fields after Clicking Edit Button
    @Test(priority =70, enabled=true)
    public void verifyNameAndEmailInputField() throws InterruptedException
    {
        Assert.assertTrue(myaccount.checkNameAndEmailInputBox());
        logger.info("Name and Email ID Field is editable after clicking on Edit Button");
    }
    
    //Verify Presence of Update Button after Clicking Edit Button
    @Test(priority =75, enabled=true)
    public void verifyUpdateButtonPresence() throws InterruptedException
    {
        Assert.assertTrue(myaccount.checkUpdateButton());
        logger.info("Update Button is present under user Profile Section on My Account Page after clicking Edit Button");
    }
    
    //Verify Presence of Cancel Button after Clicking Edit Button
    @Test(priority =80, enabled=true)
    public void verifyCancelButtonPresence() throws InterruptedException
    {
        Assert.assertTrue(myaccount.checkCanceleButton());
        logger.info("Cancel Button is present under user Profile Section on My Account Page after clicking Edit Button");
    }
    
    //Verify the error message displaying for Name Input Field
    @Test(priority =85, enabled=true)
    public void verifyErrorMessageForNameInput() throws InterruptedException
    {
        Assert.assertTrue(myaccount.checkNameInputErrorMessage());
        logger.info("Proper Error message is displaying if user doesn't enter any value in Name Field ");
    }
    //Verify the error message displaying for Email Id Input Field
    @Test(priority =90, enabled=true)
    public void verifyErrorMessageForEmailInput() throws InterruptedException
    {
        Assert.assertTrue(myaccount.checkEmailIDInputErrorMessage());
        logger.info("Proper Error message is displaying if user doesn't enter any value in Email Field ");
    }
    
    //Verify Cancel Button Functionality Under User Profile
    @Test(priority =95, enabled=true)
    public void verifyCancelButtonFunctionality() throws InterruptedException
    {
        Assert.assertTrue(myaccount.checkCanceleButtonFunctionality());
        logger.info("Cancel Button is working as expected under user profile section.");
    }
    
    //Verify updation of Name Field on User Profile Section
    @Test(priority =100, enabled=true)
    public void verifyUpdateNameField() throws InterruptedException
    {
    	String name = myaccount.getRandomString();
        Assert.assertTrue(myaccount.updateNameField(name));
        logger.info("Name Field is Updated and Displaying Properly on User Profile Section");
    }
    
    //Verify the Updated Name Stored in DB
    @Test(priority =105, enabled=true)
    public void verifyNameValueOnDB() throws InterruptedException
    {
    	
        Assert.assertTrue(myaccount.validateUpdatednamewithDB());
        logger.info("Name Field is Verified on Database");
    }
    
    //Verify updation of Email ID Field on User Profile Section
    @Test(priority =110, enabled=true)
    public void verifyUpdateEmailField() throws InterruptedException
    {
    	String email = myaccount.getRandomString()+"@sigtuple.com";
        Assert.assertTrue(myaccount.updateEmailField(email));
        logger.info("Email ID Field is Updated and Displaying Properly on User Profile Section");
    }
    //Verify the Updated Email ID Stored in DB
    @Test(priority =115, enabled=true)
    public void verifyEmailIDValueOnDB() throws InterruptedException
    {
        Assert.assertTrue(myaccount.validateUpdatednamewithDB());
        logger.info("Email ID Field is Verified on Database");
    }
    //Verify the Updation of Original Name and Email ID
    @Test(priority =120, enabled=true)
    public void verifyOriginalNameAndEmailValues() throws InterruptedException
    {
    	
        Assert.assertTrue(myaccount.restoreOriginalNameAndEmail());
        logger.info("Email ID and Name Filed is restored to Original Valiues and Verified against DB");
    }
    
  //====================================== Change Password Section ===========================================================
    
  //Verify Change Password Header
    @Test(priority =200, enabled=true)
    public void verifyChangePasswordHeader() throws InterruptedException
    {
        Assert.assertTrue(myaccount.checkChangePasswordHeaderPresence());
        logger.info("Change Password Header is proper under user Profile Section on My Account Page");
    }
    
  //Verify Presence of Update Button  Under Change Password section
    @Test(priority =205, enabled=true)
    public void verifyUpdateButtonPresenceOnPassword() throws InterruptedException
    {
        Assert.assertTrue(myaccount.checkUpdateButtonOnPasswordSection());
        logger.info("Update Button is present Under Change Password section on My Account Page");
    }
    
    //Verify Presence of Cancel Button Under Change Password section
    @Test(priority =210, enabled=true)
    public void verifyCancelButtonPresenceOnPassword() throws InterruptedException
    {
        Assert.assertTrue(myaccount.checkCanceleButtonOnPasswordSection());
        logger.info("Cancel Button is present Under Change Password section on My Account Page.");
    }
   
    //Verify Current Password Label And Corresponding Text Field
    @Test(priority =215, enabled=true)
    public void verifyCurrentPasswordAndTextField() throws InterruptedException
    {
        Assert.assertTrue(myaccount.checkCurrentPasswordField());
        logger.info("Current Password Label And Corresponding Text Field is proper Under Change Password section on My Account Page");
    }
   
  //Verify New Password Label And Corresponding Text Field
    @Test(priority =220, enabled=true)
    public void verifyNewPasswordAndTextField() throws InterruptedException
    {
        Assert.assertTrue(myaccount.checkNewPasswordField());
        logger.info("New Password Label And Corresponding Text Field is proper Under Change Password section on My Account Page");
    }
    
  //Verify Confirm Password Label And Corresponding Text Field
    @Test(priority =225, enabled=true)
    public void verifyConfirmPasswordAndTextField() throws InterruptedException
    {
        Assert.assertTrue(myaccount.checkConfirmPasswordField());
        logger.info("Confirm Password Label And Corresponding Text Field is proper Under Change Password section on My Account Page");
    }
    
    //Verify the error message displaying for Current Password Field
    @Test(priority =230, enabled=true)
    public void verifyErrorMessageForCurrentPassword() throws InterruptedException
    {
        Assert.assertTrue(myaccount.checkErrorMsgforCurrentPassword());
        logger.info("Proper Error message is displaying if user doesn't enter any value in Current Password Field ");
    }
    //Verify the error message displaying for New Password Field
    @Test(priority =235, enabled=true)
    public void verifyErrorMessageForNewPassword() throws InterruptedException
    {
        Assert.assertTrue(myaccount.checkErrorMsgforNewPassword());
        logger.info("Proper Error message is displaying if user doesn't enter any value in New Password Field ");
    }
  //Verify the error message displaying for Confirm Password Field
    @Test(priority =240, enabled=true)
    public void verifyErrorMessageForConfirmPassword() throws InterruptedException
    {
        Assert.assertTrue(myaccount.checkErrorMsgforConfirmPassword());
        logger.info("Proper Error message is displaying if user doesn't enter any value in Confirm Password Field ");
    }
    
    //Verify the error message being displayed for Wrong Current Password
    @Test(priority =245, enabled=true)
    public void verifyErrorMessageForWrongCurrentPassword() throws InterruptedException
    {
        Assert.assertTrue(myaccount.checkErrorMsgforWrongPassword());
        logger.info("Proper Error message is displaying if user enters current password wrong.");
    }
    
    //Verify the error message being displayed for New and Confirm Password Mismatch
    @Test(priority =250, enabled=true)
    public void verifyErrorMessageForNewPasswordMismatch() throws InterruptedException
    {
        Assert.assertTrue(myaccount.checkErrorMsgforNewPasswordMismatch());
        logger.info("Proper Error message is displaying if user enters New and Confirm Password different");
    }
    
    //Verify the functionality of Cancel Button present under Change Password Section
    @Test(priority =255, enabled=true)
    public void verifyCancelButtonFunctionalityonChangePassword() throws InterruptedException
    {
        Assert.assertTrue(myaccount.checkCancelBtnFunctionality());
        logger.info("Cancel Button is working as expected under Change Password section.");
    }
    
    //Verify the functionality of Update Button present under Change Password Section with Valid Inputs
    @Test(priority =260, enabled=true)
    public void verifyChangePasswordFunctionality() throws InterruptedException
    {
        Assert.assertTrue(myaccount.changePasswordwithValidInputs(props.getProperty("password3"),props.getProperty("password1")));
        logger.info("Password is getting changed successfully after clicking Update under Change Password section. ");
    }
    
    //Verify the New Password is working or not
    @Test(priority =265, enabled=true)
    public void verifyLoginwithNewPassword() throws InterruptedException
    {
        Assert.assertTrue(myaccount.validateNewlyChangedPassword(props.getProperty("username3"),props.getProperty("password1")));
        logger.info("Logout then Login  with newly changed password is working fine");
    }
    
    //Verify changing the password to Original one
    @Test(priority =270, enabled=true)
    public void verifyRestoringToOriginalPassword() throws InterruptedException
    {
        Assert.assertTrue(myaccount.changeToOriginalPassword());
        logger.info("Password Changed to Original Value.");
    }
    
    //Verify the Original password is working or not
    @Test(priority =275, enabled=true)
    public void verifyLoginwithOriginalPassword() throws InterruptedException
    {
        Assert.assertTrue(myaccount.validateNewlyChangedPassword(props.getProperty("username3"),props.getProperty("password3")));
        logger.info("Logout then Login  with Original password is working fine");
    }
    
    
    //Verify the functionality of Back Button
    
    @Test(priority =280, enabled=true)
    public void verifyBackButtonFunctionality() throws InterruptedException
    {
        Assert.assertTrue(myaccount.checkBackButtonFunctionality());
        logger.info("Back Button is wotking fine on My Account Page");
    }
    

}



