package com.Common;

import com.data.Shonit_data.PropertiesFile;
import com.utilities.BrowserSetUp;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import java.util.List;
import java.util.Properties;

public class ListReportTest extends BrowserSetUp {

    public Properties props;
    public ListReport listreport;
    private final Logger logger = LogManager.getLogger(ListReportTest.class);
    public BrowserSetUp pageload;
    boolean productcard;

    @BeforeSuite
    public void setUp() throws Exception {
        driver = getDriver();
        listreport = new ListReport(driver);
        props = PropertiesFile.prop;
        productcard=false;
        PropertiesFile.readShonitListReportFile();

    }
 
    
    //Click on Shonit List Report
    @Parameters({"product"})
    @Test(priority = 2)
    public void clickonListReportTest(String product) throws InterruptedException {
    	Thread.sleep(5000);
    	test = extent.createTest("List Report Test");
        Assert.assertTrue(listreport.clickonListReport(product));
        logger.info("Clicked on List Report Successfully to load");
    }


    //Verify the List Report Page loaded
    @Test(priority = 3)
    public void visibilityOfVersionCard() throws InterruptedException {
    	if(listreport.verifyVersionCard()) {
    		Assert.assertTrue(true);
    		logger.info("about app is opened");
    		productcard=true;
    	}
    }
    
    //Verify the List Report Page loaded
    @Test(priority = 5)
    public void visibilityOfPlateformVersion() throws InterruptedException {
    	if(productcard) {
    		Assert.assertTrue(listreport.verifyPlateformVersion().contains(props.getProperty("plateformversiontext")));
    		logger.info("plateform version is verified");
    	}
    }
    
    //Verify the List Report Page loaded
    @Test(priority = 7)
    public void visibilityOfProductName() throws InterruptedException {
    	if(productcard) {
    		Assert.assertTrue(listreport.verifyProductName().contains(props.getProperty("productnametext")));
    		logger.info("product name is verified");
    	}
    } 
    
    //Verify the List Report Page loaded
    @Test(priority = 9)
    public void visibilityOfSoftwareVersion() throws InterruptedException {
    	if(productcard) {
    		Assert.assertTrue(listreport.verifySoftwareVersion().contains(props.getProperty("softwareversiontext")));
    		logger.info("software version is verified");
    	}
    } 
    
    //Verify the List Report Page loaded
    @Test(priority = 11)
    public void closeproductVersionCard() throws InterruptedException {
    	if(productcard) {
    		Assert.assertTrue(listreport.closeproductVersionCard());
    		logger.info("about app is closed");
    	}
    }
    
    //Verify the List Report Page loaded
    @Test(priority = 13)
    public void verifyListReportpage() throws InterruptedException {
    	Thread.sleep(2000);
    	props = PropertiesFile.prop;
        String verifyListReportpage = listreport.verifyListReportPage();
        Assert.assertEquals(verifyListReportpage,"Analysis Reports");
        logger.info("List Report page loaded");
    }

    
//-------------------------- Testing part -------------------------    
    
    
    
    //Verify the List Report Page loaded
    @Parameters({"product"})
    @Test(priority = 101,enabled=true)
    public void verifymodulname(String product) throws InterruptedException {
    	//Thread.sleep(2000);
    	props = PropertiesFile.prop;
        Assert.assertTrue(listreport.checkmodulname().contains(product));
        logger.info("Modul name contains :"+product);
    }
    
    //Verify the List Report Page loaded
    @Test(priority = 101,enabled=true)
    public void verifyNotpadIcon() throws InterruptedException {
        Assert.assertTrue(listreport.checkNotepadIcon());
        logger.info("Notepad Icon is available before 'Analysis Reports' text");
    }
    
    //Verify Search field is shown
    @Test(priority = 103,enabled = false)
    public void verifysearchField() throws InterruptedException {
        Assert.assertTrue(listreport.searchfield());
        logger.info("Search field is Displayed");
    }

    //verify the filter icon id displayed
    @Test(priority = 105,enabled=true)
    public void verifyfilterIcon() throws InterruptedException {
        Assert.assertTrue(listreport.filtericon());
        logger.info("Filter icon is displayed");
    }

    //Verify the Refresh link icon and click on it
    @Test(priority = 107,enabled=true)
    public void verifyrefreshicon() throws InterruptedException { 
        Assert.assertTrue(listreport.refreshicon());
        logger.info("Refresh icon is displayed");
    }
    
    
    //verify the table headers of List Report page
    @Parameters({"product"})
    @Test(priority = 109,enabled=true)
    public void verifytableheader(String product) throws InterruptedException {
        String VerifyList=listreport.getListReportTableheader();
        Assert.assertEquals(VerifyList,props.getProperty(product+"tablecol"));
        logger.info("Success: validation of list of columns in Shrava list Report "+VerifyList);
    }
    
    //verify the table headers of List Report page
    @Test(priority = 111,enabled=true)
    public void checkpaginationeditbox() throws InterruptedException {
        Assert.assertTrue(listreport.checkpaginationeditbox());
        logger.info("edit box is visible to enter page number ");
    }
    
    //verify the table headers of List Report page
    @Test(priority = 113,enabled=true)
    public void checkpaginationposition() throws InterruptedException {
        Assert.assertTrue(listreport.checkpaginationposition());
        logger.info("table page numbers are visible");
    }
    
    //verify the table headers of List Report page
    @Test(priority = 115,enabled=true)
    public void checkpaginationchevronicons() throws InterruptedException {
        Assert.assertTrue(listreport.checkpaginationchevronicons());
        logger.info("chevron icons are visible at the bottom of page");
    }
      
    //verify Success, failure and In Progress icon
    @Test(priority = 211,enabled=true)
    public void statusIconTest() throws InterruptedException {
    	//Thread.sleep(2000);
        String VerifyList=listreport.getStatusIcons();
        //String list = String.join(",", VerifyList);
        Assert.assertEquals(VerifyList,"true");
        logger.info("All status icon along with status text is verified :" +VerifyList);
    }
    
    
    //verify case ID sorting feature
    @Test(priority = 213,enabled=true)
    public void verifycaseIDsort1() throws InterruptedException {
        Assert.assertTrue(listreport.verifyColumnSorting("caseIDsort"));
        logger.info("caseID sorting is verified");
    }
    
    //verify case ID sorting feature
    @Test(priority = 215,enabled=true)
    public void verifycaseIDsort2() throws InterruptedException {
        Assert.assertTrue(listreport.verifyColumnSorting("caseIDsort"));
        logger.info("caseID sorting is verified");
    }
    
    //verify Installation sorting feature
    @Parameters({"product"})
    @Test(priority = 217,enabled=true)
    public void verifyInstallationsort1(String product) throws InterruptedException {
    	if(!product.contains("Aadi") && !product.contains("Digitizer")) {
    		Assert.assertTrue(listreport.verifyColumnSorting("installsort"));
    		logger.info("Installation sorting is verified");
    	}
    }
    
    //verify Installation sorting feature
    @Parameters({"product"})
    @Test(priority = 219,enabled=true)
    public void verifyInstallationsort2(String product) throws InterruptedException {
    	if(!product.contains("Aadi") && !product.contains("Digitizer")) {
    		Assert.assertTrue(listreport.verifyColumnSorting("installsort"));
    		logger.info("Installation sorting is verified");
    	}
    }
    
    //verify Submited At sorting feature
    @Test(priority = 221,enabled=true)
    public void verifySubmitedAtsort1() throws Exception {
        Assert.assertTrue(listreport.verifySubmitAtSorting());
        logger.info("submit At sorting is verified");
    }
    
    //verify Submited At sorting feature
    @Test(priority = 223,enabled=true)
    public void verifySubmitedAtsort2() throws Exception {
        Assert.assertTrue(listreport.verifySubmitAtSorting());
        logger.info("submit At  sorting is verified");
    }
   
    @Parameters({"product"})
    @Test(priority = 225,enabled=true)
    public void verifySearchEnterText(String product) throws InterruptedException {
        Assert.assertTrue(listreport.searchSampelID(product));
        logger.info("Search Text passed successfully");
    }
    
    @Test(priority = 227,enabled=true)
    public void verifySearchdata() throws InterruptedException {
        Assert.assertTrue(listreport.verifySearchTabledata());
        logger.info("Table sample ID and des is being shown according to searched text");
    }
    
    @Test(priority = 229,enabled=true)
    public void verifyRefreshdata() throws Exception {
        Assert.assertTrue(listreport.verifyRefreshTabledata());
        logger.info("After click on refresh data is sorted bases on the submited by");
    }
    
    
    @Test(priority = 231,enabled=true)
    public void verifyFuctionalityOfChevronIcons() throws Exception {
        Assert.assertTrue(listreport.verifyFuctionalityOfChevronIcons());
        logger.info("Both left and right page movement is verified successfully");
    }
    
    @Test(priority = 232,enabled=true)
    public void verifyReviewerassignee() throws Exception {
        Assert.assertTrue(listreport.verifyReviewerassignee());
        Thread.sleep(3000);
        logger.info("Assignee samples to the reviewer is verified successfully");
    }
    
//------------------------------------ other columns sorting of Digitizer ---------------------------
    //verify Installation sorting feature
    @Parameters({"product"})
    @Test(priority = 301,enabled=true)
    public void verifyResolutionsort1(String product) throws InterruptedException {
    	if(product.contains("Digitizer")) {
    		Assert.assertTrue(listreport.verifyColumnSorting("resolution"));
    		logger.info("Resolution sorting is verified");
    	}
    }
      
    //verify Installation sorting feature
    @Parameters({"product"})
    @Test(priority = 303,enabled=true)
    public void verifyResolutionsort2(String product) throws InterruptedException {
    	if(product.contains("Digitizer")) {
    		Assert.assertTrue(listreport.verifyColumnSorting("resolution"));
    		logger.info("Resolution sorting is verified");
    	}
    }
      
    //verify Installation sorting feature
    @Parameters({"product"})
    @Test(priority = 305,enabled=true)
    public void verifyTestTypesort1(String product) throws InterruptedException {
    	if(product.contains("Digitizer")) {
    		Assert.assertTrue(listreport.verifyColumnSorting("testtype"));
    		logger.info("Test Type sorting is verified");
    	}
    }  
    
    //verify Installation sorting feature
    @Parameters({"product"})
    @Test(priority = 307,enabled=true)
    public void verifyTestTypesort2(String product) throws InterruptedException {
    	if(product.contains("Digitizer")) {
    		Assert.assertTrue(listreport.verifyColumnSorting("testtype"));
    		logger.info("Test Type sorting is verified");
    	}
    }
    
    //verify Installation sorting feature
    @Parameters({"product"})
    @Test(priority = 309,enabled=true)
    public void verifySampleTypesort1(String product) throws InterruptedException {
    	if(product.contains("Digitizer")) {
    		Assert.assertTrue(listreport.verifyColumnSorting("sampletype"));
    		logger.info("Sample Type sorting is verified");
    	}
    }
    
    //verify Installation sorting feature
    @Parameters({"product"})
    @Test(priority = 311,enabled=true)
    public void verifySampleTypesort2(String product) throws InterruptedException {
    	if(product.contains("Digitizer")) {
    		Assert.assertTrue(listreport.verifyColumnSorting("sampletype"));
    		logger.info("Sample Type sorting is verified");
    	}
    }
       
/*

    
    //Verify the status of the first sample
    @Test(priority = 234,dependsOnMethods="verifyfirstsamplestatus",enabled=true)
    public void verifyfirstsamplestatuscolor() throws InterruptedException {
    	//Thread.sleep(2000);
        String firstsamplecolor = listreport.getfirstsampleStatuscolor();
        if(firstsamplecolor == "green"){
            Assert.assertEquals(firstsamplecolor,"green");
            logger.info("Color of first sample status is " + firstsamplecolor);
        }else{
            logger.info("Color of first sample status is " + firstsamplecolor);
        }
    }     
*/
}
