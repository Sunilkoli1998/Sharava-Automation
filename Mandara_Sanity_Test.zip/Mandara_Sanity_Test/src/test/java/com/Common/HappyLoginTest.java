package com.Common;

import com.data.Shonit_data.PropertiesFile;
import com.utilities.BrowserSetUp;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.*;

import java.util.Properties;



public class HappyLoginTest extends BrowserSetUp {

    public WebDriver driver;
    public static Properties props;
    public Login login;



    private static final Logger logger = LogManager.getLogger(HappyLoginTest.class);


    //This will initialise the driver and create login class object
    @BeforeSuite
    public void setUp() throws Exception{
        driver = getDriver();
        login = new Login(driver);
        props = PropertiesFile.prop;
        PropertiesFile.readPropertiesFIle();
    }
    //Verify Title
    @Parameters({"url"})
    @Test(priority = 3)
    public void verifySigTupleTittle(String url)
    {
        test = extent.createTest("Happy Login Test");
        driver.navigate().to(url);
        Assert.assertEquals(login.verifySigTupleTittle(), "SigTuple Mandāra");
        logger.info("Sigtuple title is successfully verified") ;
    }

    @Test(priority = 5,enabled=true)
    public void verifyMandaraAppLoad() throws InterruptedException
    {
    	Thread.sleep(1000);
        Assert.assertTrue(login.verifyMandaraAppLoad());
        logger.info("Mandara App is loaded successfully in UI");
    }

    //Verify Signin Logo
    @Test(priority = 7,enabled=true)
    public void visibilityOfSigtupleLogo() throws InterruptedException
    {
        Assert.assertTrue(login.visibilityOfSigtupleLogo());
        logger.info("Sign in Logo Verified");
    }

    //Verify user alert messages for username, password and forgot password fields
    @Test(priority = 9,enabled=true)
    public void visibilityOfLoginContainer()throws InterruptedException
    {
        Assert.assertTrue(login.visibilityOfLoginContainer());
        logger.info("Login container is visible");
    }
    
    //Verify user alert messages for username, password and forgot password fields
    @Test(priority = 11,enabled=true)
    public void visibilityOfUserNameField()throws InterruptedException
    {
        Assert.assertEquals(login.visibilityOfUserNameField(),"User Name");
        logger.info("verifyVisibilityOfUserNameField");
    }
    
    //Verify user alert messages for username, password and forgot password fields
    @Test(priority = 13,enabled=true)
    public void visibilityOfPassNameField()throws InterruptedException
    {
        Assert.assertEquals(login.visibilityOfPassNameField(),"Password");
        logger.info("verifyVisibilityOfPassNameField");
    }
    
    //Verify user alert messages for username, password and forgot password fields
    @Test(priority = 15,enabled=true)
    public void visibilityOfLoginButton()throws InterruptedException
    {
        Assert.assertEquals(login.visibilityOfLoginButton(),"Login");
        logger.info("visibilityOfLoginButton");
    }
   
    
    //Verify user alert messages for username, password and forgot password fields
    @Test(priority = 21,enabled=true)
    public void visibilityOfForgotPasswordButton()throws InterruptedException
    {
        Assert.assertTrue(login.visibilityOfForgotPasswordButton());
        logger.info("visibilityOfForgotPasswordButton");
    }

    @Test(priority = 41,enabled=true)
    public void verifyCopyrightOnLoginPage()throws InterruptedException
    {
    	String copyright=login.verifyCopyrightOnLoginPage();
    	boolean status = false;
        if (copyright.contains("Copyright"))
        {
        	status =true;
            logger.info("Copy right info is displayed to users on Login Page "+ copyright);
        }
        Assert.assertTrue(status);
    }

    //Send Valid Credentials
    @DataProvider(name = "ValidAuthentication")
    public static Object[][] Validcredentials()  {
        props = PropertiesFile.prop;
        // The number of times data is repeated, test will be executed the same no. of times
        // Here it will execute 1 times
        String user3 = props.getProperty("username3");
        String pwd3 = props.getProperty("password3");

        return new Object[][]{{user3, pwd3}};
    }

    //Verfiy Valid Credentials
    @Test(dataProvider = "ValidAuthentication", priority = 45,enabled=true)
    public void verifyValidLogin(String uname, String pwd) throws InterruptedException 
    {
        if(login.vailidlogin(uname, pwd)) {
        	Assert.assertTrue(true);
        	logger.info("login Done successfully");
        }
        else {
        	logger.info("Login failed");
        	Assert.assertTrue(false);
        }
    }
    
    //Verify user alert messages for username, password and forgot password fields
    @Test(priority = 47,enabled=true)
    public void visibilityMandaraHomePage()throws InterruptedException
    {
    	Thread.sleep(2000);
        Assert.assertTrue(login.visibilityMandaraHomePage());
        logger.info("Mandara home page is Loaded");
    }



}
