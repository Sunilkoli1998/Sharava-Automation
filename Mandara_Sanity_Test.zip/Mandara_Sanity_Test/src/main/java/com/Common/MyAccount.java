package com.Common;


import com.aventstack.extentreports.reporter.configuration.Theme;
import com.data.Shonit_data.PropertiesFile;
import com.mongodb.BasicDBObject;
import com.mongodb.MongoClient;
import com.mongodb.MongoCredential;
import com.mongodb.ServerAddress;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.bson.BSONObject;
import org.bson.Document;
import org.bson.types.ObjectId;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.JavascriptException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;
import java.util.Random;
import java.util.Set;
import java.awt.Desktop.Action;
import java.lang.String;

public class MyAccount extends MandaraHome{

    public Properties props;
    public WebDriver driver;
    WebDriverWait wait;
    private static final Logger logger = LogManager.getLogger(MyAccount.class);
    static String mongopassword = "FKxAleVdamTZwZz3ohKRFCNfi1udFzO0k02U1iDPg";
    List<String> userDetails = new ArrayList<String>();
    String user_name = "Ravi Maurya";
    String email_Id = "ravi@sigtuple.com";
    public Login login;
    		


    public MyAccount(WebDriver driver) throws Exception {
    	super(driver);
        this.driver=driver;
        props = PropertiesFile.prop;
        wait = new WebDriverWait(driver, 30);
        PropertiesFile.readMandaraHomePropertiesFile();
        PropertiesFile.readPropertiesFIle();
        login = new Login(driver);
    }

    //verify mandara home page is opened
    public boolean checkMadaraHomePage() throws InterruptedException
    {
    	Thread.sleep(3000);
        WebElement apptoolbar = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(props.getProperty("apptoolbar"))));
        if (apptoolbar.getText().contains(props.getProperty("mandaraheader")))
        {
            return true;
        }
        else return false;
    }
    
    //verify mini Sigtuple Icon
    public String checkSigtupleIcon() throws InterruptedException
    {
        String sigtupleicon=wait.until(ExpectedConditions.elementToBeClickable(By.xpath(props.getProperty("sigtupleicon")))).getAttribute("alt");
        return sigtupleicon;
    }
    
    //verify User Icon
    public boolean checkusericon() throws InterruptedException
    {
        return wait.until(ExpectedConditions.elementToBeClickable(By.xpath(props.getProperty("usericon")))).isDisplayed();
    }
    
    //Click User Icon
    public void clickUserIcon() {
    	WebElement usericon =wait.until(ExpectedConditions.elementToBeClickable(By.xpath(props.getProperty("usericon"))));
    	usericon.click();
    }
    
    //verify all options after click on user icon
    public String verifyOptionFromUserIcon() throws InterruptedException
    {        
    	WebElement usericon =wait.until(ExpectedConditions.elementToBeClickable(By.xpath(props.getProperty("usericon"))));
    	String options="";
    	if(usericon.isDisplayed()) {
    		usericon.click();
    		Thread.sleep(3000);
    		List<WebElement> optionslist=wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath(props.getProperty("usericonoptions"))));
    		for(WebElement temp:optionslist)
    			options=options+temp.getText()+" ";
    		System.out.println(options);
    		Actions action=new Actions(driver);
    		action.moveToElement(usericon).click().build().perform();
    		Thread.sleep(2000);
    	}
    	return options;
    }
    
    //Logout from Mandara
    public boolean checkLogout() throws InterruptedException {
    	clickUserIcon();
    	Thread.sleep(2000);
    	WebElement logout = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(props.getProperty("logoutOption"))));
    	 ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", logout);
    	Thread.sleep(1000);
    	logout.click();
    	Thread.sleep(3000);
    	boolean flag1 = login.visibilityOfLoginContainer();
    	if(flag1) {
    		return true;
    	}
    	else {
    		return false;
    	}
    	
    	
    }
    
    //====================================== My Account Page ===========================================================
    
  //Click on My Account
   public boolean clickMyAccountOption() throws InterruptedException {
	   clickUserIcon();
	   Thread.sleep(3000);
	   WebElement myAccOption = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(props.getProperty("selectmyaccount"))));
	   myAccOption.click();
	   Thread.sleep(3000);
	   
	   WebElement accountheader = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(props.getProperty("myaccoundheader"))));
	   
	   
	   if(accountheader.isDisplayed()&&(accountheader.getText().trim()).equals(props.getProperty("myaccoundheadertext"))) {
		   return true;
	   }
	   else
		   return false;
	   
	   
   }
   
   //Check presence of back button on top
   public boolean checkBackButtonPresence() {
	   WebElement backbtn = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(props.getProperty("backbutton"))));
	   if(backbtn.isDisplayed()) {
		   return true;
	   }
	   else
		   return false;
	   
   }
   
 //Check presence of User Profile Section
   public boolean checkUserProfileSectionPresence() {
	   WebElement userProfileSection = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(props.getProperty("userprofilesection"))));
	   if(userProfileSection.isDisplayed()) {
		   return true;
	   }
	   else
		   return false;
	   
   }
   
 //Check presence of Change Password Section
   public boolean checkChangePasswordSectionPresence() {
	   WebElement changePasswordSection = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(props.getProperty("changepasssection"))));
	   if(changePasswordSection.isDisplayed()) {
		   return true;
	   }
	   else
		   return false;
	   
   }
   
 //====================================== User Profile Section ===========================================================
   
 //Check presence of User Profile Section Header
   public boolean checkUserProfileHeaderPresence() {
	   WebElement userprofileheader = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(props.getProperty("profilesectionheader"))));
	   WebElement profileline = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(props.getProperty("userprofileline"))));
	   if(userprofileheader.isDisplayed()&& profileline.isDisplayed()) {
		   return true;
	   }
	   else
		   return false;
	   
   }  
   
   
   //Check UserName Field and Corresponding value
   public boolean checkUserNameAndValue() {
	   boolean flag = false;
	   WebElement usernamelabel = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(props.getProperty("usernamekey"))));
	   WebElement usernameValue = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(props.getProperty("usernamevalue"))));
	   if(usernamelabel.isDisplayed()&& usernameValue.isDisplayed()) {
		   String username = usernameValue.getText().trim();
		   if(username.equals(props.getProperty("username3"))){
			   userDetails = getUserDetails(username);
			   flag= true;
		   }
		   else {
			   flag=false;
		   }
		   
	   }
	   else
		   flag= false;
	  
	   return flag;
   } 
   
 //Check Name Field and Corresponding value
   public boolean checkNameAndValue() {
	   boolean flag = false;
	   WebElement namelabel = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(props.getProperty("Namekey"))));
	   WebElement nameValue = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(props.getProperty("nameValue"))));
	   if(namelabel.isDisplayed()&& nameValue.isDisplayed()) {
		   String name = nameValue.getText().trim();
		   if(name.equals(userDetails.get(0))){
			   
			   flag= true;
		   }
		   else {
			   flag=false;
		   }
		   
	   }
	   else
		   flag= false;
	  
	   return flag;
   } 
   
 //Check Email ID Field and Corresponding value
   public boolean checkEmailIDAndValue() {
	   boolean flag = false;
	   WebElement emaillabel = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(props.getProperty("EmailIDkey"))));
	   WebElement emailValue = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(props.getProperty("emailIdvalue"))));
	   if(emaillabel.isDisplayed()&& emailValue.isDisplayed()) {
		   String email = emailValue.getText().trim();
		   if(email.equals(userDetails.get(1))){
			   
			   flag= true;
		   }
		   else {
			   flag=false;
		   }
		   
	   }
	   else
		   flag= false;
	  
	   return flag;
   } 
   
 //Check Partner Field and Corresponding value
   public boolean checkPartnerAndValue() {
	   boolean flag = false;
	   WebElement partnerlabel = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(props.getProperty("partnerkey"))));
	   WebElement partnerValue = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(props.getProperty("partnervalue"))));
	   if(partnerlabel.isDisplayed()&& partnerValue.isDisplayed()) {
		   String partner = partnerValue.getText().trim();
		   String expected_partner = getPartnerDetails(userDetails.get(2));
		   if(partner.equals(expected_partner)){
			   
			   flag= true;
		   }
		   else {
			   flag=false;
		   }
		   
	   }
	   else
		   flag= false;
	  
	   return flag;
   } 
   
   //Check presence of Edit button under User Profile Section
   public boolean checkEditButtonPresence() {
	   WebElement editbtn = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(props.getProperty("Editbutton"))));
	   if(editbtn.isDisplayed()) {
		   return true;
	   }
	   else
		   return false;
	   
   }
   
   //Click on Edit Button
   public boolean clickEditButton() throws InterruptedException {
	   WebElement editbtn = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(props.getProperty("Editbutton"))));
	   if(editbtn.isDisplayed()) {
		   editbtn.click();
		   Thread.sleep(2000);
		   return true;
	   }
	   else
		   return false;
	   
   }
  
   
   //Check Presence of Input Fields
   public boolean checkNameAndEmailInputBox() {
	   try {
		WebElement nameInput = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(props.getProperty("Namevalueinputfield"))));
		   WebElement emailInput = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(props.getProperty("EmailIDvalueinputfield"))));
		   if(nameInput.isDisplayed() && emailInput.isDisplayed()) {
			   
			   return true;
		   }
		   else
			   return false;
	} catch (Exception e) {
		
		//e.printStackTrace();
		return false;
	}
	   
   }

   
   //Check Presence of Update Button
   public boolean checkUpdateButton() throws InterruptedException {
	   WebElement updatebtn = wait.until(ExpectedConditions.elementToBeClickable(By.xpath(props.getProperty("profileUpdatebutton"))));
	   if(updatebtn.isDisplayed()) {
		   return true;
	   }
	   else
		   return false;
	   
   }
   
   //Check Presence of Cancel Button
   public boolean checkCanceleButton() throws InterruptedException {
	   WebElement cancelbtn = wait.until(ExpectedConditions.elementToBeClickable(By.xpath(props.getProperty("profileCancelbutton"))));
	   if(cancelbtn.isDisplayed()) {
		   return true;
	   }
	   else
		   return false;
	   
   }
   //Check Error Message for Name Input Field
   public boolean checkNameInputErrorMessage() throws InterruptedException {
	   try {
		WebElement nameInput = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(props.getProperty("Namevalueinputfield"))));
		   if(nameInput.isDisplayed()) {
			   nameInput.click();
			   Thread.sleep(1000);
			   nameInput.clear();
			   Thread.sleep(1000);
			   nameInput.sendKeys("A");
			   nameInput.sendKeys(Keys.BACK_SPACE);

		   }
		  
		   Thread.sleep(1000);
		   WebElement errorMessage = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(props.getProperty("Namevalueerror"))));
		   if((errorMessage.getText().trim().equals(props.getProperty("NamevalueerrorText")))){
			   return true;
		   }
		   else {
			   return false;
		   }
	} catch (Exception e) {
		
		//e.printStackTrace();
		return false;
	}
   }
   
   //Check Error Message for Email ID Input Filed
   public boolean checkEmailIDInputErrorMessage() throws InterruptedException {
	   try {
		WebElement nameInput = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(props.getProperty("EmailIDvalueinputfield"))));
		   if(nameInput.isDisplayed()) {
			   nameInput.click();
			   Thread.sleep(1000);
			   nameInput.clear();
			   Thread.sleep(1000);
			   nameInput.sendKeys("A");
			   nameInput.sendKeys(Keys.BACK_SPACE);
			   
		   }
		  
		   Thread.sleep(1000);
		   WebElement errorMessage = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(props.getProperty("EmailIDvalueerror"))));
		   if((errorMessage.getText().trim().equals(props.getProperty("EmailIDvalueerrorText")))){
			   return true;
		   }
		   else {
			   return false;
		   }
	} catch (Exception e) {
		
		//e.printStackTrace();
		return false;
	}
   }
   
   //Check Functionality of Cancel Button
   public boolean checkCanceleButtonFunctionality() throws InterruptedException {
	   try {
		WebElement cancelbtn = wait.until(ExpectedConditions.elementToBeClickable(By.xpath(props.getProperty("profileCancelbutton"))));
		   if(cancelbtn.isDisplayed()) {
			   cancelbtn.click();
			   Thread.sleep(2000);
			 }
		   boolean flag1=checkNameAndEmailInputBox();
		   boolean flag2 = checkEditButtonPresence();
		   
		   if(flag1==false && flag2==true)
		   {
			   return true;
		   }
		   else {
			   return  false;
		   }
	} catch (Exception e) {
		
		//e.printStackTrace();
		return false;
	}
	   
   }
   
   //Generate Random String
   public String getRandomString() {
	      String allAlphabets = "abcdefghijklmnopqrstuvwxyz";
	      StringBuilder newString = new StringBuilder();
	      Random rnd = new Random();
	      while (newString.length() < 6) { 
	          int index = (int) (rnd.nextFloat() * allAlphabets.length());
	          newString.append(allAlphabets.charAt(index));
	      }
	      String randomString = newString.toString();
	      
	     //System.out.println(randomString);
	      return randomString;

	  }
   
   //Check Updated Confirmation Message
   public boolean checkUpdateConfirmationMessage(String confirmationmsg) {
	   try {
		WebElement updatebtnconfirm = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(props.getProperty("updateConfirmation"))));
		   if((updatebtnconfirm.getText().trim()).contains( confirmationmsg)) {
			   return true;
		   }
		   else { 
			   return false;
		   }
	} catch (Exception e) {
		
		//e.printStackTrace();
		return false;
	}
   }
   //Compare two values
   public boolean compareTwoValues(WebElement obj) {
	   return false;
	   
   }
   //Check Functionality of update Button on Name Field
   public boolean updateNameField(String name) throws InterruptedException {
	   boolean flag1=false,flag2=false;
	    clickEditButton();
	    try {
			Thread.sleep(2000);
			WebElement nameInput = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(props.getProperty("Namevalueinputfield"))));
			   if(nameInput.isDisplayed()) {
				   nameInput.click();
				   Thread.sleep(1000);
				   nameInput.clear();
				   Thread.sleep(1000);
				   nameInput.sendKeys(name);
			   }
			   WebElement updatebtn = wait.until(ExpectedConditions.elementToBeClickable(By.xpath(props.getProperty("profileUpdatebutton"))));
			   updatebtn.click();
			   flag1=checkUpdateConfirmationMessage(props.getProperty("updateConfirmationMessage"));
			   Thread.sleep(2000);
			   WebElement usernameValue = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(props.getProperty("nameValue"))));
			   if((usernameValue.getText().trim()).equals(name)) {
				   flag2=true;
			   }
			   else {
				   flag2=false;
			   }
			   return flag1&&flag2;
			   
		} catch (Exception e) {
			
			e.printStackTrace();
			return false;
		}
	   
   }
   //validate updated Name 
   public boolean validateUpdatednamewithDB() {
	   
	   boolean flag1 = checkUserNameAndValue();
	   boolean flag2= checkNameAndValue();
	   
	   return flag1&&flag2;
   }
   
   
   //Check Functionality of update Button on Email ID Field
   public boolean updateEmailField(String emailId) throws InterruptedException {
	   boolean flag1=false,flag2=false;
	    clickEditButton();
	    try {
			Thread.sleep(2000);
			WebElement emailInput = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(props.getProperty("EmailIDvalueinputfield"))));
			   if(emailInput.isDisplayed()) {
				   emailInput.click();
				   Thread.sleep(1000);
				   emailInput.clear();
				   Thread.sleep(1000);
				   emailInput.sendKeys(emailId);
			   }
			   WebElement updatebtn = wait.until(ExpectedConditions.elementToBeClickable(By.xpath(props.getProperty("profileUpdatebutton"))));
			   updatebtn.click();
			   flag1=checkUpdateConfirmationMessage(props.getProperty("updateConfirmationMessage"));
			   Thread.sleep(2000);
			   WebElement usernameValue = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(props.getProperty("emailIdvalue"))));
			   if((usernameValue.getText().trim()).equals(emailId)) {
				   flag2=true;
			   }
			   else {
				   flag2=false;
			   }
			   return flag1&&flag2;
		} catch (Exception e) {
			
			e.printStackTrace();
			return false;
		}
	   
   }
   //validate updated Email ID 
   public boolean validateUpdatedEmailwithDB() {
	   
	   boolean flag1 = checkUserNameAndValue();
	   boolean flag2= checkEmailIDAndValue();
	   
	   return flag1&&flag2;
   }
   
   //Restore Original Name and Email Id
   public boolean restoreOriginalNameAndEmail() throws InterruptedException {
	   updateNameField(user_name);
	   
	   updateEmailField(email_Id);
	   boolean flag1 = checkUserNameAndValue();
	   boolean flag2= checkEmailIDAndValue();
	   boolean flag3= checkNameAndValue();
	   return flag1&&flag2&&flag3;
	   
   }
   
   
 //====================================== Change Password Section ===========================================================
   
 //Check presence of Change Password Section Header
   public boolean checkChangePasswordHeaderPresence() {
	   WebElement changepasswordheader = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(props.getProperty("changepasssectionheader"))));
	   ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", changepasswordheader);
	   WebElement passwordline = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(props.getProperty("changepasswordline"))));
	   if(changepasswordheader.isDisplayed()&& passwordline.isDisplayed()) {
		   return true;
	   }
	   else
		   return false;
	   
   }  
   
   //Check Presence of Update Button under Change Password Section
   public boolean checkUpdateButtonOnPasswordSection() throws InterruptedException {
	   WebElement updatebtn = wait.until(ExpectedConditions.elementToBeClickable(By.xpath(props.getProperty("changeUpdatebutton"))));
	   if(updatebtn.isDisplayed()) {
		   return true;
	   }
	   else
		   return false;
	   
   }
   
   //Check Presence of Cancel Button under Change Password Section
   public boolean checkCanceleButtonOnPasswordSection() throws InterruptedException {
	   WebElement cancelbtn = wait.until(ExpectedConditions.elementToBeClickable(By.xpath(props.getProperty("changeCancelbutton"))));
	   if(cancelbtn.isDisplayed()) {
		   return true;
	   }
	   else
		   return false;
	   
   }
   
   //Check the Current Password Label and its corresponding Text Field
   public boolean checkCurrentPasswordField() {
	   WebElement currPasswordLabel = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(props.getProperty("currentpasskey"))));
	   WebElement currPasswordTextField = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(props.getProperty("currentpassvalueinputfield"))));
	   String placeholderText = currPasswordTextField.getAttribute("placeholder");
	   if(currPasswordLabel.isDisplayed() && currPasswordTextField.isDisplayed()) {
		   if(placeholderText.equals(props.getProperty("currentpassvalueinputplaceholderText"))) {
			   return true;
		   }
		   else {
			   return false;
		   }
	   }
	   else {
		   return false;
	   }
	   
   }
   
   //Check the New Password Label and its corresponding Text Field
   public boolean checkNewPasswordField() {
	   WebElement newPasswordLabel = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(props.getProperty("newpasskey"))));
	   WebElement newPasswordTextField = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(props.getProperty("newpassvalueinputfield"))));
	   String placeholderText = newPasswordTextField.getAttribute("placeholder");
	   if(newPasswordLabel.isDisplayed() && newPasswordTextField.isDisplayed()) {
		   if(placeholderText.equals(props.getProperty("newpassvalueinputplaceholderText"))) {
			   return true;
		   }
		   else {
			   return false;
		   }
	   }
	   else {
		   return false;
	   }
	   
   }
   
   //Check the Confirm Password Label and its corresponding Text Field
   public boolean checkConfirmPasswordField() {
	   WebElement confirmPasswordLabel = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(props.getProperty("confirmpasskey"))));
	   WebElement confirmPasswordTextField = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(props.getProperty("confirmpassvalueinputfield"))));
	   String placeholderText = confirmPasswordTextField.getAttribute("placeholder");
	   if(confirmPasswordLabel.isDisplayed() && confirmPasswordTextField.isDisplayed()) {
		   if(placeholderText.equals(props.getProperty("confirmpassvalueinputplaceholderText"))) {
			   return true;
		   }
		   else {
			   return false;
		   }
	   }
	   else {
		   return false;
	   }
	   
   }
   
   //Check the Error message displaying for Current Password
   public boolean checkErrorMsgforCurrentPassword() {
   try {
		WebElement currPasswordTextField = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(props.getProperty("currentpassvalueinputfield"))));
		   if(currPasswordTextField.isDisplayed()) {
			   currPasswordTextField.click();
			   Thread.sleep(1000);
			   currPasswordTextField.clear();
			   Thread.sleep(1000);
//			   currPasswordTextField.sendKeys("A");
//			   currPasswordTextField.sendKeys(Keys.BACK_SPACE);
			   
		   }
		   WebElement newPasswordTextField = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(props.getProperty("newpassvalueinputfield"))));
		   newPasswordTextField.click();
		  
		   Thread.sleep(1000);
		   WebElement errorMessage = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(props.getProperty("currentpassvalueerror"))));
		   if((errorMessage.getText().trim().equals(props.getProperty("currentpassvalueerrorText")))){
			   return true;
		   }
		   else {
			   return false;
		   }
	} catch (Exception e) {
		
		//e.printStackTrace();
		return false;
	}
   }
   
   //Check the Error message displaying for New Password
   
   public boolean checkErrorMsgforNewPassword() {
	   try {
			WebElement newPasswordTextField = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(props.getProperty("newpassvalueinputfield"))));
			   if(newPasswordTextField.isDisplayed()) {
				   newPasswordTextField.click();
				   Thread.sleep(1000);
				   newPasswordTextField.clear();
				   Thread.sleep(1000);
//				   newPasswordTextField.sendKeys("A");
//				   newPasswordTextField.sendKeys(Keys.BACK_SPACE);
				   
			   }
			  
			   WebElement confirmPasswordTextField = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(props.getProperty("confirmpassvalueinputfield"))));
			   confirmPasswordTextField.click();
			   
			   Thread.sleep(1000);
			   WebElement errorMessage = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(props.getProperty("newpassvalueerror"))));
			   if((errorMessage.getText().trim().equals(props.getProperty("newpassvalueerrorText")))){
				   return true;
			   }
			   else {
				   return false;
			   }
		} catch (Exception e) {
			
			//e.printStackTrace();
			return false;
		}
	   }
   
   //Check the Error message displaying for Confirm Password
   public boolean checkErrorMsgforConfirmPassword() {
	   try {
			WebElement confirmPasswordTextField = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(props.getProperty("confirmpassvalueinputfield"))));
			   if(confirmPasswordTextField.isDisplayed()) {
				   confirmPasswordTextField.click();
				   Thread.sleep(1000);
				   confirmPasswordTextField.clear();
				   Thread.sleep(1000);
//				   confirmPasswordTextField.sendKeys("A");
//				   confirmPasswordTextField.sendKeys(Keys.BACK_SPACE);
				   
			   }
			   
			   WebElement currPasswordTextField = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(props.getProperty("currentpassvalueinputfield"))));
			   currPasswordTextField.click();
			  
			   Thread.sleep(1000);
			   WebElement errorMessage = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(props.getProperty("confirmpassvalueerror"))));
			   if((errorMessage.getText().trim().equals(props.getProperty("confirmpassvalueerrorText")))){
				   return true;
			   }
			   else {
				   return false;
			   }
		} catch (Exception e) {
			
			//e.printStackTrace();
			return false;
		}
	   }
   
   
   //Enter Value in Password Field
   public void enterPassword(WebElement passwordTextField, String value) throws InterruptedException {
	   //WebElement currPasswordTextField = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(props.getProperty("currentpassvalueinputfield"))));
	   if(passwordTextField.isDisplayed()) {
		   passwordTextField.click();
		   Thread.sleep(1000);
		   passwordTextField.clear();
		   Thread.sleep(1000);
		   passwordTextField.sendKeys(value);
		   Thread.sleep(1000);
		   }
   }
   
   
   //Check Error Confirmation Message when Current Password is wrong
   public boolean checkErrorMsgforWrongPassword() throws InterruptedException {
	   boolean flag1=false,flag2=false;
	   try {
		WebElement currPasswordTextField = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(props.getProperty("currentpassvalueinputfield"))));
		   WebElement newPasswordTextField = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(props.getProperty("newpassvalueinputfield"))));
		   WebElement confirmPasswordTextField = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(props.getProperty("confirmpassvalueinputfield"))));
		   enterPassword(currPasswordTextField,props.getProperty("password1"));
		   String randomText = getRandomString();
		   enterPassword(newPasswordTextField,randomText);
		   enterPassword(confirmPasswordTextField,randomText);
		   
		   WebElement updatebtn = wait.until(ExpectedConditions.elementToBeClickable(By.xpath(props.getProperty("changeUpdatebutton"))));
		   updatebtn.click();
		   
		   flag1=checkUpdateConfirmationMessage(props.getProperty("currentpasswordmismatchtext"));
		   Thread.sleep(2000);
		   flag2 = checkCurrentPasswordField() && checkNewPasswordField() && checkConfirmPasswordField();
		   
		   return flag1 && flag2;
	} catch (Exception e) {
		
		//e.printStackTrace();
		return false;
	}
	  
   }
   
   //Check Error Confirmation Message when New and Confirm Password Does not match
   public boolean checkErrorMsgforNewPasswordMismatch() throws InterruptedException {
	   boolean flag1=false;
	   try {
		   WebElement currPasswordTextField = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(props.getProperty("currentpassvalueinputfield"))));
		   WebElement newPasswordTextField = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(props.getProperty("newpassvalueinputfield"))));
		   WebElement confirmPasswordTextField = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(props.getProperty("confirmpassvalueinputfield"))));
		   enterPassword(currPasswordTextField,props.getProperty("password3"));
		   String randomText = getRandomString();
		   enterPassword(newPasswordTextField,randomText);
		   String randomText1 = getRandomString();
		   enterPassword(confirmPasswordTextField,randomText1);
		   
		   WebElement updatebtn = wait.until(ExpectedConditions.elementToBeClickable(By.xpath(props.getProperty("changeUpdatebutton"))));
		   updatebtn.click();
		   
		   flag1=checkUpdateConfirmationMessage(props.getProperty("newAndConfirmPassMismatchText"));
		   
		   return flag1;
	} catch (Exception e) {
		
		//e.printStackTrace();
		return false;
	}
   }
   //Check the functionality of Cancel button
   public boolean checkCancelBtnFunctionality() {
	   boolean flag1=false;
	   try {
		   WebElement currPasswordTextField = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(props.getProperty("currentpassvalueinputfield"))));
		   WebElement newPasswordTextField = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(props.getProperty("newpassvalueinputfield"))));
		   WebElement confirmPasswordTextField = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(props.getProperty("confirmpassvalueinputfield"))));
		   enterPassword(currPasswordTextField,props.getProperty("password3"));
		   String randomText = getRandomString();
		   enterPassword(newPasswordTextField,randomText);
		   String randomText1 = getRandomString();
		   enterPassword(confirmPasswordTextField,randomText1);
		   
		   WebElement cancelbtn = wait.until(ExpectedConditions.elementToBeClickable(By.xpath(props.getProperty("changeCancelbutton"))));
		   cancelbtn.click();
		   
		   flag1=checkCurrentPasswordField() && checkNewPasswordField() && checkConfirmPasswordField();
		   
		   return flag1;
	} catch (Exception e) {
		
		//e.printStackTrace();
		return false;
	}
	   
   }
   
   //Check functionality of Update Button with valid inputs
   public boolean changePasswordwithValidInputs(String oldpassword, String newpassword) throws InterruptedException {
	   boolean flag1=false,flag2=false;
	   try {
		   WebElement currPasswordTextField = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(props.getProperty("currentpassvalueinputfield"))));
		   WebElement newPasswordTextField = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(props.getProperty("newpassvalueinputfield"))));
		   WebElement confirmPasswordTextField = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(props.getProperty("confirmpassvalueinputfield"))));
		   enterPassword(currPasswordTextField,oldpassword);
		   enterPassword(newPasswordTextField,newpassword);
		   enterPassword(confirmPasswordTextField,newpassword);
		   
		   WebElement updatebtn = wait.until(ExpectedConditions.elementToBeClickable(By.xpath(props.getProperty("changeUpdatebutton"))));
		   updatebtn.click();
		   
		   flag1=checkUpdateConfirmationMessage(props.getProperty("successfulPasswordchangeText"));
		   Thread.sleep(2000);
		   flag2 = checkCurrentPasswordField() && checkNewPasswordField() && checkConfirmPasswordField();
		   
		   return flag1 && flag2;
	} catch (Exception e) {
		
		//e.printStackTrace();
		return false;
	}
	  
   }
   
   //Logout and Login with New Password
   public boolean validateNewlyChangedPassword(String username, String password) throws InterruptedException {
	  try {
		  wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath(props.getProperty("updateConfirmation"))));
		  boolean flag1= checkLogout();
		  Thread.sleep(2000);
		  boolean flag2 = login.vailidlogin(username,password);
		  Thread.sleep(2000);
		  boolean flag3 = checkMadaraHomePage();
		  Thread.sleep(2000);
		  return flag1 && flag2 && flag3;
	} catch (Exception e) {
		//e.printStackTrace();
		return false;
	}
	   
   }
   
   //Restore the Original Password
   public boolean changeToOriginalPassword() throws InterruptedException {
	   boolean flag1=false;
	   try {
		   clickMyAccountOption();
		   Thread.sleep(2000);
		   checkChangePasswordHeaderPresence();
		   flag1 = changePasswordwithValidInputs(props.getProperty("password1"),props.getProperty("password3"));
		   return flag1;
	} catch (Exception e) {
		//e.printStackTrace();
		return false;
	}
	   
   }
   
   //Check Functionality of Back Button
   public boolean checkBackButtonFunctionality() throws InterruptedException {
	   try {
		   clickMyAccountOption();
		   Thread.sleep(2000);
		   WebElement backbtn = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(props.getProperty("backbutton"))));
		   backbtn.click();
		   Thread.sleep(2000);
		   boolean flag1=checkMadaraHomePage();
		   return flag1;
	} catch (Exception e) {
		//e.printStackTrace();
		return false;
	}
	   
   }
   
   
   
   //=================================== DB Validation ===========================================================
   
   public MongoDatabase mongoDBConnectionTest(){

		// Creating Credentials
		MongoCredential credential = MongoCredential.createCredential("ravi", "app-qa", mongopassword.toCharArray());

		// Creating a Mongo client
		MongoClient mongo = new MongoClient(new ServerAddress("mongo-qa.sigtuple.com", 33000),
				Collections.singletonList(credential));

		//System.out.println("Connected to the database successfully");

		// Accessing the database
		MongoDatabase database = mongo.getDatabase("app-qa");
		return database;

	}
   
   public  List<String> getUserDetails(String username)  {
		MongoDatabase database = mongoDBConnectionTest();
		MongoCollection<Document> collection = database.getCollection("users");
		
		BasicDBObject andQuery = new BasicDBObject();
	    List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
	    obj.add(new BasicDBObject("username", username));
	    
	    andQuery.put("$and", obj);
	  
	    System.out.println(andQuery.toString());
	    List<String> userDetails = new ArrayList<String>();
	    
	    ObjectId oid = new ObjectId();
	  
	    FindIterable<Document> iterDoc = collection.find(andQuery);
	    Iterator<Document> it = iterDoc.iterator();
	    while (it.hasNext()) {
	        
	        Document doc = (Document)it.next();
	        String uname = doc.getString("name");
	        String emailId = doc.getString("email");
	        oid = doc.getObjectId("partner");
	        String partnerId = oid.toString();
	        userDetails.add(uname);
	        userDetails.add(emailId);
	        userDetails.add(partnerId);
	        
	    }
	    System.out.println(userDetails);
	   return userDetails;


	}
   
   public  String getPartnerDetails(String partner_id)  {
		MongoDatabase database = mongoDBConnectionTest();
		MongoCollection<Document> collection = database.getCollection("partners");
		
		ObjectId id = new ObjectId(partner_id);
		BasicDBObject query = new BasicDBObject();
		query.append("_id", id);
		query.putAll((BSONObject) query);
		String partner_name = null;
		FindIterable<Document> iterDoc = collection.find(query);

		// Getting the iterator
		Iterator<Document> it = iterDoc.iterator();
	    while (it.hasNext()) {
	        
	        Document doc = (Document)it.next();
	        partner_name = doc.getString("name");
	        
	    }
	    System.out.println(partner_name);
	    return partner_name;


	}

}

